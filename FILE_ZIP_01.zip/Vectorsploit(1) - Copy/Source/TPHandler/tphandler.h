#pragma once

#include <thread>
#include <chrono>

#include "Execution/execution.h"
#include "Taskscheduler/taskscheduler.h"

namespace TPHandler {
	void Start();
}