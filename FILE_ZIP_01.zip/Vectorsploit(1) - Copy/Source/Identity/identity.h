#pragma once

#include <lstate.h>

namespace Identity {
	uintptr_t GetCapabilitiesForIdentity(int identity);
	void SetIdentity(lua_State* L, int identity);
	int GetIdentity(lua_State* L, int identity);
	void SetCapabilities(Proto* P, lua_State* L);
}