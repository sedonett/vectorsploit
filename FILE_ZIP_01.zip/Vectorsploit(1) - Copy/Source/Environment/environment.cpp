#include "environment.h"
#include <Execution/execution.h>

#include "exploit.h"
#include "cache.h"
#include "crypt.h"
#include "files.h"
#include "closure.h"
#include "input.h"
#include "metatable.h"
#include "script.h"
#include "instance.h"
#include "debug.h"
#include "beta.h"

void Explorer::LogFunction(const char* fmt, ...) {
	if (!logFile.is_open())
		return;

	va_list args;
	va_start(args, fmt);

	va_list args_copy;
	va_copy(args_copy, args);
	int length = vsnprintf(nullptr, 0, fmt, args_copy);
	va_end(args_copy);

	std::string result;
	result.resize(length);
	vsnprintf(&result[0], length + 1, fmt, args);

	va_end(args);

	std::time_t nowTimeT = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
	std::tm* tm = std::localtime(&nowTimeT);
	logFile << "[" << std::put_time(tm, "%d-%m-%Y %H:%M:%S") << "] " << result << "\n"; // %Y-%m-%d
	logFile.flush();
}

bool Explorer::IsExtensionBlacklisted(const fs::path& path) {
	const auto extension = path.extension().string();
	return blacklistedExtensions.find(extension) != blacklistedExtensions.end();
}

bool Explorer::IsPathSafe(const std::string& relativePath) {
	const fs::path base = fs::absolute(workspaceDir);
	const fs::path combined = base / relativePath;

	const fs::path normalizedBase = base.lexically_normal();
	const fs::path normalizedCombined = combined.lexically_normal();

	const auto baseStr = normalizedBase.string();
	const auto combinedStr = normalizedCombined.string();

	if (combinedStr.compare(0, baseStr.length(), baseStr) != 0)
		return false;

	std::string lowerRelativePath = relativePath;
	std::ranges::transform(lowerRelativePath, lowerRelativePath.begin(), ::tolower);

	if (lowerRelativePath.find("..") != std::string::npos)
		return false;

	if (IsExtensionBlacklisted(combined)) {
		return false;
	}

	return true;
}

std::filesystem::path Explorer::CheckPath(lua_State* L) {
	const auto relativePath = lua_tostring(L, 1);

	if (!IsPathSafe(relativePath))
		luaG_runerror(L, "attempt to escape directory or access a blacklisted file type");

	return workspaceDir / relativePath;
}

void Explorer::Init() {

	wchar_t Path[MAX_PATH];
	wchar_t Path2[MAX_PATH];

	GetModuleFileNameW(GetModuleHandleA("nvoglv64.dll"), Path, MAX_PATH);
	const auto currentDirectory = fs::path(std::wstring(Path)).parent_path().parent_path();

	workspaceDir = currentDirectory / "workspace";

	GetModuleFileNameW(GetModuleHandle(NULL), Path2, MAX_PATH);

	std::filesystem::path fullPath(Path2);
	std::filesystem::path contentDir = fullPath.parent_path() / "content";
	if (!std::filesystem::exists(contentDir)) {
		std::filesystem::create_directory(contentDir);
	}
	std::filesystem::path gcaDir = contentDir / "VS";
	if (!std::filesystem::exists(gcaDir)) {
		std::filesystem::create_directory(gcaDir);
	}

	std::wstring gcaPath = gcaDir.wstring();
	assetsDir = gcaDir;

	logFile.open(workspaceDir / "log.txt");
}

void Environment::AddGlobal(lua_State* L, std::vector<const char*> names, lua_CFunction func) {
	for (auto name : names) {
		lua_pushcclosurek(L, func, nullptr, 0, 0);
		lua_setglobal(L, name);
	}
}

void Environment::AddField(lua_State* L, std::vector<const char*> names, lua_CFunction func) {
	for (auto name : names) {
		lua_pushcclosurek(L, func, nullptr, 0, 0);
		lua_setfield(L, -2, name);
	}
}

void Environment::CheckInstance(lua_State* L, int idx, const char* className) {
	std::string typeof_str = luaL_typename(L, 1);
	if (typeof_str != xorstr_("Instance")) {
		luaL_typeerrorL(L, 1, xorstr_("Instance"));
	}

	if (className == "") return;

	lua_getfield(L, idx, "IsA");
	lua_pushvalue(L, idx);
	lua_pushstring(L, className);
	lua_call(L, 2, 1);
	const bool isExpected = lua_toboolean(L, -1);
	lua_pop(L, 1);

	if (!isExpected) {
		luaL_argerror(L, idx, std::format("{} expected", className).c_str());
	}
}

bool MetaHooks::isDangerous(const std::string& method) {
	static const std::unordered_set<std::string> methods = {
		"getasync", "getasyncfullurl", "requestasync", "executejavascript",
		"openbrowserwindow", "sendcommand", "getrobuxbalance", "requestinternal",
		"takescreenshot", "togglerecording", "getlast", "load",
		"openscreenshotsfolder", "makerequest", "httprequestasync", "openurl", "savescriptprofilingdata"
		"getmessageid",
		"openvideosfolder"
	};

	return methods.find(method) != methods.end();
}

auto MetaHooks::namecall_hook(lua_State* L) -> int
{
	if (L->namecall)
	{
		std::string loweredNamecall = L->namecall->data;

		for (auto& x : loweredNamecall) {
			x = std::tolower(x);
		}

		if (loweredNamecall.find("httpget") != std::string::npos ||
			loweredNamecall.find("httpgetasync") != std::string::npos) {
			return ScriptLibrary::httpget(L);
		}

		if (loweredNamecall.find("getobjects") != std::string::npos) {
			return ScriptLibrary::getobjects(L);
		}

		if (isDangerous(loweredNamecall)) {
			luaL_error(L, "Blocked dangerous method: %s", loweredNamecall);
			return 0;
		}
	}

	return reinterpret_cast<__int64(__fastcall*)(__int64)>(old_namecall)((__int64)L);
}

auto MetaHooks::index_hook(lua_State* L) -> int
{
	if (lua_isstring(L, 2))
	{
		std::string key = lua_tostring(L, 2);
		std::string loweredIndex = luaL_checkstring(L, 2);

		uintptr_t instance = *(uintptr_t*)(lua_touserdata(L, 1));
		void* instance2 = lua_touserdata(L, 1);

		for (auto& x : loweredIndex) {
			x = std::tolower(x);
		}

		if (loweredIndex.find("httpget") != std::string::npos ||
			loweredIndex.find("httpgetasync") != std::string::npos) {
			lua_getglobal(L, "httpget");
			return 1;
		}

		if (loweredIndex.find("getobjects") != std::string::npos) {
			lua_getglobal(L, "getobjects");
			return 1;
		}

		if (isDangerous(loweredIndex)) {
			luaL_error(L, "Blocked dangerous index: %s", loweredIndex);
			return 0;
		}
	}

	return reinterpret_cast<__int64(__fastcall*)(__int64)>(old_index)((__int64)L);
}

auto MetaHooks::Initialize(lua_State* L) -> void
{

	//setupLogger();

	lua_getglobal(L, "game");
	lua_getmetatable(L, -1);
	lua_rawgetfield(L, -1, "__namecall");

	Closure* namecall = (Closure*)lua_topointer(L, -1);
	lua_CFunction namecall_f = namecall->c.f;
	old_namecall = (__int64)namecall_f;
	namecall->c.f = namecall_hook;

	lua_settop(L, 0);

	lua_getglobal(L, "game");
	lua_getmetatable(L, -1);
	lua_rawgetfield(L, -1, "__index");

	Closure* index = (Closure*)lua_topointer(L, -1);
	lua_CFunction index_f = index->c.f;
	old_index = (__int64)index_f;
	index->c.f = index_hook;

	lua_settop(L, 0);
}

void Environment::Initialize(lua_State* L) {
	RBX::Print(0, "Explorer::Init()");

	Explorer::Init();

	lua_newtable(L);
	lua_setglobal(L, "_G");

	lua_newtable(L);
	lua_setglobal(L, "shared");

	ExploitLibrary::Register(L);
	CacheLibrary::Register(L);
	CryptLibrary::Register(L);
	FilesLibrary::Register(L);
	ClosureLibrary::Register(L);
	InputLibrary::Register(L);
	MetaTableLibrary::Register(L);
	ScriptLibrary::Register(L);
	InstanceLibrary::Register(L);
	DebugLibrary::Register(L);
	BetaLibrary::Register(L);

	//MetaHooks::Initialize(L);
	RBX::Print(0, "Running INITSCRIPT");

	Execution::Execute(LuauInit);
	RBX::Print(0, "RAN");

}