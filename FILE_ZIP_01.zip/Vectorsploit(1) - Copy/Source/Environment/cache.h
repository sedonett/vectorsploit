#pragma once

#include "environment.h"

using namespace Environment;
using namespace Explorer;

namespace CacheLibrary {
	auto invalidate(lua_State* rl) -> int
	{
		LogFunction(xorstr_("invalidate"));
		luaL_checktype(rl, 1, LUA_TUSERDATA);

		uintptr_t instance = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, 1));

		lua_pushlightuserdata(rl, reinterpret_cast<void*>(RBX::PushInstance));
		lua_rawget(rl, LUA_REGISTRYINDEX);
		lua_pushlightuserdata(rl, reinterpret_cast<void*>(instance));

		lua_pushnil(rl);
		lua_rawset(rl, -3);
		return 0;
	}

	auto iscached(lua_State* rl) -> int
	{
		LogFunction(xorstr_("iscached"));
		luaL_checktype(rl, 1, LUA_TUSERDATA);

		uintptr_t instance = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, 1));

		lua_pushlightuserdata(rl, reinterpret_cast<void*>(RBX::PushInstance));
		lua_rawget(rl, LUA_REGISTRYINDEX);
		lua_pushlightuserdata(rl, reinterpret_cast<void*>(instance));
		lua_rawget(rl, -2);

		lua_pushboolean(rl, !lua_isnil(rl, -1));
		return 1;
	}

	auto replace(lua_State* rl) -> int
	{
		LogFunction(xorstr_("replace"));
		luaL_checktype(rl, 1, LUA_TUSERDATA);
		luaL_checktype(rl, 2, LUA_TUSERDATA);

		uintptr_t instance = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, 1));

		lua_pushlightuserdata(rl, reinterpret_cast<void*>(RBX::PushInstance));
		lua_rawget(rl, LUA_REGISTRYINDEX);
		lua_pushlightuserdata(rl, reinterpret_cast<void*>(instance));

		lua_pushvalue(rl, 2);
		lua_rawset(rl, -3);
		return 0;
	}

	auto cloneref(lua_State* L) -> int
	{
		LogFunction(xorstr_("cloneref"));

		CheckInstance(L, 1);

		const auto original_userdata = lua_touserdata(L, 1);
		const auto returned_userdata = *reinterpret_cast<std::uintptr_t*>(original_userdata);

		lua_pushlightuserdata(L, (void*)RBX::PushInstance);

		lua_rawget(L, -10000);
		lua_pushlightuserdata(L, reinterpret_cast<void*>(returned_userdata));
		lua_rawget(L, -2);

		lua_pushlightuserdata(L, reinterpret_cast<void*>(returned_userdata));
		lua_pushnil(L);
		lua_rawset(L, -4);

		RBX::PushInstance(L, (uintptr_t)original_userdata);

		lua_pushlightuserdata(L, reinterpret_cast<void*>(returned_userdata));
		lua_pushvalue(L, -3);
		lua_rawset(L, -5);
		return 1;
	}

	auto compareinstances(lua_State* rl) -> int
	{
		LogFunction(xorstr_("compareinstances"));
		luaL_checktype(rl, 1, LUA_TUSERDATA);
		luaL_checktype(rl, 2, LUA_TUSERDATA);

		uintptr_t instance_one = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, 1));
		uintptr_t instance_two = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, 2));

		lua_pushboolean(rl, instance_one == instance_two);
		return 1;
	}

	void Register(lua_State* L) {
		lua_newtable(L);
		AddField(L, { xorstr_("invalidate") }, invalidate);
		AddField(L, { xorstr_("iscached") }, iscached);
		AddField(L, { xorstr_("replace") }, replace);
		lua_setfield(L, LUA_GLOBALSINDEX, xorstr_("cache"));

		AddGlobal(L, { xorstr_("cloneref") }, cloneref);
		AddGlobal(L, { xorstr_("compareinstances"), xorstr_("checkinst")}, compareinstances);
	}
}