#pragma once

#include "environment.h"

#include <Execution/execution.h>

using namespace Environment;
using namespace Explorer;

namespace MetaTableLibrary {
	int hookmetamethod(lua_State* L)
	{
		LogFunction(xorstr_("hookmetamethod"));
		luaL_checkany(L, 1);

		const auto MetatableName = luaL_checkstring(L, 2);
		luaL_checktype(L, 3, LUA_TFUNCTION);

		lua_pushvalue(L, 1);
		lua_getmetatable(L, -1);
		if (lua_getfield(L, -1, MetatableName) == LUA_TNIL)
		{
			luaL_argerrorL(
				L, 2, std::format("'{}' is not a valid member of the given object's metatable.", MetatableName).c_str()
			);
		}
		lua_setreadonly(L, -2, false);

		lua_getglobal(L, xorstr_("hookfunction"));
		lua_pushvalue(L, -2);
		lua_pushvalue(L, 3);
		lua_call(L, 2, 1);
		lua_remove(L, -2);
		lua_setreadonly(L, -2, true);
		return 1;
	}

	auto getrawmetatable(lua_State* L) -> int
	{
		LogFunction(xorstr_("getrawmetable"));

		luaL_checkany(L, 1);

		if (!lua_getmetatable(L, 1))
			lua_pushnil(L);

		if (lua_topointer(L, 1) == Execution::MainState->gt)
			luaL_argerror(L, 1, "cannot getrawmetatable on the global environment of the executor");

		return 1;
	}

	template< std::size_t sz >
	bool check_types(lua_State* state, int index, std::array< lua_Type, sz > arr)
	{
		for (auto i = 0u; i < sz; i++)
		{
			if (lua_type(state, index) == arr[i])
				return true;
		}

		return false;
	}

	auto setrawmetatable(lua_State* rl) -> int
	{
		LogFunction(xorstr_("setrawmetatable"));
		if (!check_types<2>(rl, 1, { LUA_TTABLE, LUA_TUSERDATA }))
			luaL_argerrorL(rl, 1, "table or userdata expected");

		luaL_checktype(rl, 2, LUA_TTABLE);

		lua_setmetatable(rl, 1);
		return 1;
	}


	auto isreadonly(lua_State* rl) -> int
	{
		LogFunction(xorstr_("isreadonly"));
		lua_pushboolean(rl, lua_getreadonly(rl, 1));
		return 1;
	}


	auto getnamecallmethod(lua_State* L) -> int
	{
		LogFunction(xorstr_("getnamecallmethod"));

		if (!L->namecall) {
			lua_pushnil(L);
			return 1;
		}

		const auto szNamecall = lua_namecallatom(L, nullptr);

		if (szNamecall == nullptr)
			lua_pushnil(L);
		else
			lua_pushstring(L, szNamecall);

		return 1;
	}

	auto setnamecallmethod(lua_State* rl) -> int
	{
		LogFunction(xorstr_("setnamecallmethod"));
		rl->namecall = reinterpret_cast<TString*>(index2addr(rl, 1)->value.p);
		return 0;
	}

	auto setreadonly(lua_State* rl) -> int
	{
		LogFunction(xorstr_("setreadonly"));
		luaL_checktype(rl, 2, LUA_TBOOLEAN);

		lua_setreadonly(rl, 1, lua_toboolean(rl, 2));
		return 0;
	}

	void Register(lua_State* L) {
		AddGlobal(L, { xorstr_("hookmetamethod") }, hookmetamethod);
		AddGlobal(L, { xorstr_("getrawmetatable") }, getrawmetatable);
		AddGlobal(L, { xorstr_("setrawmetatable") }, setrawmetatable);
		AddGlobal(L, { xorstr_("isreadonly") }, isreadonly);
		AddGlobal(L, { xorstr_("getnamecallmethod") }, getnamecallmethod);
		AddGlobal(L, { xorstr_("setnamecallmethod") }, setnamecallmethod);
		AddGlobal(L, { xorstr_("setreadonly") }, setreadonly);
	}
}