#pragma once

#include "environment.h"

#include <Identity/identity.h>
#include <Compressor/compressor.h>

using namespace Environment;
using namespace Explorer;

std::unordered_map<Closure*, Closure*> savedCClosures = {};

auto FindSavedCClosure(Closure* closure) {
	const auto it = savedCClosures.find(closure);
	return it != savedCClosures.end() ? it->second : nullptr;
}

void SplitString(std::string Str, std::string By, std::vector<std::string>& Tokens)
{
	Tokens.push_back(Str);
	const auto splitLen = By.size();
	while (true)
	{
		auto frag = Tokens.back();
		const auto splitAt = frag.find(By);
		if (splitAt == std::string::npos)
			break;
		Tokens.back() = frag.substr(0, splitAt);
		Tokens.push_back(frag.substr(splitAt + splitLen, frag.size() - (splitAt + splitLen)));
	}
}

std::string strip_error_message(const std::string& message) {
	static auto callstack_regex = std::regex(xorstr_(R"(.*"\]:(\d)*: )"), std::regex::optimize | std::regex::icase);
	if (std::regex_search(message.begin(), message.end(), callstack_regex)) {
		const auto fixed = std::regex_replace(message, callstack_regex, "");
		return fixed;
	}

	return message;
};

static void handler_run(lua_State* L, void* ud) {
	luaD_call(L, (StkId)(ud), LUA_MULTRET);
}

int NewCClosureContinuation(lua_State* L, std::int32_t status) {
	if (status != LUA_OK) {
		std::size_t error_len;
		const char* errmsg = luaL_checklstring(L, -1, &error_len);
		lua_pop(L, 1);
		std::string error(errmsg);

		if (error == std::string(xorstr_("attempt to yield across metamethod/C-call boundary")))
			return lua_yield(L, LUA_MULTRET);

		std::string fixedError = strip_error_message(error);
		std::regex pattern(R"([^:]+:\d+:\s?)");

		std::smatch match;
		if (std::regex_search(fixedError, match, pattern)) {
			fixedError.erase(match.position(), match.length());
		}

		lua_pushlstring(L, fixedError.data(), fixedError.size());
		lua_error(L);
		return 0;
	}

	return lua_gettop(L);
}

int NewCClosureStub(lua_State* L) {
	const auto nArgs = lua_gettop(L);

	Closure* cl = clvalue(L->ci->func);
	if (!cl)
		luaL_error(L, xorstr_("Invalid closure"));

	const auto originalClosure = FindSavedCClosure(cl);
	if (!originalClosure)
		luaL_error(L, xorstr_("Invalid closure"));

	setclvalue(L, L->top, originalClosure);
	L->top++;

	lua_insert(L, 1);

	StkId func = L->base;
	L->ci->flags |= LUA_CALLINFO_HANDLE;

	L->baseCcalls++;
	int status = luaD_pcall(L, handler_run, func, savestack(L, func), 0);
	L->baseCcalls--;

	if (status == LUA_ERRRUN) {
		std::size_t error_len;
		const char* errmsg = luaL_checklstring(L, -1, &error_len);
		lua_pop(L, 1);
		std::string error(errmsg);

		if (error == std::string(xorstr_("attempt to yield across metamethod/C-call boundary")))
			return lua_yield(L, LUA_MULTRET);

		std::string fixedError = strip_error_message(error);
		std::regex pattern(R"([^:]+:\d+:\s?)");

		std::smatch match;
		if (std::regex_search(fixedError, match, pattern)) {
			fixedError.erase(match.position(), match.length());
		}

		lua_pushlstring(L, fixedError.data(), fixedError.size());
		lua_error(L);
		return 0;
	}

	expandstacklimit(L, L->top);

	if (status == 0 && (L->status == LUA_YIELD || L->status == LUA_BREAK))
		return -1;

	return lua_gettop(L);
};

void pushWrappedCClosure(lua_State* L, int idx) {
	auto nIdx = idx < 0 ? idx - 1 : idx;

	Closure* cl1 = clvalue(luaA_toobject(L, idx));
	Proto* p = cl1->l.p.get();

	lua_ref(L, idx);
	lua_pushcclosurek(L, NewCClosureStub, 0, 0, NewCClosureContinuation);

	Closure* cl2 = clvalue(luaA_toobject(L, -1));
	cl2->isC = 1;
	cl2->env = cl1->env;

	lua_ref(L, -1);
	savedCClosures[cl2] = cl1;
}

namespace ClosureLibrary
{
	int is_executor_closure(lua_State* L) {
		LogFunction(xorstr_("isourclosure"));
		if (lua_isfunction(L, 1)) {
			if (const auto pClosure = clvalue(luaA_toobject(L, 1)); pClosure) {
				if (pClosure->isC) {
					lua_pushboolean(L, pClosure->c.debugname == nullptr);
				}
				else {
					bool caller = L->userdata->Script.expired();
					if (caller) {
						lua_pushboolean(L, true);
					}
					else {
						lua_pushboolean(L, pClosure->l.p->linedefined == -1);
					}
				}
			}
			else {
				lua_pushboolean(L, 0);
			}
		}
		else if (lua_isnil(L, 1)) {
			if (!L->userdata->Script.expired()) {
				lua_pushboolean(L, true);
			}
			else {
				lua_pushboolean(L, false);
			}
		}

		return 1;
	}

	int clonefunction(lua_State* L) {
		LogFunction(xorstr_("clonefunction"));
		luaL_checktype(L, 1, LUA_TFUNCTION);

		if (lua_iscfunction(L, 1)) {
			Closure* cloneFunc = (Closure*)lua_topointer(L, 1);

			if (savedCClosures.find(cloneFunc) != savedCClosures.end()) {
				auto closureRef = savedCClosures.find(cloneFunc)->second;
				lua_pushcclosure(L, NewCClosureStub, 0, 0);
				savedCClosures[&luaA_toobject(L, -1)->value.gc->cl] = closureRef;

				return 1;
			}
		}

		lua_clonefunction(L, 1);
		return 1;
	};

	int newcclosure(lua_State* L) {
		LogFunction(xorstr_("newcclosure"));
		luaL_checktype(L, 1, LUA_TFUNCTION);

		if (lua_iscfunction(L, 1)) {
			lua_pushvalue(L, 1);
			return 1;
		}

		pushWrappedCClosure(L, 1);

		return 1;
	}

	int restorefunction(lua_State* L) {
		LogFunction(xorstr_("restorefunction"));
		luaL_checktype(L, 1, LUA_TFUNCTION);

		RBX::Print(0, "restorefunction is currently not implemented.");

		const auto F = clvalue(index2addr(L, 1));
		auto ClosureData = savedCClosures.find(F);

		if (ClosureData == savedCClosures.end())
			luaL_error(L, "Function is currently not hooked.");

		const auto OldClosure = ClosureData->first;
		const auto HookClosure = ClosureData->second;

		int nups1 = OldClosure->nupvalues;
		int nups2 = HookClosure->nupvalues;

		lua_pushvalue(L, 1);
		lua_setfield(L, LUA_REGISTRYINDEX, Crypt::Random::string(32).c_str());

		if (FindSavedCClosure(OldClosure) && FindSavedCClosure(HookClosure)) {
			RBX::Print(0, "Condition #1");
		}

		if (FindSavedCClosure(OldClosure) && !FindSavedCClosure(HookClosure) && OldClosure->isC && HookClosure->isC) {
			lua_clonecfunction(L, 1);

			F->c = OldClosure->c;
			F->l = OldClosure->l;
			F->env = OldClosure->env;

			for (int i = 0; i < nups2; i++)
				setobj2n(L, &F->c.upvals[i], &OldClosure->c.upvals[i]);

			RBX::Print(0, "Condition #2");
		}

		if (FindSavedCClosure(OldClosure) && !FindSavedCClosure(HookClosure) && OldClosure->isC && !HookClosure->isC) {
			RBX::Print(0, "Condition #3");
		}

		if (!FindSavedCClosure(OldClosure) && OldClosure->isC && !HookClosure->isC) {
			RBX::Print(0, "Condition #4");
		}

		if (lua_iscfunction(L, 1) && !FindSavedCClosure(OldClosure)) {
			RBX::Print(0, "Condition #5");
		}

		if (lua_isLfunction(L, 1)) {
			RBX::Print(0, "Condition #6");
		}

		return 1;
	}

	int hookfunction(lua_State* L) {
		LogFunction(xorstr_("hookfunction"));
		luaL_checktype(L, 1, LUA_TFUNCTION);
		luaL_checktype(L, 2, LUA_TFUNCTION);

		const auto OldClosure = (Closure*)lua_topointer(L, 1);
		const auto HookClosure = (Closure*)lua_topointer(L, 2);

		if (FindSavedCClosure(OldClosure) && FindSavedCClosure(HookClosure)) {
			//rbx_print(1, "NC->NC hooking");
			auto originalClosure = FindSavedCClosure(OldClosure);
			if (!originalClosure)
				luaL_error(L, xorstr_("Unable to find original closure <newcclosure to newcclosure hooking>"));

			for (auto i = 0; i < OldClosure->nupvalues; i++)
				luaA_pushobject(L, &OldClosure->c.upvals[i]);

			setclvalue(L, L->top, originalClosure);
			incr_top(L);
			pushWrappedCClosure(L, -1);

			Closure* wrappedClosure = clvalue(luaA_toobject(L, -1));

			savedCClosures[OldClosure] = FindSavedCClosure(HookClosure);

			setclvalue(L, L->top, wrappedClosure);
			incr_top(L);
			return 1;
		}

		if (FindSavedCClosure(OldClosure) && !FindSavedCClosure(HookClosure) && lua_iscfunction(L, 1) && lua_iscfunction(L, 2)) {
			//rbx_print(1, "NC->C hooking");
			lua_ref(L, 1);
			lua_ref(L, 2);
			Closure* originalLClosure = FindSavedCClosure(OldClosure);

			pushWrappedCClosure(L, 2);
			lua_ref(L, -1);

			Closure* wrappedCClosure = clvalue(luaA_toobject(L, -1));

			savedCClosures[OldClosure] = wrappedCClosure;

			setclvalue(L, L->top, originalLClosure);
			incr_top(L);

			return 1;
		}

		if (FindSavedCClosure(OldClosure) && !FindSavedCClosure(HookClosure) && lua_iscfunction(L, 1) && lua_isLfunction(L, 2)) {
			//rbx_print(1, "NC->L hooking");
			lua_ref(L, 1);
			lua_ref(L, 2);
			Closure* originalLClosure = FindSavedCClosure(OldClosure);

			savedCClosures[OldClosure] = HookClosure;

			lua_pushcclosurek(L, NewCClosureStub, nullptr, 0, NewCClosureContinuation);
			savedCClosures[clvalue(luaA_toobject(L, -1))] = originalLClosure;

			return 1;
		}

		if (!FindSavedCClosure(OldClosure) && lua_iscfunction(L, 1) && lua_isLfunction(L, 2)) {
			// C->L
			//rbx_print(1, "C->L hooking");
			pushWrappedCClosure(L, 2);
			Closure* wrappedClosure = clvalue(luaA_toobject(L, -1));

			lua_clonecfunction(L, 1);
			lua_ref(L, -1);

			savedCClosures[OldClosure] = wrappedClosure;

			OldClosure->c.f.set(NewCClosureStub);
			OldClosure->c.cont = NewCClosureContinuation;
			return 1;
		}

		if (lua_iscfunction(L, 1) && !FindSavedCClosure(OldClosure)) {
			if (!lua_iscfunction(L, 2))
				luaL_argerror(L, 2, xorstr_("C function expected"));

			//rbx_print(1, "C->C hooking");

			lua_ref(L, 1);

			for (auto i = 0; i < OldClosure->nupvalues; i++)
				luaA_pushobject(L, &OldClosure->c.upvals[i]);

			lua_clonecfunction(L, 1);

			//lua_ref(L, -1);

			lua_pushcclosure(L, OldClosure->c.f, 0, OldClosure->nupvalues);
			lua_ref(L, -1);


			savedCClosures[OldClosure] = HookClosure;

			if (OldClosure->nupvalues < HookClosure->nupvalues)
				OldClosure->nupvalues = HookClosure->nupvalues;

			for (auto i = 0; i < HookClosure->nupvalues; i++)
			{
				auto OT = &OldClosure->c.upvals[i];
				const auto HT = &HookClosure->c.upvals[i];

				OT->value = HT->value;
				OT->tt = HT->tt;
			}

			OldClosure->c.f = NewCClosureStub;//HookClosure->c.f.get();
			OldClosure->c.cont = NewCClosureContinuation;

			return 1;
		}

		if (lua_isLfunction(L, 1)) {
			if (!lua_isLfunction(L, 2))
				luaL_argerror(L, 2, xorstr_("Lua function expected"));

			//rbx_print(1, "L->L hooking");

			lua_ref(L, 1);

			for (auto i = 0; i < OldClosure->nupvalues; i++)
				luaA_pushobject(L, &OldClosure->l.uprefs[i]);

			lua_clonefunction(L, 1);
			lua_ref(L, -1);

			HookClosure->l.p.get()->linedefined = OldClosure->l.p.get()->linedefined;
			HookClosure->l.p.get()->source.set(OldClosure->l.p.get()->source.get());

			OldClosure->env = (Table*)HookClosure->env;
			OldClosure->l.p = (Proto*)HookClosure->l.p;

			for (int i = 0; i < OldClosure->nupvalues; i++)
				setobj2n(L, &OldClosure->l.uprefs[i], luaO_nilobject);

			for (int i = 0; i < HookClosure->nupvalues; i++)
				setobj2n(L, &OldClosure->l.uprefs[i], &HookClosure->l.uprefs[i]);

			return 1;
		}

		luaL_error(L, xorstr_("Hooking method not supported yet!"));

		return 0;
	};

	int getfunctionbytecode(lua_State* L) {
		LogFunction(xorstr_("getfunctionhash"));

		luaL_checktype(L, 1, LUA_TFUNCTION);

		Closure* cl = (Closure*)lua_topointer(L, 1);

		// closure info
		uint8_t nupvalues = cl->nupvalues;
		Proto* p = (Proto*)cl->l.p;

		std::string result =
			std::to_string((int)p->sizep) + "," +
			std::to_string((int)p->sizelocvars) + "," +
			std::to_string((int)p->sizeupvalues) + "," +
			std::to_string((int)p->sizek) + "," +
			std::to_string((int)p->sizelineinfo) + "," +
			std::to_string((int)p->linegaplog2) + "," +
			std::to_string((int)p->linedefined) + "," +
			std::to_string((int)p->bytecodeid) + "," +
			std::to_string((int)p->sizetypeinfo) + "," +
			std::to_string(nupvalues);

		std::string hash = Crypt::Hash::hash(result, "sha256");

		lua_pushstring(L, hash.c_str());

		return 1;
	}

	int lz4compress(lua_State* L) {
		LogFunction(xorstr_("lz4compress"));

		luaL_checktype(L, 1, LUA_TSTRING);
		const char* data = lua_tolstring(L, 1, 0);
		int nMaxCompressedSize = LZ4_compressBound(strlen(data));
		char* out_buffer = new char[nMaxCompressedSize];

		LZ4_compress(data, out_buffer, strlen(data));
		lua_pushlstring(L, out_buffer, nMaxCompressedSize);
		return 1;
	}

	int lz4decompress(lua_State* L) {
		LogFunction(xorstr_("lz4decompress"));

		luaL_checktype(L, 1, LUA_TSTRING);
		luaL_checktype(L, 2, LUA_TNUMBER);
		const char* data = lua_tolstring(L, 1, 0);
		int data_size = lua_tointeger(L, 2);

		char* pszUnCompressedFile = new char[data_size];

		LZ4_uncompress(data, pszUnCompressedFile, data_size);
		lua_pushlstring(L, pszUnCompressedFile, data_size);
		return 1;
	}

	auto iscclosure(lua_State* rl) -> int
	{
		LogFunction(xorstr_("iscclosure"));

		luaL_checktype(rl, 1, LUA_TFUNCTION);

		lua_pushboolean(rl, lua_iscfunction(rl, 1));
		return 1;
	}

	int islclosure(lua_State* L) {
		luaL_checktype(L, 1, LUA_TFUNCTION);

		lua_pushboolean(L, lua_isLfunction(L, 1));
		return 1;
	};

	auto checkcaller(lua_State* rl) -> int
	{
		LogFunction(xorstr_("checkcaller"));

		lua_pushboolean(rl, rl->userdata->Capabilities == 0x3FFFFFF00LL | Identity::GetCapabilitiesForIdentity(8));
		return 1;
	}

	auto getscriptclosure(lua_State* L) -> int
	{
		LogFunction(xorstr_("getscriptclosure"));

		auto script = *(uintptr_t*)(lua_touserdata(L, 1));
		auto voidptr_script = lua_touserdata(L, 1);

		const char* classname = *reinterpret_cast<const char**>(*reinterpret_cast<uintptr_t*>(script + RBX::Instance::ClassDescriptor) + RBX::ClassDescriptor::ClassName);
		std::string protectedstring_bytecode;

		if (strcmp(classname, xorstr_("LocalScript")) == 0) {
			protectedstring_bytecode = Compressor::decompress(*reinterpret_cast<std::string*>(*reinterpret_cast<uintptr_t*>(script + RBX::Bytecode::LocalScript) + 16));

			if (luau_load(L, xorstr_("@"), protectedstring_bytecode.c_str(), sizeof(protectedstring_bytecode), 0) != LUA_OK) {
				lua_pushnil(L);
				return 1;
			}

			Closure* pClosure = const_cast<Closure*>(static_cast<const Closure*>(lua_topointer(L, -1)));
			Identity::SetCapabilities(pClosure->l.p, L);

			return 1;
		}
		else if (strcmp(classname, xorstr_("ModuleScript")) == 0) {
			*(bool*)(RBX::EnableLoadModule) = true;

			lua_getglobal(L, "debug");
			lua_getfield(L, -1, "loadmodule");
			if (lua_isfunction(L, -1)) {
				lua_pushvalue(L, 1);
				lua_call(L, 1, 1);

				*(bool*)(RBX::EnableLoadModule) = false;

				if (!lua_isnoneornil(L, -1))
				{
					return 1;
				}
				lua_settop(L, 0);
				lua_pushnil(L);
				return 0;
			}
			else {
				lua_settop(L, 0);
				lua_pushnil(L);
				return 1;
			}
		}
		else
		{
			luaL_error(L, xorstr_("LocalScript or ModuleScript expected."));
			return 0;
		}
	}

	inline auto loadstring(lua_State* rl) -> int
	{
		LogFunction(xorstr_("loadstring"));

		const auto luauCode = luaL_checkstring(rl, 1);
		const auto chunkName = luaL_optstring(rl, 2, "=loadstring");

		lua_normalisestack(rl, 1);
		lua_preparepush(rl, 1);

		std::string bytecode = Luau::compile(luauCode, Luau::CompileOptions{ 1, 2 }, {}, &BytecodeEncoder);

		if (luau_load(rl, chunkName, bytecode.c_str(), bytecode.size(), 0) != lua_Status::LUA_OK) {
			lua_pushnil(rl);
			lua_pushvalue(rl, -2);
			return 2;
		}

		Identity::SetCapabilities(((Closure*)lua_topointer(rl, -1))->l.p, rl);
		lua_setsafeenv(rl, LUA_GLOBALSINDEX, false);
		return 1;
	}


	void Register(lua_State* L) {
		AddGlobal(L, { xorstr_("isexecutorclosure"), xorstr_("isourclosure") }, is_executor_closure);
		AddGlobal(L, { xorstr_("clonefunction") }, clonefunction);
		AddGlobal(L, { xorstr_("newcclosure") }, newcclosure);
		AddGlobal(L, { xorstr_("restorefunction") }, restorefunction);
		AddGlobal(L, { xorstr_("hookfunction") }, hookfunction);
		AddGlobal(L, { xorstr_("getfunctionbytecode") }, getfunctionbytecode);
		AddGlobal(L, { xorstr_("lz4compress") }, lz4compress);
		AddGlobal(L, { xorstr_("lz4decompress") }, lz4decompress);
		AddGlobal(L, { xorstr_("iscclosure") }, iscclosure);
		AddGlobal(L, { xorstr_("islclosure") }, islclosure);
		AddGlobal(L, { xorstr_("checkcaller") }, checkcaller);
		AddGlobal(L, { xorstr_("getscriptclosure") }, getscriptclosure);
		AddGlobal(L, { xorstr_("loadstring") }, loadstring);
	}
}