#pragma once

#include <string>

namespace rbx {
	namespace implementation{
		const struct type_holder
		{
			void(__fastcall* construct)(const char*, char*);
			void(__fastcall* moveConstruct)(char*, char*);
			void(__fastcall* destruct)(char*);
		};
	}
}



namespace RBX {

	const struct __declspec(align(8)) Name
	{
		const std::string str;
		const int index;
	};

	struct PeerId
	{
		unsigned int peerId;
	};

	const struct SystemAddress
	{
		RBX::PeerId remoteId;
	};

	namespace Reflection {
		typedef struct Descriptor Descriptor;

		namespace EventSource {

			enum EventTargetInclusion : __int32
			{
				OnlyTarget = 0x0,
				ExcludeTarget = 0x1,
			};

			const struct __declspec(align(8)) RemoteEventInvocationTargetOptions
			{
				const RBX::SystemAddress* target;
				RBX::Reflection::EventSource::EventTargetInclusion isExcludeTarget;
			};
		}

		enum ReflectionType : __int32
		{
			ReflectionType_Void = 0x0,
			ReflectionType_Bool = 0x1,
			ReflectionType_Int = 0x2,
			ReflectionType_Int64 = 0x3,
			ReflectionType_Float = 0x4,
			ReflectionType_Double = 0x5,
			ReflectionType_String = 0x6,
			ReflectionType_ProtectedString = 0x7,
			ReflectionType_Instance = 0x8,
			ReflectionType_Instances = 0x9,
			ReflectionType_Ray = 0xA,
			ReflectionType_Vector2 = 0xB,
			ReflectionType_Vector3 = 0xC,
			ReflectionType_Vector2Int16 = 0xD,
			ReflectionType_Vector3Int16 = 0xE,
			ReflectionType_Rect2d = 0xF,
			ReflectionType_CoordinateFrame = 0x10,
			ReflectionType_Color3 = 0x11,
			ReflectionType_Color3uint8 = 0x12,
			ReflectionType_UDim = 0x13,
			ReflectionType_UDim2 = 0x14,
			ReflectionType_Faces = 0x15,
			ReflectionType_Axes = 0x16,
			ReflectionType_Region3 = 0x17,
			ReflectionType_Region3Int16 = 0x18,
			ReflectionType_CellId = 0x19,
			ReflectionType_GuidData = 0x1A,
			ReflectionType_PhysicalProperties = 0x1B,
			ReflectionType_BrickColor = 0x1C,
			ReflectionType_SystemAddress = 0x1D,
			ReflectionType_BinaryString = 0x1E,
			ReflectionType_Surface = 0x1F,
			ReflectionType_Enum = 0x20,
			ReflectionType_Property = 0x21,
			ReflectionType_Tuple = 0x22,
			ReflectionType_ValueArray = 0x23,
			ReflectionType_ValueTable = 0x24,
			ReflectionType_ValueMap = 0x25,
			ReflectionType_Variant = 0x26,
			ReflectionType_GenericFunction = 0x27,
			ReflectionType_WeakFunctionRef = 0x28,
			ReflectionType_ColorSequence = 0x29,
			ReflectionType_ColorSequenceKeypoint = 0x2A,
			ReflectionType_NumberRange = 0x2B,
			ReflectionType_NumberSequence = 0x2C,
			ReflectionType_NumberSequenceKeypoint = 0x2D,
			ReflectionType_InputObject = 0x2E,
			ReflectionType_Connection = 0x2F,
			ReflectionType_ContentId = 0x30,
			ReflectionType_DescribedBase = 0x31,
			ReflectionType_RefType = 0x32,
			ReflectionType_QFont = 0x33,
			ReflectionType_QDir = 0x34,
			ReflectionType_EventInstance = 0x35,
			ReflectionType_TweenInfo = 0x36,
			ReflectionType_DockWidgetPluginGuiInfo = 0x37,
			ReflectionType_PluginDrag = 0x38,
			ReflectionType_Random = 0x39,
			ReflectionType_PathWaypoint = 0x3A,
			ReflectionType_FloatCurveKey = 0x3B,
			ReflectionType_RotationCurveKey = 0x3C,
			ReflectionType_SharedString = 0x3D,
			ReflectionType_DateTime = 0x3E,
			ReflectionType_RaycastParams = 0x3F,
			ReflectionType_RaycastResult = 0x40,
			ReflectionType_OverlapParams = 0x41,
			ReflectionType_LazyTable = 0x42,
			ReflectionType_DebugTable = 0x43,
			ReflectionType_CatalogSearchParams = 0x44,
			ReflectionType_OptionalCoordinateFrame = 0x45,
			ReflectionType_CSGPropertyData = 0x46,
			ReflectionType_UniqueId = 0x47,
			ReflectionType_Font = 0x48,
			ReflectionType_Blackboard = 0x49,
			ReflectionType_Max = 0x4A,
		};
		enum Descriptor_ThreadSafety : __int32
		{
			Unset = 0x0,
			Unsafe = 0x1,
			ReadSafe = 0x3,
			LocalSafe = 0x7,
			Safe = 0xF,
		};

		struct /*VFT*/ Descriptor_vtbl
		{
			void(__fastcall * deconstructor)(RBX::Reflection::Descriptor* _this);
		};

		const struct __declspec(align(8)) Descriptor_Attributes
		{
			bool isDeprecated;
			const RBX::Reflection::Descriptor* preferred;
			RBX::Reflection::Descriptor_ThreadSafety threadSafety;
		};

		struct Descriptor
		{
			RBX::Reflection::Descriptor_vtbl* __vftable /*VFT*/;
			const RBX::Name* name;
			const RBX::Reflection::Descriptor_Attributes attributes;
		};

		const struct Type : RBX::Reflection::Descriptor
		{
			const RBX::Name* tag;
			const RBX::Reflection::ReflectionType reflectionType;
			const bool isFloat;
			const bool isNumber;
			const bool isEnum;
			const bool isOptional;
		};

		struct Variant_Storage
		{
			const rbx::implementation::type_holder* holder;
			char data[64];
		};

		const struct Variant
		{
			const RBX::Reflection::Type* _type;
			Variant_Storage value;
		};

		
	}
}