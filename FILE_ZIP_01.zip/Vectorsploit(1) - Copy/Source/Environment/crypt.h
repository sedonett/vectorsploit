#include "environment.h"

using namespace Environment;
using namespace Explorer;

namespace CryptLibrary {
	static int base64encode(lua_State* rl)
	{
		LogFunction(xorstr_("base64encode"));
		luaL_checktype(rl, 1, LUA_TSTRING);

		const auto& encoded = Crypt::Base64::encode(lua_tostring(rl, 1));

		lua_pushlstring(rl, encoded.data(), encoded.length());
		return 1;
	}


	static int base64decode(lua_State* rl)
	{
		LogFunction(xorstr_("base64decode"));
		luaL_checktype(rl, 1, LUA_TSTRING);

		const auto& decoded = Crypt::Base64::decode(lua_tostring(rl, 1));

		lua_pushlstring(rl, decoded.data(), decoded.length());
		return 1;
	}


	static int encrypt(lua_State* rl)
	{
		LogFunction(xorstr_("encrypt"));
		luaL_checktype(rl, 1, LUA_TSTRING);
		luaL_checktype(rl, 2, LUA_TSTRING);
		luaL_checktype(rl, 4, LUA_TSTRING);

		const auto& [encrypted, iv] = Crypt::Hash::encrypt(lua_tostring(rl, 1), lua_tostring(rl, 2), lua_isnil(rl, 3) ? "" : lua_tostring(rl, 3), lua_tostring(rl, 4));

		lua_pushlstring(rl, encrypted.data(), encrypted.length());
		lua_pushlstring(rl, iv.data(), iv.length());
		return 2;
	}


	static int decrypt(lua_State* rl)
	{
		LogFunction(xorstr_("decrypt"));
		luaL_checktype(rl, 1, LUA_TSTRING);
		luaL_checktype(rl, 2, LUA_TSTRING);
		luaL_checktype(rl, 3, LUA_TSTRING);
		luaL_checktype(rl, 4, LUA_TSTRING);

		const auto& decrypted = Crypt::Hash::decrypt(lua_tostring(rl, 1), lua_tostring(rl, 2), lua_tostring(rl, 3), lua_tostring(rl, 4));

		lua_pushlstring(rl, decrypted.data(), decrypted.length());
		return 1;
	}


	static int bytes(lua_State* rl)
	{
		LogFunction(xorstr_("bytes"));
		luaL_checktype(rl, 1, LUA_TNUMBER);

		const auto& bytes = Crypt::Random::bytes(lua_tointeger(rl, 1));

		lua_pushlstring(rl, bytes.data(), bytes.length());
		return 1;
	}


	static int generatekey(lua_State* rl)
	{
		LogFunction(xorstr_("generatekey"));
		const auto& key = Crypt::Random::bytes(32);

		lua_pushlstring(rl, key.data(), key.length());
		return 1;
	}


	static int hash(lua_State* rl)
	{
		LogFunction(xorstr_("hash"));
		luaL_checktype(rl, 1, LUA_TSTRING);
		luaL_checktype(rl, 2, LUA_TSTRING);

		const auto& hash = Crypt::Hash::hash(lua_tostring(rl, 1), lua_tostring(rl, 2));

		lua_pushlstring(rl, hash.data(), hash.length());
		return 1;
	}

	static int generatebytes(lua_State* rl)
	{
		LogFunction(xorstr_("generatebytes"));
		luaL_checktype(rl, 1, LUA_TNUMBER);

		const auto& bytes = Crypt::Random::bytes(lua_tointeger(rl, 1));

		lua_pushlstring(rl, bytes.data(), bytes.length());
		return 1;
	}

	void Register(lua_State* L) {
		AddGlobal(L, { xorstr_("base64_encode") }, base64encode);
		AddGlobal(L, { xorstr_("base64_decode") }, base64decode);

		lua_newtable(L);
		AddField(L, { xorstr_("encode") }, base64encode);
		AddField(L, { xorstr_("decode") }, base64decode);
		lua_setfield(L, LUA_GLOBALSINDEX, { xorstr_("base64") });

		lua_newtable(L);
		AddField(L, { xorstr_("base64encode") }, base64encode);
		AddField(L, { xorstr_("base64decode") }, base64decode);
		AddField(L, { xorstr_("base64_encode") }, base64encode);
		AddField(L, { xorstr_("base64_decode") }, base64decode);

		lua_newtable(L);
		AddField(L, { xorstr_("encode") }, base64encode);
		AddField(L, { xorstr_("decode") }, base64decode);
		lua_setfield(L, -2, { xorstr_("base64") });

		AddField(L, { xorstr_("encrypt") }, encrypt);
		AddField(L, { xorstr_("decrypt") }, decrypt);
		AddField(L, { xorstr_("generatebytes") }, generatebytes);
		AddField(L, { xorstr_("generatekey") }, generatekey);
		AddField(L, { xorstr_("hash") }, hash);

		lua_setfield(L, LUA_GLOBALSINDEX, xorstr_("crypt"));
	}
}