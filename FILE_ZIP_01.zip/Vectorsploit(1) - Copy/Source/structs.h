#pragma once

#include <Windows.h>
#include <string>
#include <iostream>
#include <fstream>
#include <unordered_map>

#include <lstate.h>


struct live_thread_ref
{
	int __atomic_refs; // 0
	lua_State* th; // 8
	int thread_id; // 16
	int ref_id; // 20
};

struct weak_thread_ref_t
{
	std::uint8_t pad_0[16];

	weak_thread_ref_t* previous; // 16
	weak_thread_ref_t* next; // 24
	live_thread_ref* liveThreadRef; // 32
	struct Node_t* node; // 40

	std::uint8_t pad_1[8]; // 52
};

struct functionscriptslot_t {
	std::uint8_t pad_0[112];

	live_thread_ref* func_ref; // 112
};

struct slot_t {
	int64_t unk_0; // 0
	void* func_0; // 8

	slot_t* next; // 16
	void* __atomic; // 24

	int64_t sig; // 32

	void* func_1; // 40

	functionscriptslot_t* storage; // 48
};

struct SignalConnectionBridge {
	slot_t* islot; // 0
	int64_t __shared_reference_islot; // 8

	int64_t unk0; // 16
	int64_t unk1; // 24
};

struct Node_t
{
	std::uint8_t pad_0[8];

	weak_thread_ref_t* wtr; // 8
};

inline std::unordered_map<slot_t*, int64_t> NodeMap;

class RBXConnection_t {
private:
	slot_t* node;
	int64_t sig;
	live_thread_ref* func_ref;

public:
	RBXConnection_t(slot_t* node) : node(node), sig(node->sig)
	{
		if (node->storage && (node->storage->func_ref != nullptr))
		{
			func_ref = node->storage->func_ref;
		}
	}

	auto get_function_ref() -> int { return func_ref->ref_id; }
	auto get_thread_ref() -> int { return func_ref->thread_id; }
	auto get_luathread() -> lua_State* { return func_ref->th; }
	auto get_node() -> slot_t* { return this->node; }

	auto is_enabled() -> bool { return node->sig != NULL; }

	auto disable() -> void
	{
		if (!NodeMap[node])
		{
			NodeMap[node] = node->sig;
		}
		node->sig = NULL;
	}

	auto enable() -> void
	{
		if (!node->sig)
		{ // dont wanna fuck up here
			node->sig = NodeMap[node];
		}
	}
};

struct ExtraSpace {
	struct Shared {
		int32_t threadCount;
		void* scriptContext;
		void* scriptVmState;
		char field_18[0x8];
		void* __intrusive_set_AllThreads;
	};

	char _0[8];
	char _8[8];
	char _10[8];
	struct Shared* sharedExtraSpace;
};

struct weak_thread_ref_t2 {
	std::atomic< std::int32_t > _refs;
	lua_State* thread;
	std::int32_t thread_ref;
	std::int32_t object_id;
	std::int32_t unk1;
	std::int32_t unk2;

	weak_thread_ref_t2(lua_State* L)
		: thread(L), thread_ref(NULL), object_id(NULL), unk1(NULL), unk2(NULL) {
	};
};

struct debugger_result_t {
	std::int32_t result;
	std::int32_t unk[0x4];
};