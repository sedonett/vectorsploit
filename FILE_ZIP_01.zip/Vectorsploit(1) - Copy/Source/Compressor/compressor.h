#pragma once

#include <string>
#include <vector>

#include "zstd/xxhash.h"
#include "zstd/zstd.h"

namespace Compressor {
	std::string compress(std::string string);
	std::string decompress(std::string string);
}