#pragma once
#include <string>
#include <iostream>

#include <openssl/sha.h>
#include <openssl/md5.h>
#include <openssl/aes.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/buffer.h>

#include <iomanip>
#include <sstream>
#include <string>

#include <Windows.h>
#include <array>
#include <memory>
#include <Lmcons.h>

#include <comdef.h>
#include <Wbemidl.h>

#pragma comment(lib, "wbemuuid.lib")

namespace Crypt {
    namespace Base64 {
        std::string encode(const std::string& data);
        std::string decode(const std::string& data);
    }

    namespace Random {
        std::string string(int len);
        std::string bytes(int length);
    }

    namespace Hash {
        std::string perform_hash(const EVP_MD* md, const std::string& data);
        std::string hash(const std::string& data, const std::string& algorithm);
        std::string perform_decryption(const EVP_CIPHER* cipher, const std::string& data, const std::string& key, const std::string& iv);
        std::string decrypt(const std::string& data, const std::string& key, const std::string& iv, const std::string& mode);
        std::string perform_encryption(const EVP_CIPHER* cipher, const std::string& data, const std::string& key, const std::string& iv);
        std::pair<std::string, std::string> encrypt(const std::string& data, const std::string& key, const std::string& iv, const std::string& mode);
    }

    namespace HWID {
        std::string GetHWID();
    }
}