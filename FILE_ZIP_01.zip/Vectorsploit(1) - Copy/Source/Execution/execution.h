#pragma once

#include "offsets.h"

#include "TaskScheduler/taskscheduler.h"
#include "Identity/identity.h"

#include "xorstr.hpp"

#include <lualib.h>
#include <Luau/Compiler.h>

namespace Execution {
	inline lua_State* MainState;

	void Initialize();
	void Execute(std::string source);
}