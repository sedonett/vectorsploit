#pragma once
#include <Windows.h>
#include <cstdint>
#include <string> 
#include "xorstr/xorstr.hpp"
#include <filesystem>
#include <Shlobj.h>
#include <regex>
#include <fstream>
#include <iostream>
#include <zstd.h>
#include <xxhash.h>
#include <windef.h>
#include <thread>
#include <chrono>
#include "Luau/lualib.h"
#include "BytecodeBuilder.h"
#include "Compiler.h"
#include "BytecodeUtils.h"
#include "luacode.h"
#include <future>
#include "Luau/lua.h"
#include <condition_variable>
#include <basetsd.h>
#include <minwindef.h>
#include <queue>
#include "Luau/lobject.h"
#include "Luau/lgc.h"
#include "Luau/lmem.h"
#include "Luau/lapi.h"
#include <map>
#include "wininet.h"
#pragma comment(lib, "wininet.lib")






enum EventTargetInclusion : __int32
{
    OnlyTarget = 0x0,
    ExcludeTarget = 0x1,
    TEST = 0x3,
};

struct PeerId
{
    unsigned int peerId;
};

const struct SystemAddress
{
    PeerId remoteId;
};

const struct __declspec(align(8)) RemoteEventInvocationTargetOptions
{
    const SystemAddress* target;
    EventTargetInclusion isExcludeTarget;
};

enum ReflectionType : __int32
{
    ReflectionType_Void = 0x0,
    ReflectionType_Bool = 0x1,
    ReflectionType_Int = 0x2,
    ReflectionType_Int64 = 0x3,
    ReflectionType_Float = 0x4,
    ReflectionType_Double = 0x5,
    ReflectionType_String = 0x6,
    ReflectionType_ProtectedString = 0x7,
    ReflectionType_Instance = 0x8,
    ReflectionType_Instances = 0x9,
    ReflectionType_Ray = 0xA,
    ReflectionType_Vector2 = 0xB,
    ReflectionType_Vector3 = 0xC,
    ReflectionType_Vector2Int16 = 0xD,
    ReflectionType_Vector3Int16 = 0xE,
    ReflectionType_Rect2d = 0xF,
    ReflectionType_CoordinateFrame = 0x10,
    ReflectionType_Color3 = 0x11,
    ReflectionType_Color3uint8 = 0x12,
    ReflectionType_UDim = 0x13,
    ReflectionType_UDim2 = 0x14,
    ReflectionType_Faces = 0x15,
    ReflectionType_Axes = 0x16,
    ReflectionType_Region3 = 0x17,
    ReflectionType_Region3Int16 = 0x18,
    ReflectionType_CellId = 0x19,
    ReflectionType_GuidData = 0x1A,
    ReflectionType_PhysicalProperties = 0x1B,
    ReflectionType_BrickColor = 0x1C,
    ReflectionType_SystemAddress = 0x1D,
    ReflectionType_BinaryString = 0x1E,
    ReflectionType_Surface = 0x1F,
    ReflectionType_Enum = 0x20,
    ReflectionType_Property = 0x21,
    ReflectionType_Tuple = 0x22,
    ReflectionType_ValueArray = 0x23,
    ReflectionType_ValueTable = 0x24,
    ReflectionType_ValueMap = 0x25,
    ReflectionType_Variant = 0x26,
    ReflectionType_GenericFunction = 0x27,
    ReflectionType_WeakFunctionRef = 0x28,
    ReflectionType_ColorSequence = 0x29,
    ReflectionType_ColorSequenceKeypoint = 0x2A,
    ReflectionType_NumberRange = 0x2B,
    ReflectionType_NumberSequence = 0x2C,
    ReflectionType_NumberSequenceKeypoint = 0x2D,
    ReflectionType_InputObject = 0x2E,
    ReflectionType_Connection = 0x2F,
    ReflectionType_ContentId = 0x30,
    ReflectionType_DescribedBase = 0x31,
    ReflectionType_RefType = 0x32,
    ReflectionType_QFont = 0x33,
    ReflectionType_QDir = 0x34,
    ReflectionType_EventInstance = 0x35,
    ReflectionType_TweenInfo = 0x36,
    ReflectionType_DockWidgetPluginGuiInfo = 0x37,
    ReflectionType_PluginDrag = 0x38,
    ReflectionType_Random = 0x39,
    ReflectionType_PathWaypoint = 0x3A,
    ReflectionType_FloatCurveKey = 0x3B,
    ReflectionType_RotationCurveKey = 0x3C,
    ReflectionType_SharedString = 0x3D,
    ReflectionType_DateTime = 0x3E,
    ReflectionType_RaycastParams = 0x3F,
    ReflectionType_RaycastResult = 0x40,
    ReflectionType_OverlapParams = 0x41,
    ReflectionType_LazyTable = 0x42,
    ReflectionType_DebugTable = 0x43,
    ReflectionType_CatalogSearchParams = 0x44,
    ReflectionType_OptionalCoordinateFrame = 0x45,
    ReflectionType_CSGPropertyData = 0x46,
    ReflectionType_UniqueId = 0x47,
    ReflectionType_Font = 0x48,
    ReflectionType_Blackboard = 0x49,
    ReflectionType_Max = 0x4A,
};

struct Descriptor;

enum ThreadSafety : __int32
{
    Unset = 0x0,
    Unsafe = 0x1,
    ReadSafe = 0x3,
    LocalSafe = 0x7,
    Safe = 0xF,
};

const struct  __declspec(align(8)) Name
{
    const std::basic_string<char, std::char_traits<char>, std::allocator<char>> str;
    const int index;
};

struct /*VFT*/ Descriptor_vtbl
{
    void(__fastcall* _Descriptor)(Descriptor* _this);
};

const struct __declspec(align(8)) Attributes
{
    bool isDeprecated;
    const Descriptor* preferred;
    ThreadSafety threadSafety;
};

struct Descriptor
{
    Descriptor_vtbl* __vftable /*VFT*/;
    const Name* name;
    const Attributes attributes;
};

const struct Type : Descriptor
{
    const Name* tag;
    const ReflectionType reflectionType;
    const bool isFloat;
    const bool isNumber;
    const bool isEnum;
    const bool isOptional;
};

const struct type_holder
{
    void(__fastcall* construct)(const char*, char*);
    void(__fastcall* moveConstruct)(char*, char*);
    void(__fastcall* destruct)(char*);
};

struct Storage
{
    const type_holder* holder;
    char data[64];
};

const struct Variant
{
    const Type* _type;
    Storage value;
};










const std::unique_ptr<uintptr_t> DLLbase = std::make_unique<uintptr_t>(reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr)));
#define RegisterFunction(L, Func, Name) lua_pushcclosure(L, Func, Name, 0); \
lua_setglobal(L, Name);

#define RegisterMember(L, Func, Name) lua_pushcclosure(L, Func, Name, 0); \
lua_setfield(L, -2, Name);

#define ARG_CHECK(L, MIN, MAX, T) if (lua_gettop(L) < MIN) { T return 0; } else if (lua_gettop(L) > MAX) { lua_settop(L, MAX); } T

#define oxorany(x) x

class ENV
{
public:
	static void RegisterFunctions(lua_State* L);
	static uintptr_t OFFSET_RaiseEventInvocation;
	static void Execute(uintptr_t state, std::string source);
};

static Table* getcurrenv(lua_State* L)
{
	if (L->ci == L->base_ci)
		return L->gt;
	else
		return curr_func(L)->env;
}

static LUAU_NOINLINE TValue* pseudo2addr(lua_State* L, int idx)
{
	api_check(L, lua_ispseudo(idx));
	switch (idx)
	{ // pseudo-indices
	case LUA_REGISTRYINDEX:
		return registry(L);
	case LUA_ENVIRONINDEX:
	{
		sethvalue(L, &L->global->pseudotemp, getcurrenv(L));
		return &L->global->pseudotemp;
	}
	case LUA_GLOBALSINDEX:
	{
		sethvalue(L, &L->global->pseudotemp, L->gt);
		return &L->global->pseudotemp;
	}
	default:
	{
		Closure* func = curr_func(L);
		idx = LUA_GLOBALSINDEX - idx;
		return (idx <= func->nupvalues) ? &func->c.upvals[idx - 1] : cast_to(TValue*, luaO_nilobject);
	}
	}
}


static LUAU_FORCEINLINE TValue* index2addr(lua_State* L, int idx)
{
	if (idx > 0)
	{
		TValue* o = L->base + (idx - 1);
		api_check(L, idx <= L->ci->top - L->base);
		if (o >= L->top)
			return cast_to(TValue*, luaO_nilobject);
		else
			return o;
	}
	else if (idx > LUA_REGISTRYINDEX)
	{
		api_check(L, idx != 0 && -idx <= L->top - L->base);
		return L->top + idx;
	}
	else
	{
		return pseudo2addr(L, idx);
	}
}