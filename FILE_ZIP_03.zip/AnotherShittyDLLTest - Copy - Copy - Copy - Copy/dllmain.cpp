﻿#include "UNCEnvironment.h"


extern "C" __declspec(dllexport) LRESULT CALLBACK callback(int code, WPARAM wParam, LPARAM lParam) {
	return CallNextHookEx(NULL, code, wParam, lParam);
}


//SHUFFLES AND ENCS AND DUMMYNODE AND OTHERS LOCATED IN VM.H


//--------------------------Jobs----------------------------------

static constexpr uintptr_t job_start = 0x1C8;
static constexpr uintptr_t job_name = 0x90;
static constexpr uintptr_t job_end = 0x1D0;

//-----------------------ScriptContext----------------------------

static constexpr uintptr_t ScriptContextState = 0x120; 
static constexpr uintptr_t ScriptContextJob = 0x1F8; 

//-----------------------Identity---------------------------------

static constexpr uintptr_t Identity = 0x30;
static constexpr uintptr_t Capabilities = 0x48;
static constexpr uintptr_t userdataoffset = 0x78;

static uintptr_t max_capabilities = 0x3FFFFFF00i64 | 0xFFFFFFFFFFFFFCFFui64;


//irrelevant
std::uintptr_t IdentityValue = 8;

std::uintptr_t* IdentityNumber = &IdentityValue;

std::uintptr_t Script[2] = { 0,0 };

//-----------------------Other------------------------------------

const uintptr_t Parent = 0x50;

const uintptr_t TopOffset = 0x28;

const uintptr_t BaseOffset = 0x20;

uintptr_t ENV::OFFSET_RaiseEventInvocation = 0x13BE220;

constexpr uintptr_t OFFSET_TASKDEFER = 0xF223C0; 

constexpr uintptr_t OFFSET_LUAVMLOAD = 0xB54150; 

constexpr uintptr_t OFFSET_GETGLOBALSTATE = 0xD629D0; 

constexpr uintptr_t OFFSET_DECRYPTLUASTATE = 0xB51160; 

constexpr uintptr_t DecryptStateParam = 0x88;

constexpr uintptr_t OFFSET_PRINT = 0x1408B80; 

constexpr uintptr_t OFFSET_GETSCHEDULER = 0x2E021B0;

char kBytecodeMagic[] = "RSB1";

int kBytecodeHashMultiplier = 41;

int kBytecodeHashSeed = 42;










//-----------------------End of offsets----------------------------

using taskdefer_rbx = uintptr_t(__cdecl*)(int64_t rl);
taskdefer_rbx rbx_taskdefer = reinterpret_cast<taskdefer_rbx>(*DLLbase + OFFSET_TASKDEFER);

using luavmload_rbx = uintptr_t(__fastcall*)(int64_t state, std::string* source, const char* chunk, int environment);
luavmload_rbx rbx_luavmload = reinterpret_cast<luavmload_rbx>(*DLLbase + OFFSET_LUAVMLOAD);

using getglobalstate_rbx = uintptr_t(__cdecl*)(uintptr_t sc, uintptr_t* indentity, uintptr_t* script);
getglobalstate_rbx rbx_getglobalstate = reinterpret_cast<getglobalstate_rbx>(*DLLbase + OFFSET_GETGLOBALSTATE);

using decryptluastate_rbx = uintptr_t(__cdecl*)(uintptr_t encrypted);
decryptluastate_rbx rbx_decryptluastate = reinterpret_cast<decryptluastate_rbx>(*DLLbase + OFFSET_DECRYPTLUASTATE);

using print_func = void(*)(int, const char*);
print_func print = reinterpret_cast<print_func>(*DLLbase + OFFSET_PRINT);

using getscheduler_t = __int64(__cdecl*)();
static getscheduler_t rbx_getscheduler = reinterpret_cast<getscheduler_t>(*DLLbase + OFFSET_GETSCHEDULER);

static std::string compress_bytecode(std::string_view bytecode) {
	class ZSTDContext {
		ZSTD_CCtx* ctx;
	public:
		ZSTDContext() : ctx(ZSTD_createCCtx()) {}
		~ZSTDContext() { ZSTD_freeCCtx(ctx); }
		ZSTD_CCtx* get() { return ctx; }
	};

	class CompressBuffer {
		std::vector<char> buffer;
	public:
		CompressBuffer(size_t size) : buffer(size) {}
		char* data() { return buffer.data(); }
		size_t size() const { return buffer.size(); }
	};

	const int dataSize = bytecode.size();
	ZSTDContext ctx;
	CompressBuffer compressed(ZSTD_compressBound(dataSize));

	const int compressedSize = ZSTD_compress(
		compressed.data(),
		compressed.size(),
		bytecode.data(),
		dataSize,
		ZSTD_maxCLevel()
	);

	std::string result = kBytecodeMagic;
	result.append(reinterpret_cast<const char*>(&dataSize), sizeof(dataSize));
	result.append(compressed.data(), compressedSize);

	const unsigned int hash = XXH32(result.data(), result.size(), kBytecodeHashSeed);
	unsigned char hashbytes[4];
	std::memcpy(hashbytes, &hash, sizeof(hash));

	for (size_t i = 0; i < result.size(); ++i) {
		result[i] ^= hashbytes[i % 4] + i * kBytecodeHashMultiplier;
	}

	return result;
}


class bytecode_encoder_t : public Luau::BytecodeEncoder
{
	inline void encode(uint32_t* data, size_t count) override
	{
		for (auto i = 0u; i < count;)
		{
			auto& opcode = *reinterpret_cast<uint8_t*>(data + i);

			i += Luau::getOpLength(LuauOpcode(opcode));

			opcode *= 227;
		}
	}
};
bytecode_encoder_t bytecode_encoder = {};


uintptr_t TaskScheduler = 0;
uintptr_t LuaState = 0;
std::vector<uintptr_t> Jobs{};
void Initialize()
{


	print(0, "starting init...");
	TaskScheduler = rbx_getscheduler();
	print(1, "got scheduler");

	auto JobsStart = *(uintptr_t*)(TaskScheduler + job_start);
	const auto JobsEnd = *(uintptr_t*)(TaskScheduler + job_end);

	for (auto i = JobsStart; i < JobsEnd; i += 0x10) {
		Jobs.push_back(*(uintptr_t*)i);
	}
	print(2, "loaded jobs");
}

uintptr_t GetJobByName(std::string_view JobName)
{
	print(0, "searching for job");
	for (const auto i : Jobs)
	{
		if (*(std::string*)(i + job_name) == JobName) {
			print(1, ("found job " + std::string(JobName)).c_str());
			return i;
		}

	}
	print(2, ("job not found: " + std::string(JobName)).c_str());
	return 0;
}

uintptr_t GetLuaState()
{
	print(0, "fetching lua state...");
	if (!LuaState)
	{
		uintptr_t Identity = 0, Script = 0;
		const auto EncryptedState = rbx_getglobalstate(*(uintptr_t*)(GetJobByName("WaitingHybridScriptsJob") + ScriptContextJob) + ScriptContextState, &Identity, &Script);
		const auto DecryptedLuaState = rbx_decryptluastate(EncryptedState + DecryptStateParam);

		LuaState = DecryptedLuaState;
		print(1, "decrypted lua state");
	}
	return LuaState;
}

uintptr_t GetDatamodelByJob()
{
	print(0, "fetching datamodel...");
	const uintptr_t WaitingHybridScriptsJob = GetJobByName("WaitingHybridScriptsJob");
	const uintptr_t script_context = *(uintptr_t*)(WaitingHybridScriptsJob + ScriptContextJob);
	const uintptr_t DataModel = *(uintptr_t*)(script_context + Parent);

	print(1, "got datamodel!");

	return DataModel;
}

static auto set_context(__int64 state, int level) -> void
{
	uintptr_t userdata = *reinterpret_cast<uintptr_t*>(state + userdataoffset);
	*reinterpret_cast<uintptr_t*>(userdata + Identity) = level;
	*reinterpret_cast<uintptr_t*>(userdata + Capabilities) = max_capabilities;
}

static void Set1Capabilities(Proto* Proto, uintptr_t* CapFlags)
{
	if (!Proto)
		return;

	Proto->userdata = CapFlags;
	for (int i = 0; i < Proto->sizep; ++i)
		Set1Capabilities(Proto->p[i], CapFlags);
}


auto ENV::Execute(uintptr_t state, std::string source) -> void
{
	if (source.empty())
		return;
	lua_State* state2 = lua_newthread((lua_State*)state);
	std::string a = Luau::compile(source);
	std::string bytecode = compress_bytecode(a);
	if (rbx_luavmload((int64_t)state2, &bytecode, "@Vectorsploit", 0) != 0)
	{
		print(3, Luau::compile(source).c_str() + 1);
		return;
	}
	else
	{
		Set1Capabilities(((Closure*)lua_topointer((lua_State*)state2, -1))->l.p, &max_capabilities);
		rbx_taskdefer((int64_t)state2);
	}
}

class PipeSystem {
private:
	static constexpr size_t BUFFER_SIZE = 8192;
	static constexpr size_t MAX_BUFFER_SIZE = 999234524;

	struct Buffer {
		std::unique_ptr<char[]> data;
		size_t size;

		Buffer(size_t bufferSize) :
			data(std::make_unique<char[]>(bufferSize)),
			size(bufferSize) {}
	};

	class PipeHandle {
		HANDLE handle;
	public:
		PipeHandle(LPCWSTR name) {
			SECURITY_ATTRIBUTES sa;
			SECURITY_DESCRIPTOR sd;
			InitializeSecurityDescriptor(&sd, SECURITY_DESCRIPTOR_REVISION);
			SetSecurityDescriptorDacl(&sd, TRUE, nullptr, FALSE);
			sa.nLength = sizeof(sa);
			sa.lpSecurityDescriptor = &sd;
			sa.bInheritHandle = TRUE;

			handle = CreateNamedPipe(
				name,
				PIPE_ACCESS_DUPLEX | PIPE_TYPE_BYTE | PIPE_READMODE_BYTE,
				PIPE_WAIT,
				1,
				BUFFER_SIZE,
				BUFFER_SIZE,
				NMPWAIT_USE_DEFAULT_WAIT,
				&sa
			);
		}

		~PipeHandle() {
			if (handle != INVALID_HANDLE_VALUE) {
				DisconnectNamedPipe(handle);
				CloseHandle(handle);
			}
		}

		operator HANDLE() const { return handle; }
	};

public:
	static bool ReadFromPipe(HANDLE hPipe, uintptr_t LuaState) {
		Buffer buffer(BUFFER_SIZE);
		std::string accumulator;
		DWORD bytesRead;

		while (ReadFile(hPipe, buffer.data.get(), buffer.size - 1, &bytesRead, nullptr) && bytesRead > 0) {
			buffer.data[bytesRead] = '\0';
			accumulator.append(buffer.data.get(), bytesRead);
		}

		if (!accumulator.empty()) {
			ENV::Execute(LuaState, accumulator);
			return true;
		}

		return false;
	}

	static void RunNamedPipe(LPCWSTR pipeName, uintptr_t LuaState) {
		while (true) {
			PipeHandle pipe(pipeName);
			if (pipe == INVALID_HANDLE_VALUE) continue;

			if (ConnectNamedPipe(pipe, nullptr)) {
				std::string script_source;
				Buffer buffer(BUFFER_SIZE);
				DWORD bytesRead;

				while (ReadFile(pipe, buffer.data.get(), buffer.size - 1, &bytesRead, nullptr)) {
					buffer.data[bytesRead] = '\0';
					script_source.append(buffer.data.get(), bytesRead);
				}

				if (!script_source.empty()) {
					ENV::Execute(LuaState, script_source);
				}
			}
		}
	}
};


__forceinline void MainThread(HMODULE DllModule) {
	Initialize();
	uintptr_t LuaState = GetLuaState();
	uintptr_t DataModel = GetDatamodelByJob();
	*reinterpret_cast<bool*>(DataModel + 0x420) = false;

	set_context(LuaState, 8);
	luaL_sandboxthread((lua_State*)LuaState);
	lua_createtable((lua_State*)LuaState, 0, 0);
	lua_setfield((lua_State*)LuaState, -10002, "_G");
	lua_newtable((lua_State*)LuaState);
	lua_setglobal((lua_State*)LuaState, "shared");

	ENV::RegisterFunctions((lua_State*)LuaState);
	
	print(0, "VS is injected!");
	print(1, "VS is injected!");
	print(2, "VS is injected!");
	print(3, "VS is injected!");
	print(4, "VS is injected!");

	LPCWSTR pipeName = L"\\\\.\\pipe\\vectorsploit";
	std::thread([pipeName, LuaState]() {
		PipeSystem::RunNamedPipe(pipeName, LuaState);
		}).detach();
}

bool __stdcall DllMain(HMODULE DllModule, uintptr_t ReasonForCall, void*)
{
	if (ReasonForCall == DLL_PROCESS_ATTACH)
	{
		DWORD oldProtect;
		VirtualProtect((LPVOID)DllModule, 0x1000, PAGE_READWRITE, &oldProtect);
		RtlZeroMemory((LPVOID)DllModule, 0x1000);
		VirtualProtect((LPVOID)DllModule, 0x1000, oldProtect, &oldProtect);

		std::thread(MainThread, DllModule).detach();
	}
	return true;
}

