#include "UNCEnvironment.h"
#include "Luau/lfunc.h"
#include "Base64/Base64.h"
#include "lz4/lz4.h"

//ENV
static std::vector<Closure*> function_array;
static std::map<Closure*, Closure*> newcclosure_map;

static __int64 old_namecall;
static __int64 old_index;

std::vector<const char*> dangerous_functions =
{
	"OpenVideosFolder", "OpenScreenshotsFolder",
	"GetRobuxBalance", "PerformPurchase", "PromptBundlePurchase", "PromptNativePurchase",
	"PromptProductPurchase", "PromptPurchase", "PromptThirdPartyPurchase", "Publish",
	"GetMessageId", "OpenBrowserWindow", "RequestInternal", "ExecuteJavaScript",
	"openvideosfolder", "openscreenshotsfolder", "getrobuxbalance", "performpurchase",
	"promptbundlepurchase", "promptnativepurchase", "promptproductpurchase",
	"promptpurchase", "promptthirdpartypurchase", "publish", "getmessageid", "promptcancelsubscription", "promptcollectiblespurchase", "promptgamepasspurchase",
	"openbrowserwindow", "requestinternal", "executejavascript", "openVideosFolder",
	"openScreenshotsFolder", "getRobuxBalance", "performPurchase", "promptBundlePurchase",
	"promptNativePurchase", "promptProductPurchase", "promptPurchase", "promptbulkpurchase", "promptpremiumpurchase",
	"promptrobloxpurchase", "promptsubscriptionpurchase", "performbulkpurchase", "performpurchasev2", "performsubscriptionpurchase", "performsubscriptionpurchasev2", "performcancelsubscription",
	"promptThirdPartyPurchase", "publish", "getMessageId", "openBrowserWindow",
	"requestInternal", "executeJavaScript",
	"ToggleRecording", "TakeScreenshot", "HttpRequestAsync", "GetLast",
	"SendCommand", "GetAsync", "GetAsyncFullUrl", "RequestAsync", "MakeRequest",
	"togglerecording", "takescreenshot", "httprequestasync", "getlast",
	"sendcommand", "getasync", "getasyncfullurl", "requestasync", "makerequest",
	"toggleRecording", "takeScreenshot", "httpRequestAsync", "getLast",
	"sendCommand", "getAsync", "getAsyncFullUrl", "requestAsync", "makeRequest"
};



enum type
{
	roblox_c_closure,
	module_c_closure,
	module_c_wrap,
	l_closure,
	not_set
};

__forceinline static int GetGenv(lua_State* L)
{
	lua_pushvalue(L, LUA_ENVIRONINDEX);
	return 1;
}



auto getreg(lua_State* rl) -> int
{
	lua_pushvalue(rl, LUA_REGISTRYINDEX);
	return 1;
}

auto getrenv(lua_State* rl) -> int
{
	setobj(rl, rl->top, index2addr(rl->global->mainthread, LUA_GLOBALSINDEX));
	incr_top(rl);
	return 1;
}

auto getsenv(lua_State* L) -> int
{
	ARG_CHECK(L, 1, 1);
	return 1;
};


static std::string replace_all(std::string subject, const std::string& search, const std::string& replace)
{
	size_t pos = 0;
	while ((pos = subject.find(search, pos)) != std::string::npos)
	{
		subject.replace(pos, search.length(), replace);
		pos += replace.length();
	}
	return subject;
}


static std::string download_string(std::string URL)
{
	HINTERNET interwebs = InternetOpenA("Mozilla/5.0", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, NULL);
	HINTERNET urlFile;
	std::string rtn;
	if (interwebs)
	{
		urlFile = InternetOpenUrlA(interwebs, URL.c_str(), NULL, NULL, NULL, NULL);
		if (urlFile)
		{
			char buffer[2000];
			DWORD bytesRead;
			do
			{
				InternetReadFile(urlFile, buffer, 2000, &bytesRead);
				rtn.append(buffer, bytesRead);
				memset(buffer, 0, 2000);
			} while (bytesRead);
			InternetCloseHandle(interwebs);
			InternetCloseHandle(urlFile);
			std::string p = replace_all(rtn, "|n", "\r\n");
			return p;
		}
	}
	InternetCloseHandle(interwebs);
	std::string p = replace_all(rtn, "|n", "\r\n");
	return p;
}


auto getgc(lua_State* state) -> int
{
	bool full = false;

	if (lua_gettop(state) > 0 && lua_type(state, 1) == LUA_TBOOLEAN)
		full = lua_toboolean(state, 1);

	lua_newtable(state);

	auto cur_page = state->global->allgcopages;
	int idx{};

	while (cur_page)
	{
		char* start = 0;
		char* end = 0;
		auto block = 0;
		auto size = 0;

		luaM_getpagewalkinfo(cur_page, &start, &end, &block, &size);

		for (auto pos = start; pos != end; pos += size)
		{
			const auto gco = reinterpret_cast<GCObject*>(pos);

			if (gco->gch.tt == LUA_TFUNCTION || ((gco->gch.tt == LUA_TTABLE || gco->gch.tt == LUA_TUSERDATA) && full))
			{

				state->top->value.gc = gco;
				state->top->tt = gco->gch.tt;
				state->top++;

				lua_rawseti(state, -2, ++idx);
			}
		}

		cur_page = cur_page->listnext;
	}

	return 1;
}

auto httpget(lua_State* rl) -> int
{
	luaL_checktype(rl, 2, LUA_TSTRING);

	double oofjgubqjulniz = 27474;
	double fmfzkqrycpvsu = 17683;
	bool tyylwkmbovrsgv = false;
	std::string tsbvnqqhpgid = "ylxllqtlqivyiewppdspxwruqzxrezykbvzwlqfynjytyxcrzaht";
	int lmtvjnprifq = 603;

	auto url = lua_tostring(rl, 2);

	std::string rblygbzzty = "jqxnrabtfncjfsywhavzxfxzygbjertfwcktutqzpnjn";
	double yhweysv = 12520;
	bool bvwxizeshxiuiu = false;
	bool uduwelfuwiko = true;
	bool xeijpbtmf = false;
	double hzpbonibqgawg = 26229;
	std::string zpqodpf = "aimmzefnfuddlmdfltqiorhnhefvfghzbzxkxluqxymnkxcnzenhrkmpnolzivtpmorzvlakhxswwzvauzw";
	if (false != false) {
		int bewak;
		for (bewak = 85; bewak > 0; bewak--) {
			continue;
		}
	}

	lua_pushstring(rl, download_string(url).c_str());
	return 1;
}



auto loadstring(lua_State* rl) -> int
{
	size_t l = 0;
	auto s = luaL_checklstring(rl, 1, &l);
	ENV::Execute((uintptr_t)rl, std::string(s, l));

	lua_pushnil(rl);
	lua_insert(rl, -2);
	return 2;
}

auto GetObjects(lua_State* rl) -> int
{
	luaL_checktype(rl, 2, LUA_TSTRING);
	std::string asset = lua_tostring(rl, 2);

	lua_getglobal(rl, "game");
	lua_getfield(rl, -1, "GetService");
	lua_pushvalue(rl, -2);
	lua_pushstring(rl, "InsertService");
	lua_call(rl, 2, 1);

	lua_getfield(rl, -1, "LoadLocalAsset");
	lua_pushvalue(rl, -2);
	lua_pushstring(rl, asset.data());
	lua_call(rl, 2, 1);

	lua_createtable(rl, 0, 0);
	lua_pushvalue(rl, -2);
	lua_rawseti(rl, -2, 1);

	return 1;
}


const auto RaiseEventInvocation = reinterpret_cast<void(__fastcall*)
	(uintptr_t * inst, uintptr_t * descriptor, Variant * args, RemoteEventInvocationTargetOptions * options)>
	(0x13BE220);

inline uintptr_t Owner, Signal;

void FuckYouRoblox() {
	RemoteEventInvocationTargetOptions options;
	Variant args;

	options.target = nullptr;
	options.isExcludeTarget = OnlyTarget;

	//blowupdeleter();
	RaiseEventInvocation(reinterpret_cast<uintptr_t*>(Owner), reinterpret_cast<uintptr_t*>(Signal), &args, &options);

	//RBX::Print(0, "[epicz] Owner >> %p", Owner);
	//RBX::Print(0, "[epicz] Signal >> %p", Signal);
}

int ReplicateSignal(lua_State* L) {
	luaL_checktype(L, 1, LUA_TUSERDATA);
	if (strcmp(luaL_typename(L, 1), xorstr_("RBXScriptSignal")) != 0)
	{
		luaL_typeerror(L, 1, xorstr_("RBXScriptSignal"));
	}

	//	blowupdeleter();

	uintptr_t A = *reinterpret_cast<uintptr_t*>(lua_touserdata(L, 1));

	Signal = *(uintptr_t*)(A);
	Owner = *(uintptr_t*)(A + 0x18);

	std::thread(FuckYouRoblox).detach();
	return 0;
}



auto dangerous_function(lua_State* L) -> int
{
	lua_pushboolean(L, false);
	lua_pushstring(L, "Disabled for security reasons.");
	return 2;
}

auto namecall_hook(lua_State* L) -> int
{
	auto state = (__int64)L;
	uintptr_t userdata = *reinterpret_cast<uintptr_t*>(state + 120);
	int level = *reinterpret_cast<uintptr_t*>(userdata + 0x30);

	if (L->namecall && level >= 3)
	{
		const char* data = L->namecall->data;

		if (!strcmp(data, "HttpGet") || !strcmp(data, "HttpGetAsync"))
		{
			return httpget(L);
		}

		if (!strcmp(data, "GetObjects") || !strcmp(data, "GetObjectsAsync"))
		{
			return GetObjects(L);
		}

		for (unsigned int i = 0; i < dangerous_functions.size(); i++) {
			if (!strcmp(data, dangerous_functions[i])) {
				lua_pushboolean(L, false);
				lua_pushstring(L, "Disabled for security reasons.");
				return 2;
			}
		}
	}

	return reinterpret_cast<__int64(__fastcall*)(__int64)>(old_namecall)((__int64)L);
}

auto index_hook(lua_State* L) -> int
{
	auto state = (__int64)L;
	uintptr_t userdata = *reinterpret_cast<uintptr_t*>(state + 120);
	int level = *reinterpret_cast<uintptr_t*>(userdata + 0x30);

	if (lua_isstring(L, 2) && level >= 3)
	{
		const char* data = luaL_checkstring(L, 2);

		if (!strcmp(data, "HttpGet") || !strcmp(data, "HttpGetAsync"))
		{
			lua_getglobal(L, "HttpGet");
			return 1;
		}

		if (!strcmp(data, "GetObjects") || !strcmp(data, "GetObjectsAsync"))
		{
			lua_getglobal(L, "GetObjects");
			return 1;
		}

		for (unsigned int i = 0; i < dangerous_functions.size(); i++) {
			if (!strcmp(data, dangerous_functions[i])) {
				lua_pushcclosure(L, dangerous_function, NULL, 0);
				return 1;
			}
		}
	}

	return reinterpret_cast<__int64(__fastcall*)(__int64)>(old_index)((__int64)L);
}

auto getttenv(lua_State* rl) -> int
{
	luaL_checktype(rl, 1, LUA_TTHREAD);
	lua_State* ls = (lua_State*)lua_topointer(rl, 1);
	Table* tab = hvalue(luaA_toobject(ls, LUA_GLOBALSINDEX));

	sethvalue(rl, rl->top, tab);
	rl->top++;

	return 1;
}


namespace Handler
{
	static std::map<Closure*, lua_CFunction> cfunction_map = {};

	static int cfunction_handler(lua_State* rl)
	{
		auto found = cfunction_map.find(curr_func(rl));

		if (found != cfunction_map.end())
		{
			return found->second(rl);
		}
		return 0;
	}


	static lua_CFunction get(Closure* cl)
	{
		return cfunction_map[cl];
	}


	static void set(Closure* cl, lua_CFunction cf)
	{
		cfunction_map[cl] = cf;
	}


	static void push(lua_State* rl, lua_CFunction fn, const char* debugname, int nup)
	{
		lua_pushcclosurek(rl, cfunction_handler, debugname, nup, 0);
		Closure* closure = *reinterpret_cast<Closure**>(index2addr(rl, -1));
		cfunction_map[closure] = fn;
	}

	static void push_newcc(lua_State* rl, lua_CFunction fn, const char* debugname, int nup, lua_Continuation count)
	{
		lua_pushcclosurek(rl, cfunction_handler, debugname, nup, count);
		Closure* closure = *reinterpret_cast<Closure**>(index2addr(rl, -1));
		cfunction_map[closure] = fn;
	}


	namespace wraps
	{
		static Closure* get(Closure* c)
		{
			return newcclosure_map.find(c)->second;
		}

		static void set(Closure* c, Closure* l)
		{
			newcclosure_map[c] = l;
		}
	}
}


auto newcclosure_handler(lua_State* rl) -> int {
	const auto nargs = lua_gettop(rl);
	rl->ci->flags |= LUA_CALLINFO_HANDLE;
	void* real_closure = reinterpret_cast<void*>(newcclosure_map.find(clvalue(rl->ci->func))->second);

	if (real_closure == nullptr)
		return 0;

	rl->top->value.p = real_closure;
	rl->top->tt = LUA_TFUNCTION;
	rl->top++;

	lua_insert(rl, 1);

	const char* error = nullptr;
	rl->baseCcalls++;
	const int res = lua_pcall(rl, nargs, LUA_MULTRET, 0);
	rl->baseCcalls--;

	if (res == 0 && (rl->status == LUA_YIELD || rl->status == LUA_BREAK))
		return -1;

	return lua_gettop(rl);
}




static type get_type(Closure* cl)
{
	auto cl_type = not_set;

	if (!cl->isC)
		cl_type = l_closure;
	else
	{
		if (reinterpret_cast<lua_CFunction>((lua_CFunction)cl->c.f) == Handler::cfunction_handler)
		{
			if (Handler::get(cl) == newcclosure_handler)
				cl_type = module_c_wrap;
			else
				cl_type = module_c_closure;
		}
		else
			cl_type = roblox_c_closure;
	}

	return cl_type;
}

std::string random_str(int length) {
	static std::string charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	std::string result;
	result.resize(length);

	srand(time(NULL));
	for (int i = 0; i < length; i++)
		result[i] = charset[rand() % charset.length()];

	return result;
}


static int hookfunction(lua_State* rl)
{
	luaL_checktype(rl, 1, LUA_TFUNCTION);
	luaL_checktype(rl, 2, LUA_TFUNCTION);

	const auto cl1 = clvalue(index2addr(rl, 1));
	const auto cl2 = clvalue(index2addr(rl, 2));
	int nups1 = cl1->nupvalues;
	int nups2 = cl2->nupvalues;

	lua_pushvalue(rl, 1);
	lua_setfield(rl, LUA_REGISTRYINDEX, random_str(32).c_str());

	if (get_type(cl1) == roblox_c_closure && get_type(cl2) == roblox_c_closure)
	{
		if (nups1 >= nups2)
		{
			lua_clonecfunction(rl, 1);

			cl1->c.f = (lua_CFunction)cl2->c.f;
			cl1->c.cont = (lua_Continuation)cl2->c.cont;
			cl1->env = (Table*)cl2->env;

			for (int i = 0; i < nups2; i++)
				setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
		}
		else
			luaL_error(rl, "Too many upvalues");
	}

	else if (get_type(cl1) == module_c_closure && get_type(cl2) == module_c_closure)
	{
		if (nups1 >= nups2)
		{
			lua_clonecfunction(rl, 1);
			Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));

			Handler::set(cl1, Handler::get(cl2));
			cl1->c.cont = (lua_Continuation)cl2->c.cont;
			cl1->env = (Table*)cl2->env;

			for (int i = 0; i < nups2; i++)
				setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
		}
		else
			luaL_error(rl, "Too many upvalues");
	}

	else if (get_type(cl1) == module_c_wrap && get_type(cl2) == module_c_wrap)
	{
		lua_clonecfunction(rl, 1);
		Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));

		Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(cl1));
		Handler::wraps::set(cl1, Handler::wraps::get(cl2));

		cl1->env = (Table*)cl2->env;
	}

	else if (get_type(cl1) == l_closure && get_type(cl2) == l_closure)
	{
		if (nups1 >= nups2)
		{
			lua_clonefunction(rl, 1);

			cl1->l.p = (Proto*)cl2->l.p;
			cl1->env = (Table*)cl2->env;

			for (int i = 0; i < nups2; i++)
				setobj2n(rl, &cl1->l.uprefs[i], &cl2->l.uprefs[i]);
		}
		else
			luaL_error(rl, "Too many upvalues");
	}

	else if (get_type(cl1) == roblox_c_closure && get_type(cl2) == module_c_closure)
	{
		if (nups1 >= nups2)
		{
			lua_clonecfunction(rl, 1);

			Handler::set(cl1, Handler::get(cl2));

			cl1->c.f = (lua_CFunction)cl2->c.f;
			cl1->c.cont = (lua_Continuation)cl2->c.cont;
			cl1->env = (Table*)cl2->env;

			for (int i = 0; i < nups2; i++)
				setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
		}
		else
			luaL_error(rl, "Too many upvalues");
	}

	else if (get_type(cl1) == roblox_c_closure && get_type(cl2) == module_c_wrap)
	{
		lua_clonecfunction(rl, 1);

		Handler::set(cl1, Handler::get(cl2));
		Handler::wraps::set(cl1, Handler::wraps::get(cl2));

		cl1->c.f = (lua_CFunction)cl2->c.f;
		cl1->c.cont = (lua_Continuation)cl2->c.cont;
		cl1->env = (Table*)cl2->env;
	}

	else if (get_type(cl1) == roblox_c_closure && get_type(cl2) == l_closure)
	{
		lua_clonecfunction(rl, 1);
		lua_ref(rl, 2);

		cl1->c.f = (lua_CFunction)Handler::cfunction_handler;
		Handler::set(cl1, newcclosure_handler);
		Handler::wraps::set(cl1, cl2);
	}

	else if (get_type(cl1) == module_c_closure && get_type(cl2) == roblox_c_closure)
	{
		if (nups1 >= nups2)
		{
			lua_clonecfunction(rl, 1);
			Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));

			cl1->env = (Table*)cl2->env;
			cl1->c.f = (lua_CFunction)cl2->c.f;
			cl1->c.cont = (lua_Continuation)cl2->c.cont;

			for (int i = 0; i < nups2; i++)
				setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
		}
		else
			luaL_error(rl, "Too many upvalues");
	}

	else if (get_type(cl1) == module_c_closure && get_type(cl2) == module_c_wrap)
	{
		lua_clonecfunction(rl, 1);
		Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));

		Handler::set(cl1, newcclosure_handler);
		Handler::wraps::set(cl1, cl2);
	}

	else if (get_type(cl1) == module_c_closure && get_type(cl2) == l_closure)
	{
		lua_clonecfunction(rl, 1);
		Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));
		lua_ref(rl, 2);

		Handler::set(cl1, newcclosure_handler);
		Handler::wraps::set(cl1, cl2);
	}

	else if (get_type(cl1) == module_c_wrap && get_type(cl2) == roblox_c_closure)
	{
		if (nups1 >= nups2)
		{
			lua_clonecfunction(rl, 1);
			Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));
			Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(cl1));

			cl1->env = (Table*)cl2->env;
			cl1->c.f = (lua_CFunction)cl2->c.f;
			cl1->c.cont = (lua_Continuation)cl2->c.cont;

			for (int i = 0; i < nups2; i++)
				setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
		}
		else
			luaL_error(rl, "Too many upvalues");
	}

	else if (get_type(cl1) == module_c_wrap && get_type(cl2) == module_c_closure)
	{
		if (nups1 >= nups2)
		{
			lua_clonecfunction(rl, 1);
			Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));
			Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(cl1));

			Handler::set(cl1, Handler::get(cl2));

			cl1->env = (Table*)cl2->env;
			cl1->c.cont = (lua_Continuation)cl2->c.cont;

			for (int i = 0; i < nups2; i++)
				setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
		}
		else
			luaL_error(rl, "Too many upvalues");
	}

	else if (get_type(cl1) == module_c_wrap && get_type(cl2) == l_closure)
	{
		lua_clonecfunction(rl, 1);
		Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));
		Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(cl1));

		lua_ref(rl, 2);
		Handler::wraps::set(cl1, cl2);
	}

	else if (get_type(cl1) == l_closure && (get_type(cl2) == roblox_c_closure || get_type(cl2) == module_c_closure))
	{
		lua_clonefunction(rl, 1);
		const auto& spoof = Luau::compile("local f = function() end; return f(...); ");
		luau_load(rl, cl1->l.p->source->data, spoof.c_str(), spoof.size(), 0);

		Closure* clspoof = clvalue(index2addr(rl, -1));
		setobj(rl, &clspoof->l.p->k[0], index2addr(rl, 2));
		clspoof->l.p->linedefined = (__int64)cl1->l.p->linedefined;
		cl1->l.p = (Proto*)clspoof->l.p;

		lua_pop(rl, 1);
	}

	else if (get_type(cl1) == l_closure && get_type(cl2) == module_c_wrap)
	{
		const Closure* l = Handler::wraps::get(cl2);

		if (nups1 >= l->nupvalues)
		{
			lua_clonefunction(rl, 1);

			cl1->env = (Table*)l->env;
			cl1->l.p = (Proto*)l->l.p;

			for (int i = 0; i < l->nupvalues; i++)
				setobj2n(rl, &cl1->l.uprefs[i], &l->l.uprefs[i]);
		}
		else
			luaL_error(rl, "Too many upvalues");
	}
	else
		luaL_error(rl, "Failed to hook");

	return 1;
}

auto get_workspace() -> std::filesystem::path
{
	static const auto workspace_path = std::filesystem::current_path() / "workspace";
	std::filesystem::create_directories(workspace_path);
	return workspace_path;
}


auto sanitize(std::filesystem::path path) -> std::filesystem::path
{
	const auto workspace_path = get_workspace();
	const auto sanitized_path = std::filesystem::weakly_canonical(workspace_path / path);

	bool contains_blacklisted_ext = false;
	const char* blacklisted_exts[] = { ".exe", ".scr", ".bat", ".com", ".csh",".msi", ".vb", ".vbs", ".vbe", ".ws", ".wsf", ".wsh", ".ps1", ".py" };

	for (const auto blacklisted_ext : blacklisted_exts)
	{
		if (sanitized_path.string().contains(blacklisted_ext))
			contains_blacklisted_ext = true;
	}

	return (!sanitized_path.string().starts_with(workspace_path.string()) || contains_blacklisted_ext) ? std::filesystem::path() : sanitized_path;
}

auto read_file(lua_State* L) -> int
{
	luaL_stackcheck(L, 1, 1, luaL_checktype(L, 1, LUA_TSTRING););

	const auto file_path = sanitize(lua_tostring(L, 1));
	if (!std::filesystem::exists(file_path))
	{
		luaL_error(L, "file \"%s\" does not exist", file_path);
		return 0;
	}

	std::ifstream file_stream(file_path, std::ios::binary);
	if (!file_stream.is_open())
	{
		luaL_error(L, "unable to open \"%s\"", file_path);
		return 0;
	}

	const auto content = std::string(std::istreambuf_iterator<char>(file_stream), std::istreambuf_iterator<char>());
	file_stream.close();
	lua_pushlstring(L, content.c_str(), content.size());
	return 1;
}

auto list_files(lua_State* L) -> int
{
	luaL_stackcheck(L, 1, 1, luaL_checktype(L, 1, LUA_TSTRING););

	const auto folder_path = sanitize(lua_tostring(L, 1));
	if (!std::filesystem::exists(folder_path))
		luaL_error(L, "folder \"%s\" does not exist", folder_path);
	lua_newtable(L);

	int n = 0;
	for (auto& entry : std::filesystem::directory_iterator(folder_path))
	{
		lua_pushstring(L, entry.path().string().c_str());
		lua_rawseti(L, -2, ++n);
	}

	return 1;
}

int write_file(lua_State* L)
{
	luaL_checktype(L, 1, LUA_TSTRING);
	luaL_checktype(L, 2, LUA_TSTRING);

	const auto file_path = sanitize(lua_tostring(L, 1));
	const std::string content = lua_tostring(L, 2);

	std::filesystem::path path(file_path);
	std::filesystem::path dir = path.parent_path();

	if (!std::filesystem::exists(dir))
	{
		std::error_code ec;
		if (!std::filesystem::create_directories(dir, ec))
		{
			luaL_error(L, "Failed to create directory: \"%s\"", dir.string().c_str());
			return 0;
		}
	}

	std::ofstream file_stream(file_path, std::ios::binary);
	if (!file_stream.is_open())
	{
		luaL_error(L, "Unable to open \"%s\"", file_path.c_str());
		return 0;
	}

	file_stream.write(content.c_str(), content.size());

	return 0;
}


int make_folder(lua_State* L)
{
	luaL_stackcheck(L, 1, 1, luaL_checktype(L, 1, LUA_TSTRING););
	std::filesystem::create_directories(sanitize(lua_tostring(L, 1)));
	return 0;
}

int append_file(lua_State* L)
{
	luaL_stackcheck(L, 2, 2, luaL_checktype(L, 1, LUA_TSTRING););
	luaL_checktype(L, 2, LUA_TSTRING);

	const auto file_path = sanitize(lua_tostring(L, 1));
	if (!std::filesystem::exists(file_path))
	{
		luaL_error(L, "file \"%s\" does not exist", file_path);
		return 0;
	}

	std::ofstream file_stream(file_path, std::ios::binary | std::ios::app);
	if (!file_stream.is_open())
	{
		luaL_error(L, "unable to open \"%s\"", file_path);
		return 0;
	}

	std::string content = lua_tostring(L, 2);
	file_stream.write(content.c_str(), content.size());

	return 0;
}

int is_file(lua_State* L)
{
	luaL_stackcheck(L, 1, 1, luaL_checktype(L, 1, LUA_TSTRING););
	lua_pushboolean(L, std::filesystem::is_regular_file(sanitize(lua_tostring(L, 1))));
	return 1;
}

int is_folder(lua_State* L)
{
	luaL_stackcheck(L, 1, 1, luaL_checktype(L, 1, LUA_TSTRING););
	lua_pushboolean(L, std::filesystem::is_directory(sanitize(lua_tostring(L, 1))));
	return 1;
}

int del_file(lua_State* L)
{
	luaL_stackcheck(L, 1, 1, luaL_checktype(L, 1, LUA_TSTRING););

	const auto file_path = sanitize(lua_tostring(L, 1));
	if (!std::filesystem::exists(file_path))
	{
		luaL_error(L, "file \"%s\" does not exist", file_path);
		return 0;
	}

	if (!std::filesystem::remove(sanitize(file_path)))
		luaL_error(L, "failed to delete \"%s\"", file_path);

	return 0;
}

int del_folder(lua_State* L)
{
	luaL_stackcheck(L, 1, 1, luaL_checktype(L, 1, LUA_TSTRING););

	const auto folder_path = sanitize(lua_tostring(L, 1));
	if (!std::filesystem::exists(folder_path))
	{
		luaL_error(L, "folder \"%s\" does not exist", folder_path);
		return 0;
	}

	if (!std::filesystem::remove_all(sanitize(folder_path)))
		luaL_error(L, "failed to delete \"%s\"", folder_path);

	return 0;
}

int load_file(lua_State* L)
{
	const std::string file_path = luaL_checkstring(L, 1);
	const std::filesystem::path sanitized_path = sanitize(std::filesystem::path(file_path));

	if (!std::filesystem::exists(sanitized_path))
	{
		luaL_error(L, "file \"%s\" does not exist", sanitized_path.string().c_str());
		return 0;
	}

	std::ifstream file_stream(sanitized_path, std::ios::binary);
	if (!file_stream.is_open())
	{
		luaL_error(L, "unable to open \"%s\"", sanitized_path.string().c_str());
		return 0;
	}

	std::string content((std::istreambuf_iterator<char>(file_stream)), std::istreambuf_iterator<char>());
	file_stream.close();

	ENV::Execute((uintptr_t)L, content.c_str());



	return 1;
}

int MessageBoxFunc(lua_State* L)
{
	auto Contents = lua_tostring(L, 1);
	auto Title = lua_tostring(L, 2);
	auto Flags = lua_tonumber(L, 3);

	auto Result = MessageBoxA(NULL, Contents.c_str(), Title.c_str(), Flags);

	lua_pushnumber(L, Result);
	return 1;
}
int isrbxactive(lua_State* L)
{
	lua_pushboolean(L, GetForegroundWindow() == GetCurrentProcess());
	return 1;
}



auto clonefunction(lua_State* rl) -> int
{
	luaL_checktype(rl, 1, LUA_TFUNCTION);

	switch (get_type(clvalue(index2addr(rl, 1))))
	{
	case roblox_c_closure:
		lua_clonecfunction(rl, 1);
		break;
	case module_c_closure:
		lua_clonecfunction(rl, 1);
		Handler::set(clvalue(index2addr(rl, -1)), Handler::get(clvalue(index2addr(rl, 1))));
		break;
	case module_c_wrap:
		lua_clonecfunction(rl, 1);
		Handler::set(clvalue(index2addr(rl, -1)), Handler::get(clvalue(index2addr(rl, 1))));
		Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(clvalue(index2addr(rl, 1))));
		break;
	case l_closure:
		lua_clonefunction(rl, 1);
		break;
	}

	return 1;
}


int newcclosure_cont(lua_State* rl, int status) {
	if (!status) return lua_gettop(rl);
	luaL_error(rl, lua_tolstring(rl, -1, nullptr));
	return 0;
}



auto newcclosure(lua_State* rl) -> int
{
	luaL_checktype(rl, 1, LUA_TFUNCTION);

	if (lua_iscfunction(rl, 1))
		luaL_error(rl, "L closure expected.");

	auto tval1 = (TValue*)index2addr(rl, 1);

	lua_ref(rl, 1);
	Handler::push_newcc(rl, newcclosure_handler, 0, 0, newcclosure_cont);
	Closure* catched = clvalue(index2addr(rl, -1));
	function_array.push_back(catched);

	newcclosure_map[catched] = &tval1->value.gc->cl;

	return 1;
}


auto debug_getconstants(lua_State* L) -> int
{
	ARG_CHECK(L, 1, 1);

	if (!lua_isfunction(L, 1) && !lua_isnumber(L, 1)) {
		luaL_argerror(L, 1, "function or number expected");
		return 0;
	}

	if (lua_isnumber(L, 1)) {
		lua_Debug ar;

		if (!lua_getinfo(L, lua_tonumber(L, 1), "f", &ar)) {
			luaL_error(L, "level out of range");
			return 0;
		}

		if (lua_iscfunction(L, -1)) {
			luaL_argerror(L, 1, "stack points to a C closure, Lua function expected");
			return 0;
		}
	}
	else {
		lua_pushvalue(L, 1);

		if (lua_iscfunction(L, -1)) {
			luaL_argerror(L, 1, "Lua function expected");
			return 0;
		}
	}

	Closure* cl = (Closure*)lua_topointer(L, -1);
	Proto* p = cl->l.p;
	TValue* k = p->k;

	lua_newtable(L);

	for (std::intptr_t i = 0; i < p->sizek; i++) {
		TValue* tval = &(k[i]);

		if (tval->tt == LUA_TFUNCTION) {
			TValue* i_o = (L->top);
			setnilvalue(i_o);
			L->top++;
		}
		else {
			TValue* i_o = (L->top);
			i_o->value = tval->value;
			i_o->tt = tval->tt;
			L->top++;
		}

		lua_rawseti(L, -2, (i + 1));
	}

	return 1;
}

auto debug_getconstant(lua_State* L) -> int {
	ARG_CHECK(L, 2, 2);

	if (!lua_isfunction(L, 1) && !lua_isnumber(L, 1)) {
		luaL_argerror(L, 1, "function or number expected");
		return 0;
	}

	const std::intptr_t index = luaL_checkinteger(L, 2);

	if (lua_isnumber(L, 1)) {
		lua_Debug ar;

		if (!lua_getinfo(L, lua_tonumber(L, 1), "f", &ar)) {
			luaL_error(L, "level out of range");
			return 0;
		}

		if (lua_iscfunction(L, -1)) {
			luaL_argerror(L, 1, "stack points to a C closure, Lua function expected");
			return 0;
		}
	}
	else {
		lua_pushvalue(L, 1);

		if (lua_iscfunction(L, -1)) {
			luaL_argerror(L, 1, "Lua function expected");
			return 0;
		}
	}

	Closure* cl = (Closure*)lua_topointer(L, -1);
	Proto* p = cl->l.p;
	TValue* k = p->k;

	if (!index) {
		luaL_argerror(L, 1, "constant index starts at 1");
		return 0;
	}

	if (index > p->sizek) {
		luaL_argerror(L, 1, "constant index is out of range");
		return 0;
	}

	TValue* tval = &(k[index - 1]);

	if (tval->tt == LUA_TFUNCTION) {
		TValue* i_o = (L->top);
		setnilvalue(i_o);
		L->top++;
	}
	else {
		TValue* i_o = (L->top);
		i_o->value = tval->value;
		i_o->tt = tval->tt;
		L->top++;
	}

	return 1;
}

auto debug_setconstant(lua_State* L) -> int {
	ARG_CHECK(L, 3, 3);

	if (!lua_isfunction(L, 1) && !lua_isnumber(L, 1)) {
		luaL_argerror(L, 1, "function or number expected");
		return 0;
	}

	const std::intptr_t index = luaL_checkinteger(L, 2);

	luaL_checkany(L, 3);

	if (lua_isnumber(L, 1)) {
		lua_Debug ar;

		if (!lua_getinfo(L, lua_tonumber(L, 1), "f", &ar)) {
			luaL_error(L, "level out of range");
			return 0;
		}

		if (lua_iscfunction(L, -1)) {
			luaL_argerror(L, 1, "stack points to a C closure, Lua function expected");
			return 0;
		}
	}
	else {
		lua_pushvalue(L, 1);

		if (lua_iscfunction(L, -1)) {
			luaL_argerror(L, 1, "Lua function expected");
			return 0;
		}
	}

	Closure* cl = (Closure*)lua_topointer(L, -1);
	Proto* p = cl->l.p;
	TValue* k = p->k;

	if (!index) {
		luaL_argerror(L, 1, "constant index starts at 1");
		return 0;
	}

	if (index > p->sizek) {
		luaL_argerror(L, 1, "constant index is out of range");
		return 0;
	}

	auto constant = &k[index - 1];

	if (constant->tt == LUA_TFUNCTION)
		return 0;

	const TValue* new_t = luaA_toobject(L, 3);
	constant->tt = new_t->tt;
	constant->value = new_t->value;

	return 0;
}

auto debug_getupvalues(lua_State* L) -> int {
	ARG_CHECK(L, 1, 1);
	if (!lua_isfunction(L, 1) && !lua_isnumber(L, 1)) {
		luaL_argerror(L, 1, "function or number expected");
		return 0;
	}

	if (lua_isnumber(L, 1)) {
		lua_Debug ar;

		if (!lua_getinfo(L, lua_tonumber(L, 1), "f", &ar)) {
			luaL_error(L, "level out of range");
			return 0;
		}
	}
	else
		lua_pushvalue(L, 1);

	Closure* closure = (Closure*)lua_topointer(L, -1);
	TValue* upvalue_table = (TValue*)nullptr;

	lua_newtable(L);

	if (!closure->isC)
		upvalue_table = closure->l.uprefs;
	else if (closure->isC)
		upvalue_table = closure->c.upvals;

	for (std::intptr_t i = 0; i < closure->nupvalues; i++) {
		TValue* upval = (&upvalue_table[i]);
		TValue* top = L->top;

		top->value = upval->value;
		top->tt = upval->tt;
		L->top++;

		lua_rawseti(L, -2, (i + 1));
	}

	return 1;
}

auto debug_getupvalue(lua_State* L) -> int {
	ARG_CHECK(L, 2, 2);
	if (!lua_isfunction(L, 1) && !lua_isnumber(L, 1)) {
		luaL_argerror(L, 1, "function or number expected");
		return 0;
	}

	if (lua_isnumber(L, 1)) {
		lua_Debug ar;

		if (!lua_getinfo(L, lua_tonumber(L, 1), "f", &ar)) {
			luaL_error(L, "level out of range");
			return 0;
		}
	}
	else
		lua_pushvalue(L, 1);

	const std::intptr_t index = luaL_checkinteger(L, 2);

	Closure* closure = (Closure*)lua_topointer(L, -1);
	TValue* upvalue_table = (TValue*)nullptr;

	if (!closure->isC)
		upvalue_table = closure->l.uprefs;
	else if (closure->isC)
		upvalue_table = closure->c.upvals;

	if (!index) {
		luaL_argerror(L, 1, "upvalue index starts at 1");
		return 0;
	}

	if (index > closure->nupvalues) {
		luaL_argerror(L, 1, "upvalue index is out of range");
		return 0;
	}

	TValue* upval = (&upvalue_table[index - 1]);
	TValue* top = L->top;

	top->value = upval->value;
	top->tt = upval->tt;
	L->top++;

	return 1;
}

auto debug_setupvalue(lua_State* L) -> int {
	ARG_CHECK(L, 3, 3);
	if (!lua_isfunction(L, 1) && !lua_isnumber(L, 1)) {
		luaL_argerror(L, 1, "function or number expected");
		return 0;
	}


	const std::intptr_t index = luaL_checkinteger(L, 2);
	luaL_checkany(L, 3);

	if (lua_isnumber(L, 1)) {
		lua_Debug ar;

		if (!lua_getinfo(L, lua_tonumber(L, 1), "f", &ar)) {
			luaL_error(L, "level out of range");
			return 0;
		}
	}
	else
		lua_pushvalue(L, 1);

	Closure* closure = (Closure*)lua_topointer(L, -1);
	const TValue* value = luaA_toobject(L, 3);
	TValue* upvalue_table = (TValue*)nullptr;

	if (!closure->isC)
		upvalue_table = closure->l.uprefs;
	else if (closure->isC)
		upvalue_table = closure->c.upvals;

	if (!index) {
		luaL_argerror(L, 1, "upvalue index starts at 1");
		return 0;
	}

	if (index > closure->nupvalues) {
		luaL_argerror(L, 1, "upvalue index is out of range");
		return 0;
	}

	TValue* upvalue = (&upvalue_table[index - 1]);

	upvalue->value = value->value;
	upvalue->tt = value->tt;

	luaC_barrier(L, closure, value);
	lua_pushboolean(L, true);

	return 1;
}

auto debug_getprotos(lua_State* L) -> int {
	ARG_CHECK(L, 1, 1, luaL_checktype(L, 1, LUA_TFUNCTION););

	if (lua_iscfunction(L, -1)) {
		luaL_argerror(L, 1, "stack points to a C closure, Lua function expected");
		return 0;
	}

	Closure* closure = (Closure*)lua_topointer(L, -1);

	lua_newtable(L);

	Proto* main_proto = closure->l.p;

	for (std::intptr_t i = 0; i < main_proto->sizep; i++) {
		Proto* proto_data = main_proto->p[i];
		Closure* lclosure = luaF_newLclosure(L, proto_data->nups, closure->env, proto_data);

		setclvalue(L, L->top, lclosure);
		L->top++;

		lua_rawseti(L, -2, (i + 1));
	}

	return 1;
}

auto debug_getproto(lua_State* L) -> int {
	ARG_CHECK(L, 2, 3);
	luaL_checktype(L, 2, LUA_TNUMBER);

	bool active = luaL_optboolean(L, 3, false);

	if (lua_isnumber(L, 1)) {
		std::intptr_t level = lua_tointeger(L, 1);

		if (level >= L->ci - L->base_ci || level < 0)
			luaL_argerror(L, 1, "stack level out of range");

		lua_Debug ar;
		lua_getinfo(L, level, "f", &ar);

		if (clvalue(reinterpret_cast<CallInfo*>(L->ci - level)->func)->isC)
			luaL_argerror(L, 1, "stack level to a cclosure, lclosure expected");
	}
	else
		lua_pushvalue(L, 1);

	if (lua_isnumber(L, -1) == FALSE && lua_isfunction(L, -1) == FALSE) {
		luaL_argerror(L, 1, "function or level expected");
		return 0;
	}

	const auto function = clvalue(luaA_toobject(L, -1));

	if (!function->isC) {
		if (active)
			lua_newtable(L);

		const auto index = lua_tointeger(L, 2);

		if (index < 1 || index > function->l.p->sizep)
			luaL_argerror(L, 2, "proto index out of range");

		const auto proto = function->l.p->p[index - 1];

		setclvalue(L, L->top, luaF_newLclosure(L, proto->nups, function->env, proto));
		L->top++;

		if (active)
			lua_rawseti(L, -2, 1);
	}
	else
		luaL_argerror(L, 1, "lclosure expected");

	return 1;
}

auto debug_getstack(lua_State* L) -> int {
	ARG_CHECK(L, 1, 2);
	luaL_checktype(L, 1, LUA_TNUMBER);

	const auto level = lua_tointeger(L, 1);
	const auto index = luaL_optinteger(L, 2, -1);

	if (level >= L->ci - L->base_ci || level < 0)
		luaL_argerror(L, 1, "level out of range");

	const auto frame = reinterpret_cast<CallInfo*>(L->ci - level);
	const auto top = (frame->top - frame->base);

	if (clvalue(frame->func)->isC)
		luaL_argerror(L, 1, "level points to a cclosure, lclosure expected");

	if (index == -1) {
		lua_newtable(L);

		for (std::intptr_t i = 0; i < top; i++) {
			setobj2s(L, L->top, &frame->base[i]);
			L->top++;

			lua_rawseti(L, -2, i + 1);
		}
	}
	else {
		if (index < 1 || index > top)
			luaL_argerror(L, 2, "stack index out of range");

		setobj2s(L, L->top, &frame->base[index - 1]);
		L->top++;
	}
	return 1;
}

auto debug_setstack(lua_State* L) -> int {
	ARG_CHECK(L, 3, 3);
	luaL_checktype(L, 1, LUA_TNUMBER);
	luaL_checktype(L, 2, LUA_TNUMBER);
	luaL_checkany(L, 3);

	const auto level = lua_tointeger(L, 1);
	const auto index = lua_tointeger(L, 2);

	if (level >= L->ci - L->base_ci || level < 0)
		luaL_argerror(L, 1, "level out of range");

	const auto frame = reinterpret_cast<CallInfo*>(L->ci - level);
	const auto top = (frame->top - frame->base);

	if (clvalue(frame->func)->isC)
		luaL_argerror(L, 1, "level points to a cclosure, lclosure expected");

	if (index < 1 || index > top)
		luaL_argerror(L, 2, "stack index out of range");

	setobj2s(L, &frame->base[index - 1], luaA_toobject(L, 3));
	return 0;
}

auto debug_getinfo(lua_State* L) -> int {
	ARG_CHECK(L, 1, 1);
	std::intptr_t level{};
	if (lua_isnumber(L, 1)) {
		level = lua_tointeger(L, 1);
		luaL_argcheck(L, level >= 0, 1, "level can't be negative");
	}
	else if (lua_isfunction(L, 1))
		level = -lua_gettop(L);
	else {
		luaL_argerror(L, 1, "function or level expected");
		return 0;
	}

	lua_Debug ar;
	if (!lua_getinfo(L, level, "sluanf", &ar))
		luaL_argerror(L, 1, "invalid level");

	lua_newtable(L);

	lua_pushstring(L, ar.source);
	lua_setfield(L, -2, "source");

	lua_pushstring(L, ar.short_src);
	lua_setfield(L, -2, "short_src");

	lua_pushvalue(L, 1);
	lua_setfield(L, -2, "func");

	lua_pushstring(L, ar.what);
	lua_setfield(L, -2, "what");

	lua_pushinteger(L, ar.currentline);
	lua_setfield(L, -2, "currentline");

	lua_pushstring(L, ar.name);
	lua_setfield(L, -2, "name");

	lua_pushinteger(L, ar.nupvals);
	lua_setfield(L, -2, "nups");

	lua_pushinteger(L, ar.nparams);
	lua_setfield(L, -2, "numparams");

	lua_pushinteger(L, ar.isvararg);
	lua_setfield(L, -2, "is_vararg");

	return 1;
}

auto debug_getregistry(lua_State* L) -> int
{
	ARG_CHECK(L, 0, 0);
	lua_pushvalue(L, LUA_REGISTRYINDEX);
	return 1;
}



auto iscclosure(lua_State* L) -> int {
	ARG_CHECK(L, 1, 1, luaL_checktype(L, 1, LUA_TFUNCTION););
	lua_pushboolean(L, lua_iscfunction(L, 1));
	return 1;
}

auto islclosure(lua_State* rl) -> int
{
	luaL_checktype(rl, 1, LUA_TFUNCTION);

	lua_pushboolean(rl, lua_isLfunction(rl, 1));
	return 1;
}

auto checkcaller(lua_State* rl) -> int
{
	auto state = (__int64)rl;
	uintptr_t userdata = *reinterpret_cast<uintptr_t*>(state + 120);
	int level = *reinterpret_cast<uintptr_t*>(userdata + 0x30);

	lua_pushboolean(rl, (bool)(level >= 3));
	return 1;
}







int mouse1press(lua_State* rl)
{
	HWND window = FindWindowA(NULL, "Roblox");
	if (GetForegroundWindow() == window)
		mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
	return 0;
}


int mouse1release(lua_State* rl)
{
	HWND window = FindWindowA(NULL, "Roblox");
	if (GetForegroundWindow() == window)
		mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
	return 0;
}


int mouse1click(lua_State* rl)
{
	HWND window = FindWindowA(NULL, "Roblox");
	if (GetForegroundWindow() == window)
		mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
	return 0;
}


int mouse2press(lua_State* rl)
{
	HWND window = FindWindowA(NULL, "Roblox");
	if (GetForegroundWindow() == window)
		mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
	return 0;
}


int mouse2release(lua_State* rl)
{
	HWND window = FindWindowA(NULL, "Roblox");
	if (GetForegroundWindow() == window)
		mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
	return 0;
}


int mouse2click(lua_State* rl)
{
	HWND window = FindWindowA(NULL, "Roblox");
	if (GetForegroundWindow() == window)
		mouse_event(MOUSEEVENTF_RIGHTDOWN | MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
	return 0;
}


int keypress(lua_State* rl)
{
	HWND window = FindWindowA(NULL, "Roblox");
	UINT key = luaL_checkinteger(rl, 1);

	if (GetForegroundWindow() == window)
		keybd_event(0, (BYTE)MapVirtualKeyA(key, MAPVK_VK_TO_VSC), KEYEVENTF_SCANCODE, 0);
	return 0;
}


int iskeydown(lua_State* rl)
{
	luaL_checktype(rl, 1, LUA_TNUMBER);

	UINT key = luaL_checkinteger(rl, 1);

	SHORT state = GetAsyncKeyState(key);
	lua_pushboolean(rl, (bool)((state & 0x8000) != 0));
	return 1;
}


int keyrelease(lua_State* rl)
{
	HWND window = FindWindowA(NULL, "Roblox");
	UINT key = luaL_checkinteger(rl, 1);

	if (GetForegroundWindow() == window)
		keybd_event(0, (BYTE)MapVirtualKeyA(key, MAPVK_VK_TO_VSC), KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP, 0);
	return 0;
}


int mousemoverel(lua_State* rl)
{
	HWND window = FindWindowA(NULL, "Roblox");

	DWORD x = luaL_checkinteger(rl, 1);
	DWORD y = luaL_checkinteger(rl, 2);

	if (GetForegroundWindow() == window)
		mouse_event(MOUSEEVENTF_MOVE, x, y, 0, 0);
	return 0;
}


int mousemoveabs(lua_State* rl)
{
	HWND window = FindWindowA(NULL, "Roblox");

	DWORD x = luaL_checkinteger(rl, 1);
	DWORD y = luaL_checkinteger(rl, 2);

	if (GetForegroundWindow() != window) return 0;

	int width = GetSystemMetrics(SM_CXSCREEN) - 1;
	int height = GetSystemMetrics(SM_CYSCREEN) - 1;

	RECT CRect;
	GetClientRect(GetForegroundWindow(), &CRect);

	POINT Point{ CRect.left, CRect.top };
	ClientToScreen(GetForegroundWindow(), &Point);

	x = (x + (DWORD)Point.x) * (65535 / width);
	y = (y + (DWORD)Point.y) * (65535 / height);

	mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE, x, y, 0, 0);

	return 0;
}


int mousescroll(lua_State* rl)
{
	HWND window = FindWindowA(NULL, "Roblox");
	DWORD scroll_amount = luaL_checkinteger(rl, 1);

	if (GetForegroundWindow() == window)
		mouse_event(MOUSEEVENTF_WHEEL, 0, 0, scroll_amount, 0);
	return 0;
}


auto identifyexecutor(lua_State* rl) -> int
{
	lua_pushstring(rl, "Vectorsploit");
	lua_pushstring(rl, "1.3.3.7");
	return 2;
}


__forceinline static int GetCustomAsset(lua_State* L)
{
	luaL_stackcheck(L, 1, 1, luaL_checktype(L, 1, LUA_TSTRING););

	const std::string FileName = lua_tostring(L, 1);

	const auto FilePath = get_workspace() / FileName;
	const auto AssetPath = std::filesystem::current_path() / xorstr_("content") / FilePath.filename();

	const size_t ContentSize = std::filesystem::file_size(FilePath);
	std::string Result(ContentSize, '\0');

	const auto Future = std::async(std::launch::async, [FileName, FilePath, AssetPath, ContentSize, Result]() -> std::filesystem::path {

		std::ifstream FileStream(FilePath, std::ios::in | std::ios::binary);
		FileStream.read((char*)Result.data(), ContentSize);

		return AssetPath;
		}).get();

	std::ofstream Out(AssetPath, std::ios::out | std::ios::binary);
	Out.write(Result.c_str(), Result.size());
	Out.close();

	lua_pushstring(L, std::format("rbxasset://{}", Future.filename().string()).c_str());
	return 1;
}

int B64Encode(lua_State* L)
{
	luaL_checktype(L, 1, LUA_TSTRING);

	auto Str = lua_tostring(L, 1);

	lua_pushstring(L, base64_encode(Str).c_str());
	return 1;
}

int B64Decode(lua_State* L)
{
	luaL_checktype(L, 1, LUA_TSTRING);

	auto Str = lua_tostring(L, 1);

	lua_pushstring(L, base64_decode(Str).c_str());
	return 1;
}

__forceinline static int SetClipboard(lua_State* L)
{
	luaL_checktype(L, 1, LUA_TSTRING);

	size_t l = 0;
	auto s = luaL_checklstring(L, 1, &l);
	std::string content = std::string(s, l);

	HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, l + 1);
	memcpy(GlobalLock(hMem), content.data(), l);
	GlobalUnlock(hMem);
	OpenClipboard(0);
	EmptyClipboard();
	SetClipboardData(CF_TEXT, hMem);
	CloseClipboard();
	return 0;
}

__forceinline static int GetClipboard(lua_State* L)
{
	OpenClipboard(NULL);
	HANDLE hData = GetClipboardData(CF_TEXT);
	char* pszText = (char*)GlobalLock(hData);
	std::string pszTextCopy(pszText);

	GlobalUnlock(hData);
	CloseClipboard();
	lua_pushstring(L, pszTextCopy.c_str());
	return 1;
}

__forceinline static int SetReadonly(lua_State* L)
{
	luaL_stackcheck(L, 2, 2, luaL_checktype(L, 1, LUA_TTABLE););
	luaL_checktype(L, 2, LUA_TBOOLEAN);

	((Table*)lua_topointer(L, 1))->readonly = lua_toboolean(L, 2);
	return 0;
}

__forceinline static int IsReadonly(lua_State* L)
{
	luaL_stackcheck(L, 1, 1, luaL_checktype(L, 1, LUA_TTABLE););

	lua_pushboolean(L, ((Table*)lua_topointer(L, 1))->readonly);
	return 1;
}

int set_namecall_method(lua_State* L)
{
	ARG_CHECK(L, 1, 1, luaL_checktype(L, 1, LUA_TSTRING););
	L->namecall = tsvalue(luaA_toobject(L, 1));
	return 0;
}

int isluau(lua_State* L) {
	lua_pushboolean(L, true);
	return 1;
}

int setuntouched(lua_State* L) {
	luaL_checktype(L, 1, lua_Type::LUA_TTABLE);
	luaL_checktype(L, 2, lua_Type::LUA_TBOOLEAN);

	lua_setsafeenv(L, 1, lua_toboolean(L, 2));
	return 0;
}


int isuntouched(lua_State* L) {
	luaL_checktype(L, 1, lua_Type::LUA_TTABLE);
	lua_pushboolean(L, static_cast<const Table*>(lua_topointer(L, 1))->safeenv);

	return 1;
}
__forceinline static int GetNilInstances(lua_State* L)
{
	luaL_stackcheck(L, 0, 0);

	struct CInstanceContext
	{
		lua_State* L;
		__int64 n;
	} Context = { L, 0 };

	lua_createtable(L, 0, 0);
	for (lua_Page* Page = L->global->allgcopages; Page;)
	{
		lua_Page* Next{ Page->listnext }; /* Block visit might destroy the page */

		luaM_visitpage(Page, &Context, [](void* Context, lua_Page* Page, GCObject* Gco) -> bool {
			auto GcContext = (CInstanceContext*)Context;
			const auto Type = Gco->gch.tt;

			if (Type == LUA_TUSERDATA)
			{
				TValue* top = GcContext->L->top;
				top->value.p = reinterpret_cast<void*>(Gco);
				top->tt = Type;
				GcContext->L->top++;

				if (!strcmp(luaL_typename(GcContext->L, -1), xorstr_("Instance")))
				{
					lua_getfield(GcContext->L, -1, xorstr_("Parent"));

					const auto NullParent = lua_isnoneornil(GcContext->L, -1);
					if (NullParent)
					{
						lua_pop(GcContext->L, 1);
						GcContext->n++;
						lua_rawseti(GcContext->L, -2, GcContext->n);
					}
					else
						lua_pop(GcContext->L, 2);
				}
				else
					lua_pop(GcContext->L, 1);
			}

			return true;
			}
		);

		Page = Next;
	}
	return 1;
}

auto getrawmetatable(lua_State* L) -> int
{
	luaL_checkany(L, 1);
	if (!lua_getmetatable(L, 1)) lua_pushnil(L);
	return 1;
}

auto setrawmetatable(lua_State* L) -> int
{
	luaL_checkany(L, 1);
	std::intptr_t t = lua_type(L, 2);
	luaL_argcheck(L, t == LUA_TNIL || t == LUA_TTABLE, 2, "nil or table expected");
	lua_settop(L, 2);
	lua_pushboolean(L, lua_setmetatable(L, 1));
	return 1;
}

__forceinline static int GetHui(lua_State* L)
{
	luaL_stackcheck(L, 0, 0);

	lua_getglobal(L, xorstr_("game"));
	lua_getfield(L, -1, xorstr_("GetService"));

	lua_pushvalue(L, -2);
	lua_pushstring(L, xorstr_("CoreGui"));

	lua_pcall(L, 2, 1, 0);
	return 1;
}

__forceinline static int GetInstances(lua_State* L)
{
	luaL_stackcheck(L, 0, 0);

	struct CInstanceContext
	{
		lua_State* L;
		__int64 n;
	} Context = { L, 0 };

	lua_createtable(L, 0, 0);
	for (lua_Page* Page = L->global->allgcopages; Page;)
	{
		lua_Page* Next{ Page->listnext }; /* Block visit might destroy the page */

		luaM_visitpage(Page, &Context, [](void* Context, lua_Page* Page, GCObject* Gco) -> bool {
			auto GcContext = (CInstanceContext*)Context;
			const auto Type = Gco->gch.tt;

			if (Type == LUA_TUSERDATA)
			{
				TValue* top = GcContext->L->top;
				top->value.p = reinterpret_cast<void*>(Gco);
				top->tt = Type;
				GcContext->L->top++;

				if (!strcmp(luaL_typename(GcContext->L, -1), xorstr_("Instance")))
				{
					GcContext->n++;
					lua_rawseti(GcContext->L, -2, GcContext->n);
				}
				else
					lua_pop(GcContext->L, 1);
			}

			return true;
			}
		);

		Page = Next;
	}

	return 1;
}

int lz4compress(lua_State* L) {
	luaL_checktype(L, 1, LUA_TSTRING);
	size_t input_size;
	const char* data = lua_tolstring(L, 1, &input_size); // Correctly get string and its length

	int max_compressed_size = LZ4_compressBound(input_size);
	std::vector<char> out_buffer(max_compressed_size);

	int compressed_size = LZ4_compress_default(data, out_buffer.data(), input_size, max_compressed_size);


	lua_pushlstring(L, out_buffer.data(), compressed_size);
	return 1;
}

int lz4decompress(lua_State* L) {
	luaL_checktype(L, 1, LUA_TSTRING);
	luaL_checktype(L, 2, LUA_TNUMBER);
	size_t compressed_size;
	const char* compressed_data = lua_tolstring(L, 1, &compressed_size);
	int decompressed_size = lua_tointeger(L, 2);

	std::vector<char> decompressed_buffer(decompressed_size);

	int actual_size = LZ4_decompress_safe(compressed_data, decompressed_buffer.data(), compressed_size, decompressed_size);


	lua_pushlstring(L, decompressed_buffer.data(), actual_size);
	return 1;
}

void ENV::RegisterFunctions(lua_State* L) {

	RegisterFunction(L, ReplicateSignal, "ReplicateSignal");
	RegisterFunction(L, ReplicateSignal, "replicatesignal");
	RegisterFunction(L, ReplicateSignal, "Replicatesignal");
	RegisterFunction(L, ReplicateSignal, "replicate_signal");


	RegisterFunction(L, GetInstances, oxorany("getinstances"));
	RegisterFunction(L, GetInstances, oxorany("get_instances"));
	RegisterFunction(L, GetInstances, oxorany("GetInstances"));

	RegisterFunction(L, GetHui, "gethui");
	RegisterFunction(L, GetHui, "get_hui");
	RegisterFunction(L, GetHui, "GetHui");

	RegisterFunction(L, GetNilInstances, oxorany("getnilinstances"));
	RegisterFunction(L, GetNilInstances, oxorany("get_nil_instances"));
	RegisterFunction(L, GetNilInstances, oxorany("GetNilInstances"));

	RegisterFunction(L, getrawmetatable, oxorany("getrawmetatable"));
	RegisterFunction(L, getrawmetatable, oxorany("get_raw_metatable"));
	RegisterFunction(L, getrawmetatable, oxorany("GetRawMetatable"));

	RegisterFunction(L, setrawmetatable, oxorany("setrawmetatable"));
	RegisterFunction(L, setrawmetatable, oxorany("set_raw_metatable"));
	RegisterFunction(L, setrawmetatable, oxorany("SetRawMetatable"));


	RegisterFunction(L, setuntouched, "setuntouched");
	RegisterFunction(L, isuntouched, "isuntouched");

	RegisterFunction(L, isluau, "isluau");

	RegisterFunction(L, set_namecall_method, oxorany("setnamecallmethod"));
	RegisterFunction(L, set_namecall_method, oxorany("set_namecall_method"));
	RegisterFunction(L, set_namecall_method, oxorany("SetNamecallMethod"));

	RegisterFunction(L, SetReadonly, oxorany("setreadonly"));
	RegisterFunction(L, SetReadonly, oxorany("set_readonly"));
	RegisterFunction(L, SetReadonly, oxorany("SetReadonly"));

	RegisterFunction(L, IsReadonly, oxorany("isreadonly"));
	RegisterFunction(L, IsReadonly, oxorany("is_readonly"));
	RegisterFunction(L, IsReadonly, oxorany("IsReadonly"));

	RegisterFunction(L, lz4compress, "lz4compress");
	RegisterFunction(L, lz4decompress, "lz4decompress");

	RegisterFunction(L, GetCustomAsset, "getcustomasset");

	RegisterFunction(L, GetCustomAsset, "get_custom_asset");

	RegisterFunction(L, GetCustomAsset, "GetCustomAsset");

	RegisterFunction(L, GetClipboard, oxorany("getclipboard"));
	RegisterFunction(L, GetClipboard, oxorany("get_clipboard"));
	RegisterFunction(L, GetClipboard, oxorany("GetClipboard"));

	RegisterFunction(L, SetClipboard, oxorany("setclipboard"));
	RegisterFunction(L, SetClipboard, oxorany("set_clipboard"));
	RegisterFunction(L, SetClipboard, oxorany("SetClipboard"));
	RegisterFunction(L, SetClipboard, oxorany("toclipboard"));
	RegisterFunction(L, SetClipboard, oxorany("setrbxclipboard"));
	RegisterFunction(L, SetClipboard, oxorany("to_clipboard"));
	RegisterFunction(L, SetClipboard, oxorany("ToClipboard"));

	RegisterFunction(L, identifyexecutor, "identifyexecutor");
	RegisterFunction(L, identifyexecutor, "getexecutorname");

	RegisterFunction(L, mouse1press, "mouse1press");
	RegisterFunction(L, mouse1press, "Mouse1Press");
	RegisterFunction(L, mouse2press, "mouse2press");
	RegisterFunction(L, mouse2press, "Mouse2Press");
	RegisterFunction(L, mouse1release, "mouse1release");
	RegisterFunction(L, mouse1release, "Mouse1Release");
	RegisterFunction(L, mouse2release, "mouse2release");
	RegisterFunction(L, mouse2release, "Mouse2Release");
	RegisterFunction(L, mouse1click, "mouse1click");
	RegisterFunction(L, mouse1click, "Mouse1Click");
	RegisterFunction(L, mouse2click, "mouse2click");
	RegisterFunction(L, mouse2click, "Mouse2Click");
	RegisterFunction(L, mousescroll, "mousescroll");
	RegisterFunction(L, mousescroll, "MouseScroll");
	RegisterFunction(L, mousemoverel, "mousemoverel");
	RegisterFunction(L, mousemoverel, "MouseMoveRel");
	RegisterFunction(L, mousemoverel, "MouseMoveRelative");
	RegisterFunction(L, mousemoveabs, "mousemoveabs");
	RegisterFunction(L, mousemoveabs, "MouseMoveABS");
	RegisterFunction(L, mousemoveabs, "MouseMoveAbs");
	RegisterFunction(L, keypress, "keypress");
	RegisterFunction(L, keypress, "KeyPress");
	RegisterFunction(L, keyrelease, "keyrelease");
	RegisterFunction(L, keyrelease, "KeyRelease");
	RegisterFunction(L, iskeydown, "iskeydown");
	RegisterFunction(L, iskeydown, "IsKeyDown");
	RegisterFunction(L, iskeydown, "KeyDown");









	RegisterFunction(L, isrbxactive, "isrbxactive");
	RegisterFunction(L, MessageBoxFunc, oxorany("messagebox"));
	RegisterFunction(L, isrbxactive, "isgameactive");
	RegisterFunction(L, isrbxactive, "iswindowactive");

	RegisterFunction(L, clonefunction, "clonefunction");
	RegisterFunction(L, clonefunction, "clonefunc");


	RegisterFunction(L, MessageBoxFunc, oxorany("Messagebox"));

	RegisterFunction(L, GetGenv, "getgenv");
	RegisterFunction(L, getttenv, "gettenv");
	RegisterFunction(L, getreg, "getreg");
	RegisterFunction(L, getrenv, "getrenv");
	RegisterFunction(L, getgc, "getgc");
	RegisterFunction(L, getsenv, "getsenv");

	RegisterFunction(L, hookfunction, "hookfunction");
	RegisterFunction(L, hookfunction, "replaceclosure");
	RegisterFunction(L, hookfunction, "hookfunc");

	RegisterFunction(L, loadstring, "loadstring");
	RegisterFunction(L, loadstring, "Loadstring");
	RegisterFunction(L, loadstring, "LoadString");

	//RegisterFunction(L, newcclosure, "newcclosure");
	//RegisterFunction(L, newcclosure, "new_c_closure");

	RegisterFunction(L, iscclosure, "iscclosure");
	RegisterFunction(L, iscclosure, "is_c_closure");

	RegisterFunction(L, islclosure, "islclosure");
	RegisterFunction(L, islclosure, "is_l_closure");

	RegisterFunction(L, checkcaller, "checkcaller");


	RegisterFunction(L, hookfunction, "hookfunction");
	RegisterFunction(L, hookfunction, "replaceclosure");
	RegisterFunction(L, hookfunction, "hookfunc");


	RegisterFunction(L, read_file, "readfile");
	RegisterFunction(L, read_file, "ReadFile");
	RegisterFunction(L, read_file, "read_file");

	RegisterFunction(L, list_files, "listfiles");
	RegisterFunction(L, list_files, "list_files");
	RegisterFunction(L, list_files, "ListFiles");

	RegisterFunction(L, append_file, "appendfile");
	RegisterFunction(L, append_file, "AppendFile");
	RegisterFunction(L, append_file, "append_file");

	RegisterFunction(L, make_folder, "makefolder");
	RegisterFunction(L, make_folder, "make_folder");
	RegisterFunction(L, make_folder, "MakeFolder");

	RegisterFunction(L, write_file, "writefile");
	RegisterFunction(L, write_file, "WriteFile");
	RegisterFunction(L, write_file, "write_file");

	RegisterFunction(L, load_file, "loadfile");
	RegisterFunction(L, load_file, "load_file");
	RegisterFunction(L, load_file, "LoadFile");

	RegisterFunction(L, list_files, "listfiles");
	RegisterFunction(L, list_files, "ListFiles");
	RegisterFunction(L, list_files, "list_files");

	RegisterFunction(L, is_folder, "isfolder");
	RegisterFunction(L, is_folder, "is_folder");
	RegisterFunction(L, is_folder, "IsFolder");

	RegisterFunction(L, is_file, "isfile");
	RegisterFunction(L, is_file, "IsFile");
	RegisterFunction(L, is_file, "is_file");

	RegisterFunction(L, make_folder, "makefolder");
	RegisterFunction(L, make_folder, "make_folder");
	RegisterFunction(L, make_folder, "MakeFolder");

	RegisterFunction(L, del_folder, "delfolder");
	RegisterFunction(L, del_folder, "deletefolder");
	RegisterFunction(L, del_folder, "delete_folder");
	RegisterFunction(L, del_folder, "DeleteFolder");

	RegisterFunction(L, del_file, "delfile");
	RegisterFunction(L, del_file, "deletefile");
	RegisterFunction(L, del_file, "DeleteFile");
	RegisterFunction(L, del_file, "delete_file");

	lua_getglobal(L, "game");
	lua_getmetatable(L, -1);
	lua_getfield(L, -1, "__namecall");

	Closure* namecall = (Closure*)lua_topointer(L, -1);
	lua_CFunction namecall_f = namecall->c.f;
	old_namecall = (__int64)namecall_f;
	namecall->c.f = namecall_hook;

	lua_settop(L, 0);

	lua_getglobal(L, "game");
	lua_getmetatable(L, -1);
	lua_getfield(L, -1, "__index");

	Closure* index = (Closure*)lua_topointer(L, -1);
	lua_CFunction index_f = index->c.f;
	old_index = (__int64)index_f;
	index->c.f = index_hook;




	lua_newtable(L);

	lua_pushcclosure(L, debug_getconstant, "debug.getconstant", 0);
	lua_setfield(L, -2, "getconstant");

	lua_pushcclosure(L, debug_getconstants, "debug.getconstants", 0);
	lua_setfield(L, -2, "getconstants");

	lua_pushcclosure(L, debug_getinfo, "debug.getinfo", 0);
	lua_setfield(L, -2, "getinfo");

	lua_pushcclosure(L, debug_getproto, "debug.getproto", 0);
	lua_setfield(L, -2, "getproto");

	lua_pushcclosure(L, debug_getprotos, "debug.getprotos", 0);
	lua_setfield(L, -2, "getprotos");

	lua_pushcclosure(L, debug_getstack, "debug.getstack", 0);
	lua_setfield(L, -2, "getstack");

	lua_pushcclosure(L, debug_getupvalue, "debug.getupvalue", 0);
	lua_setfield(L, -2, "getupvalue");

	lua_pushcclosure(L, debug_getupvalues, "debug.getupvalues", 0);
	lua_setfield(L, -2, "getupvalues");

	lua_pushcclosure(L, debug_setconstant, "debug.setconstant", 0);
	lua_setfield(L, -2, "setconstant");

	lua_pushcclosure(L, debug_setstack, "debug.setstack", 0);
	lua_setfield(L, -2, "setstack");

	lua_pushcclosure(L, debug_setupvalue, "debug.setupvalue", 0);
	lua_setfield(L, -2, "setupvalue");

	lua_pushcclosure(L, debug_getregistry, "debug.getregistry", 0);
	lua_setfield(L, -2, "getregistry");

	lua_setglobal(L, "debug");

}

