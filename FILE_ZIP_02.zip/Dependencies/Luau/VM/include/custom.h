#include <vector>

#ifndef CUSTOM_LUAU_STUFF
	#define CUSTOM_LUAU_STUFF TRUE
	std::vector<uintptr_t> exploit_closures = {};
	std::vector<uintptr_t> exploit_protos = {};
#endif