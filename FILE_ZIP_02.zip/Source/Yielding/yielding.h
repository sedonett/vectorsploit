
#pragma once

#include <iostream>
#include <cstdint>
#include <functional>
#include <thread>

#include "lualib.h"
#include "lstate.h"

#include "xorstr.hpp"

using YieldReturn = std::function<int(lua_State* L)>;

namespace Yielding {
	int haltExecution(lua_State* L, const std::function<YieldReturn()>& YieldedFunction);
}