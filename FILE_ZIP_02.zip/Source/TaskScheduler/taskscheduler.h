#pragma once

#include <Execution/execution.h>

#include "offsets.h"

#include <lstate.h>
#include <string>
#include <vector>
#include <queue>

namespace TaskScheduler {
	inline std::queue<std::string> Queue = {};
	inline std::queue<std::string> TeleportQueue = {};

	using VTFunctionType = uintptr_t(__fastcall*)(uintptr_t, uintptr_t, uintptr_t);
	static VTFunctionType OldFunction = nullptr;

	std::vector<uintptr_t> GetJobs();

	uintptr_t GetJobByName(std::string name);
	uintptr_t GetLuaState();
	uintptr_t GetDataModel();

	void HookGarbageCollector();
}