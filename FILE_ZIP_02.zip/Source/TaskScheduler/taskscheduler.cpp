#include "taskscheduler.h"

std::vector<uintptr_t> TaskScheduler::GetJobs() {
	std::vector<uintptr_t> Jobs = {};

	uintptr_t Singleton = RBX::GetTaskScheduler();

	auto JobsStart = *(uintptr_t*)(Singleton + RBX::TaskScheduler::JobsStart);
	const auto JobsEnd = *(uintptr_t*)(Singleton + RBX::TaskScheduler::JobsEnd);

	for (auto i = JobsStart; i < JobsEnd; i += 0x10) {
		uintptr_t Job = *(uintptr_t*)i;

		uintptr_t DataModelJob = *(uintptr_t*)(Job + RBX::TaskScheduler::DatamodelJob);
		uintptr_t DataModel = *(uintptr_t*)(DataModelJob + RBX::TaskScheduler::DatamodelJobToDatamodel);


		if (IsBadReadPtr(reinterpret_cast<uintptr_t*>(DataModelJob), sizeof(uintptr_t*))) continue;
		if (IsBadReadPtr(reinterpret_cast<uintptr_t*>(DataModel), sizeof(uintptr_t*))) continue;

		uintptr_t DataModelName = *(uintptr_t*)(DataModel + RBX::Instance::Name);

		if (*(std::string*)(DataModelName) == "Ugc") {
			Jobs.push_back(*(uintptr_t*)i);
		}
	}
	
	return Jobs;
}

uintptr_t TaskScheduler::GetJobByName(std::string name) {
	for (const auto job : GetJobs()) {
		if (*(std::string*)(job + RBX::TaskScheduler::JobName) == name) {
			return job;
		}
	}
	return 0;
}

uintptr_t TaskScheduler::GetLuaState() {
	uintptr_t WaitingHybridScriptsJob = GetJobByName("WaitingHybridScriptsJob");
	if (!WaitingHybridScriptsJob) return 0;

	uintptr_t ScriptContext = *(uintptr_t*)(WaitingHybridScriptsJob + RBX::TaskScheduler::ScriptContext);
	if (!ScriptContext) return 0;

	uintptr_t Identity = 0, Script = 0;
	auto EncryptedGlobalState = RBX::GetGlobalStateForInstance(ScriptContext + RBX::ScriptContext::GlobalStates, &Identity, &Script);
	auto DecryptedState = RBX::DecryptLuaState(EncryptedGlobalState + RBX::ScriptContext::LuaState);

	return DecryptedState;
}

uintptr_t TaskScheduler::GetDataModel() {
	const uintptr_t WaitingHybridScriptsJob = GetJobByName("WaitingHybridScriptsJob");
	if (!WaitingHybridScriptsJob) return 0x0;

	const uintptr_t ScriptContext = *(uintptr_t*)(WaitingHybridScriptsJob + RBX::TaskScheduler::ScriptContext);
	const uintptr_t DataModel = *(uintptr_t*)(ScriptContext + RBX::Instance::Parent);

	return DataModel;
}

void TaskScheduler::HookGarbageCollector() {
	uintptr_t LuaGc = GetJobByName("LuaGc");
	if (!LuaGc) return;

	auto VTable = new void* [25];
	memcpy(VTable, *(void**)LuaGc, sizeof(uintptr_t) * 25);
	OldFunction = (VTFunctionType)(VTable[2]);

	auto Hook = [](uintptr_t a1, uintptr_t a2, uintptr_t a3) -> uintptr_t {
		if (!TaskScheduler::Queue.empty()) {
			Execution::Execute(TaskScheduler::Queue.front());
			TaskScheduler::Queue.pop();
		}

		if (!TaskScheduler::TeleportQueue.empty()) {
			Execution::Execute(TaskScheduler::TeleportQueue.front());
			TaskScheduler::TeleportQueue.pop();
		}

		if (TaskScheduler::OldFunction == nullptr) {
			return 0x0;
		}

		return TaskScheduler::OldFunction(a1, a2, a3);
	};

	VTable[2] = reinterpret_cast<void*>(+Hook);
	*(void**)LuaGc = VTable;
}
