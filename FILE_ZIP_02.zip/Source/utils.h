#include <iostream>
#include <Windows.h>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#include <queue>
#include <map>

#include <ShlObj.h>
#include <Wininet.h>
#include <TlHelp32.h>
#include <queue>

#pragma comment(lib, "wininet.lib")

namespace Utils
{

	static inline bool is_errors(int code)
	{
		return (code >= 400);
	}

	static inline std::string write_error(int code)
	{
		switch (code)
		{
		case 100: return "continue";
		case 101: return "switching protocols";
		case 102: return "processing";
		case 103: return "early hints";

		case 200: return "ok";
		case 201: return "created";
		case 202: return "accepted";
		case 203: return "non-authoritative information";
		case 204: return "no content";
		case 205: return "reset content";
		case 206: return "partial content";
		case 207: return "multi-status";
		case 208: return "already reported";
		case 226: return "im used";

		case 300: return "multiple choices";
		case 301: return "moved permanently";
		case 302: return "found";
		case 303: return "see other";
		case 304: return "not modified";
		case 305: return "use proxy";
		case 307: return "temporary redirect";
		case 308: return "permanent redirect";

		case 400: return "bad request";
		case 401: return "unauthorized";
		case 402: return "payment required";
		case 403: return "forbidden";
		case 404: return "not found";
		case 405: return "method not allowed";
		case 406: return "not acceptable";
		case 407: return "proxy authentication required";
		case 408: return "request timeout";
		case 409: return "conflict";
		case 410: return "gone";
		case 411: return "length required";
		case 412: return "precondition failed";
		case 413: return "payload too large";
		case 414: return "uri too long";
		case 415: return "unsupported media type";
		case 416: return "range not satisfiable";
		case 417: return "expectation failed";
		case 422: return "unprocessable entity";
		case 423: return "locked";
		case 424: return "failed dependency";
		case 426: return "upgrade required";
		case 428: return "precondition required";
		case 429: return "too many requests";
		case 431: return "request header fields too large";
		case 451: return "unavailable for legal reasons";

		case 500: return "internal server error";
		case 501: return "not implemented";
		case 502: return "bad gateway";
		case 503: return "service unavailable";
		case 504: return "gateway time-out";
		case 505: return "http version not supported";
		case 506: return "variant also negotiates";
		case 507: return "insufficient storage";
		case 508: return "loop detected";
		case 510: return "not extended";
		case 511: return "network authentication required";

		default: return std::string();
		}
	}

	__forceinline static std::string replace_all(std::string subject, const std::string& search, const std::string& replace)
	{
		size_t pos = 0;
		while ((pos = subject.find(search, pos)) != std::string::npos)
		{
			subject.replace(pos, search.length(), replace);
			pos += replace.length();
		}
		return subject;
	}

	__forceinline static auto replace(std::string& str, const std::string& from, const std::string& to) -> bool
	{
		size_t start_pos = str.find(from);
		if (start_pos == std::string::npos)
			return false;
		str.replace(start_pos, from.length(), to);
		return true;
	}
}