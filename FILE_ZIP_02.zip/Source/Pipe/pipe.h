#pragma once

#include <Windows.h>
#include <string>
#include <memory>

#include "TaskScheduler/taskscheduler.h"

class PipeSystem {
private:
	static constexpr size_t BUFFER_SIZE = 8192;
	static constexpr size_t MAX_BUFFER_SIZE = 999234524;

	struct Buffer {
		std::unique_ptr<char[]> data;
		size_t size;

		Buffer(size_t bufferSize) :
			data(std::make_unique<char[]>(bufferSize)),
			size(bufferSize) {
		}
	};

	class PipeHandle {
		HANDLE handle;
	public:
		PipeHandle(const char* name) {
			SECURITY_ATTRIBUTES sa;
			SECURITY_DESCRIPTOR sd;
			InitializeSecurityDescriptor(&sd, SECURITY_DESCRIPTOR_REVISION);
			SetSecurityDescriptorDacl(&sd, TRUE, nullptr, FALSE);
			sa.nLength = sizeof(sa);
			sa.lpSecurityDescriptor = &sd;
			sa.bInheritHandle = TRUE;

			handle = CreateNamedPipe(
				name,
				PIPE_ACCESS_DUPLEX | PIPE_TYPE_BYTE | PIPE_READMODE_BYTE,
				PIPE_WAIT,
				1,
				BUFFER_SIZE,
				BUFFER_SIZE,
				NMPWAIT_USE_DEFAULT_WAIT,
				&sa
			);
		}

		~PipeHandle() {
			if (handle != INVALID_HANDLE_VALUE) {
				DisconnectNamedPipe(handle);
				CloseHandle(handle);
			}
		}

		operator HANDLE() const { return handle; }
	};

public:
	static bool ReadFromPipe(HANDLE hPipe) {
		Buffer buffer(BUFFER_SIZE);
		std::string accumulator;
		DWORD bytesRead;

		while (ReadFile(hPipe, buffer.data.get(), buffer.size - 1, &bytesRead, nullptr) && bytesRead > 0) {
			buffer.data[bytesRead] = '\0';
			accumulator.append(buffer.data.get(), bytesRead);
		}

		if (!accumulator.empty()) {
			TaskScheduler::Queue.push(accumulator);
			return true;
		}

		return false;
	}

	static void RunNamedPipe(const char* pipeName) {
		while (true) {
			PipeHandle pipe(pipeName);
			if (pipe == INVALID_HANDLE_VALUE) continue;

			if (ConnectNamedPipe(pipe, nullptr)) {
				std::string script_source;
				Buffer buffer(BUFFER_SIZE);
				DWORD bytesRead;

				while (ReadFile(pipe, buffer.data.get(), buffer.size - 1, &bytesRead, nullptr)) {
					buffer.data[bytesRead] = '\0';
					script_source.append(buffer.data.get(), bytesRead);
				}

				if (!script_source.empty()) {
					TaskScheduler::Queue.push(script_source);
				}
			}
		}
	}
};

