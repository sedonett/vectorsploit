#include "execution.h"

#include "Environment/environment.h"

void Execution::Initialize() {
	uintptr_t WaitingHybridScriptsJob = TaskScheduler::GetJobByName("WaitingHybridScriptsJob");
	uintptr_t LuaState = TaskScheduler::GetLuaState();

	MainState = lua_newthread((lua_State*)(LuaState));

	lua_ref((lua_State*)LuaState, -1);
	lua_pop((lua_State*)LuaState, -1);

	luaL_sandboxthread(MainState);
	Environment::Initialize(MainState);
	TaskScheduler::HookGarbageCollector();
}

void Execution::Execute(std::string source) {
	const auto Bytecode = Luau::compile(source, { 1, 1, 0 }, {}, &BytecodeEncoder);

	if (Bytecode[0] == '\0') {
		RBX::Print(3, Bytecode.c_str() + 1);
		return;
	}

	lua_State* thread = lua_newthread(MainState);

	Identity::SetIdentity(thread, 8);

	if (luau_load(thread, xorstr_("@"), Bytecode.c_str(), Bytecode.size(), 0) == 0) {
		Closure* Cl = (Closure*)lua_topointer(thread, -1);
		Identity::SetCapabilities(Cl->l.p, thread);

		RBX::Defer(thread);
	}
}