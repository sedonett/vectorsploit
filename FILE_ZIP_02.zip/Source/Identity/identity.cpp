#include "identity.h"

uintptr_t Identity::GetCapabilitiesForIdentity(int identity) {
    uintptr_t result;

    switch (identity)
    {
    case 1:
    case 4:
        result = 0x2000000000000003LL;
        break;
    case 3:
        result = 0x200000000000000BLL;
        break;
    case 5:
        result = 0x2000000000000001LL;
        break;
    case 6:
        result = 0x600000000000000BLL;
        break;
    case 7:
    case 8:
        result = 0x200000000000003FLL;
        break;
    case 9:
        result = 12LL;
        break;
    case 0xA:
        result = 0x6000000000000003LL;
        break;
    case 0xB:
        result = 0x2000000000000000LL;
        break;
    case 0xC:
        result = 0x1000000000000000LL;
        break;
    default:
        result = 0LL;
        break;
    }

    return result;
}

void Identity::SetIdentity(lua_State* L, int identity) {
	L->userdata->Identity = identity;
    L->userdata->Capabilities = 0x3FFFFFF00LL | GetCapabilitiesForIdentity(identity);
}

int Identity::GetIdentity(lua_State* L, int identity) {
	return L->userdata->Identity;
}

void Identity::SetCapabilities(Proto* P, lua_State* L) {
	P->userdata = &L->userdata->Capabilities;

	for (int i = 0; i < P->sizep; i++) {
		SetCapabilities(P->p[i], L);
	}
}