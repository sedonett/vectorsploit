#pragma once

#include "environment.h"

using namespace Environment;
using namespace Explorer;

namespace InputLibrary {
	int isrbxactive(lua_State* rl)
	{
		LogFunction(xorstr_("isrbxactive"));
		HWND window;
		window = FindWindowA(NULL, "Roblox");
		lua_pushboolean(rl, GetForegroundWindow() == window);
		return 1;
	}

	int mouse1press(lua_State* rl)
	{
		LogFunction(xorstr_("mouse1press"));
		HWND window = FindWindowA(NULL, "Roblox");
		if (GetForegroundWindow() == window)
			mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
		return 0;
	}

	int mouse1release(lua_State* rl)
	{
		LogFunction(xorstr_("mouse1release"));
		HWND window = FindWindowA(NULL, "Roblox");
		if (GetForegroundWindow() == window)
			mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
		return 0;
	}

	int mouse1click(lua_State* rl)
	{
		LogFunction(xorstr_("mouse1click"));
		HWND window = FindWindowA(NULL, "Roblox");
		if (GetForegroundWindow() == window)
			mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
		return 0;
	}

	int mouse2press(lua_State* rl)
	{
		LogFunction(xorstr_("mouse2press"));
		HWND window = FindWindowA(NULL, "Roblox");
		if (GetForegroundWindow() == window)
			mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
		return 0;
	}

	int mouse2release(lua_State* rl)
	{
		LogFunction(xorstr_("mouse2release"));
		HWND window = FindWindowA(NULL, "Roblox");
		if (GetForegroundWindow() == window)
			mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
		return 0;
	}

	int mouse2click(lua_State* rl)
	{
		LogFunction(xorstr_("mouse2click"));
		HWND window = FindWindowA(NULL, "Roblox");
		if (GetForegroundWindow() == window)
			mouse_event(MOUSEEVENTF_RIGHTDOWN | MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
		return 0;
	}

	int keypress(lua_State* rl)
	{
		LogFunction(xorstr_("keypress"));
		HWND window = FindWindowA(NULL, "Roblox");
		UINT key = luaL_checkinteger(rl, 1);

		if (GetForegroundWindow() == window)
			keybd_event(0, (BYTE)MapVirtualKeyA(key, MAPVK_VK_TO_VSC), KEYEVENTF_SCANCODE, 0);
		return 0;
	}

	int iskeydown(lua_State* rl)
	{
		LogFunction(xorstr_("iskeydown"));
		luaL_checktype(rl, 1, LUA_TNUMBER);

		UINT key = luaL_checkinteger(rl, 1);

		SHORT state = GetAsyncKeyState(key);
		lua_pushboolean(rl, (bool)((state & 0x8000) != 0));
		return 1;
	}

	int keyrelease(lua_State* rl)
	{
		LogFunction(xorstr_("keyrelease"));
		HWND window = FindWindowA(NULL, "Roblox");
		UINT key = luaL_checkinteger(rl, 1);

		if (GetForegroundWindow() == window)
			keybd_event(0, (BYTE)MapVirtualKeyA(key, MAPVK_VK_TO_VSC), KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP, 0);
		return 0;
	}

	int mousemoverel(lua_State* rl)
	{
		LogFunction(xorstr_("mousemoverel"));
		HWND window = FindWindowA(NULL, "Roblox");

		DWORD x = luaL_checkinteger(rl, 1);
		DWORD y = luaL_checkinteger(rl, 2);

		if (GetForegroundWindow() == window)
			mouse_event(MOUSEEVENTF_MOVE, x, y, 0, 0);
		return 0;
	}

	int mousemoveabs(lua_State* rl)
	{
		LogFunction(xorstr_("mousemoveabs"));
		HWND window = FindWindowA(NULL, "Roblox");

		DWORD xx = luaL_checkinteger(rl, 1);
		DWORD y = luaL_checkinteger(rl, 2);

		if (GetForegroundWindow() != window) return 0;

		int width = GetSystemMetrics(SM_CXSCREEN) - 1;
		int height = GetSystemMetrics(SM_CYSCREEN) - 1;

		RECT CRect;
		GetClientRect(GetForegroundWindow(), &CRect);

		POINT Point{ CRect.left, CRect.top };
		ClientToScreen(GetForegroundWindow(), &Point);

		xx = (xx + (DWORD)Point.x) * (65535 / width);
		y = (y + (DWORD)Point.y) * (65535 / height);

		mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE, xx, y, 0, 0);

		return 0;
	}

	int mousescroll(lua_State* rl)
	{
		LogFunction(xorstr_("mousescroll"));
		HWND window = FindWindowA(NULL, "Roblox");
		DWORD scroll_amount = luaL_checkinteger(rl, 1);

		if (GetForegroundWindow() == window)
			mouse_event(MOUSEEVENTF_WHEEL, 0, 0, scroll_amount, 0);
		return 0;
	}

	void Register(lua_State* L) {
		AddGlobal(L, { xorstr_("isrbxactive") }, isrbxactive);
		AddGlobal(L, { xorstr_("mouse1press") }, mouse1press);
		AddGlobal(L, { xorstr_("mouse1release") }, mouse1release);
		AddGlobal(L, { xorstr_("mouse1click") }, mouse1click);
		AddGlobal(L, { xorstr_("mouse2press") }, mouse2press);
		AddGlobal(L, { xorstr_("mouse2release") }, mouse2release);
		AddGlobal(L, { xorstr_("mouse2click") }, mouse2click);
		AddGlobal(L, { xorstr_("keypress") }, keypress);
		AddGlobal(L, { xorstr_("iskeydown") }, iskeydown);
		AddGlobal(L, { xorstr_("keyrelease") }, keyrelease);
		AddGlobal(L, { xorstr_("mousemoverel") }, mousemoverel);
		AddGlobal(L, { xorstr_("mousemoveabs") }, mousemoveabs);
		AddGlobal(L, { xorstr_("mousescroll") }, mousescroll);
	}
}