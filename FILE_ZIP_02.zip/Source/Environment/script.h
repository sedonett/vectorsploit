
#define _WINSOCKAPI_
#define WIN32_LEAN_AND_MEAN

#pragma once

#include "environment.h"
#include "utils.h"

#include <TaskScheduler/taskscheduler.h>
#include <Yielding/yielding.h>

#include "structs.h"

using namespace Environment;
using namespace Explorer;

namespace ScriptLibrary {
	int gethui(lua_State* L)
	{
		LogFunction(xorstr_("gethui"));
		lua_getglobal(L, xorstr_("cloneref"));
		lua_getglobal(L, xorstr_("game"));
		lua_call(L, 1, 1);
		lua_getfield(L, -1, xorstr_("GetService"));
		lua_pushvalue(L, -2);
		lua_pushstring(L, xorstr_("CoreGui"));
		lua_call(L, 2, 1);
		lua_remove(L, 1);
		lua_getglobal(L, xorstr_("cloneref"));
		lua_pushvalue(L, 1);
		lua_call(L, 1, 1);
		lua_getfield(L, -1, xorstr_("RobloxGui"));
		lua_getglobal(L, xorstr_("cloneref"));
		lua_pushvalue(L, -2);
		lua_call(L, 1, 1);
		return 1;
	}

	auto setclipboard(lua_State* rl) -> int
	{
		LogFunction(xorstr_("setclipboard"));
		luaL_checktype(rl, 1, LUA_TSTRING);

		std::string content = lua_tostring(rl, 1);

		HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, content.size() + 1);
		memcpy(GlobalLock(hMem), content.data(), content.size());
		GlobalUnlock(hMem);
		OpenClipboard(0);
		EmptyClipboard();
		SetClipboardData(CF_TEXT, hMem);
		CloseClipboard();
		return 0;
	}

	auto getclipboard(lua_State* rl) -> int
	{
		LogFunction(xorstr_("getclipboard"));
		OpenClipboard(NULL);
		std::string clipboard = reinterpret_cast<char*>(GetClipboardData(CF_TEXT));

		lua_pushlstring(rl, clipboard.data(), clipboard.length());
		return 1;
	}

	auto httpget(lua_State* rl) -> int
	{
		LogFunction(xorstr_("httpget"));

		luaL_checktype(rl, 1, LUA_TSTRING);
		std::string url = lua_tostring(rl, 1);

		if (url.find("http") == std::string::npos)
			luaL_error(rl, "Invalid url, (expected 'http://' or 'https://')");

		cpr::Header Headers{  };

		Headers.insert({ "User-Agent", "Roblox/WinInet" });

		auto result = cpr::Get(cpr::Url{ url }, Headers);

		if (Utils::is_errors(result.status_code))
		{
			std::string http_error;
			http_error += "[HttpGet] ";
			http_error += std::to_string(result.status_code);
			http_error += " ";
			http_error += Utils::write_error(result.status_code);

			luaL_error(rl, http_error.c_str());
		}

		lua_pushlstring(rl, result.text.data(), result.text.size());
		return 1;
	}

	auto getobjects(lua_State* rl) -> int
	{
		LogFunction(xorstr_("getobjects"));
		std::string asset;

		if (!lua_isstring(rl, 1)) {
			luaL_checktype(rl, 2, LUA_TSTRING);
			asset = lua_tostring(rl, 2);
		}
		else {
			luaL_checktype(rl, 1, LUA_TSTRING);
			asset = lua_tostring(rl, 1);
		}

		lua_getglobal(rl, "game");
		lua_getfield(rl, -1, "GetService");
		lua_pushvalue(rl, -2);
		lua_pushstring(rl, "InsertService");
		lua_call(rl, 2, 1);

		lua_getfield(rl, -1, "LoadLocalAsset");
		lua_pushvalue(rl, -2);
		lua_pushstring(rl, asset.data());
		lua_call(rl, 2, 1);

		lua_createtable(rl, 0, 0);
		lua_pushvalue(rl, -2);
		lua_rawseti(rl, -2, 1);

		return 1;
	}

	auto identifyexecutor(lua_State* rl) -> int
	{
		LogFunction(xorstr_("identifyexecutor"));
		lua_pushstring(rl, xorstr_("Vectorsploit"));
		lua_pushstring(rl, xorstr_("Private Release"));
		return 2;
	}

	int request(lua_State* rl)
	{
		LogFunction(xorstr_("request"));

		lua_getfield(rl, 1, "Url");
		auto url = luaL_checkstring(rl, -1);
		lua_pop(rl, 1);

		lua_getfield(rl, 1, "Method");
		auto method = std::string(luaL_checkstring(rl, -1));
		lua_pop(rl, 1);

		std::string body;
		lua_getfield(rl, 1, "Body");
		if (lua_isstring(rl, -1))
		{
			body = luaL_checkstring(rl, -1);
		}
		lua_pop(rl, 1);

		cpr::Header headers;
		lua_getfield(rl, 1, "Headers");
		if (lua_istable(rl, -1))
		{
			lua_pushnil(rl);
			while (lua_next(rl, -2))
			{
				headers[luaL_checkstring(rl, -2)] = luaL_checkstring(rl, -1);
				lua_pop(rl, 1);
			}
		}
		lua_pop(rl, 1);

		headers["User-Agent"] = "Vectorsploit/RobloxApp/1.0.0";

		HW_PROFILE_INFO hwProfileInfo;
		if (!GetCurrentHwProfile(&hwProfileInfo))
			luaL_error(rl, "Invalid HWID.");

		std::string hwid = hwProfileInfo.szHwProfileGuid;

		headers["VS-Fingerprint"] = Crypt::Hash::hash(hwid, "sha256");
		headers["VS-Identifier"] = Crypt::Hash::hash(hwid, "sha256");

		return Yielding::haltExecution(rl, [method, url, body, headers, rl]() -> auto
			{
				cpr::Response response;

				if (method == "GET" || method == "Get")
				{
					response = cpr::Get(cpr::Url(url), headers);
				}
				else if (method == "POST" || method == "Post")
				{
					response = cpr::Post(cpr::Url(url), cpr::Body(body), headers);
				}
				else if (method == "PATCH" || method == "Patch")
				{
					response = cpr::Patch(cpr::Url(url), cpr::Body(body), headers);
				}
				else if (method == "PUT" || method == "Put")
				{
					response = cpr::Put(cpr::Url(url), cpr::Body(body), headers);
				}
				else
				{
					luaL_error(rl, "invalid method");
				}

				return ([response](lua_State* rl) {

					lua_newtable(rl);

					lua_pushlstring(rl, response.text.data(), response.text.length());
					lua_setfield(rl, -2, "Body");

					lua_pushinteger(rl, response.status_code);
					lua_setfield(rl, -2, "StatusCode");

					lua_pushlstring(rl, response.status_line.data(), response.status_line.length());
					lua_setfield(rl, -2, "StatusMessage");

					lua_pushboolean(rl, response.status_code >= 200 && response.status_code < 300);
					lua_setfield(rl, -2, "Success");

					lua_newtable(rl);
					for (const auto& header : response.header)
					{
						lua_pushlstring(rl, header.first.data(), header.first.length());
						lua_pushlstring(rl, header.second.data(), header.second.length());
						lua_settable(rl, -3);
					}
					lua_setfield(rl, -2, "Headers");

					return 1;
					});
			});

	}

	int gethwid(lua_State* L) {
		lua_pushstring(L, Crypt::HWID::GetHWID().c_str());
		return 1;
	}

	auto getcustomasset(lua_State* L) -> int
	{
		LogFunction(xorstr_("getcustomasset"));
		luaL_checktype(L, 1, LUA_TSTRING);

		std::string assetname = lua_tostring(L, 1);
		std::filesystem::path workspace_path = workspaceDir / assetname;
		std::filesystem::path asset_directory = assetsDir / workspace_path.filename();

		try {
			std::filesystem::copy_file(workspace_path, asset_directory, std::filesystem::copy_options::update_existing);
			lua_pushstring(L, std::string("rbxasset://VS/" + asset_directory.filename().string()).data());
			return 1;
		}
		catch (std::exception& e) {
			luaL_error(L, xorstr_("failed to get custom asset"));
			return 0;
		}

		return 1;
	}

	auto queue_on_teleport(lua_State* rl) -> int {
		LogFunction(xorstr_("queue_on_teleport"));

		std::string src = luaL_checkstring(rl, 1);
		TaskScheduler::TeleportQueue.push(src);

		return 0;
	}

	int getcallingscript(lua_State* L) {
		LogFunction(xorstr_("getcallingscript"));
		std::uint64_t scriptPtr = *reinterpret_cast<std::uintptr_t*>(L->userdata) + 0x50;
		if (!scriptPtr) { lua_pushnil(L); return 1; }

		RBX::PushInstance(L, scriptPtr);
		return 1;
	}

	auto getloadedmodules(lua_State* L) -> int
	{
		LogFunction(xorstr_("getloadedmodules"));
		lua_newtable(L);

		typedef struct {
			lua_State* pLua;
			int itemsFound;
			std::map< uintptr_t, bool > map;
		} GCOContext;

		auto gcCtx = GCOContext{ L, 0 };

		const auto ullOldThreshold = L->global->GCthreshold;
		L->global->GCthreshold = SIZE_MAX;

		// Visit garbage-collected objects
		luaM_visitgco(L, &gcCtx, [](void* ctx, lua_Page* pPage, GCObject* pGcObj) -> bool {
			const auto pCtx = static_cast<GCOContext*>(ctx);
			const auto ctxL = pCtx->pLua;

			if (isdead(ctxL->global, pGcObj))
				return false;

			if (const auto gcObjType = pGcObj->gch.tt;
				gcObjType == LUA_TFUNCTION) {
				// Push the function onto the stack
				ctxL->top->value.gc = pGcObj;
				ctxL->top->tt = gcObjType;
				ctxL->top++;

				lua_getfenv(ctxL, -1);

				if (!lua_isnil(ctxL, -1)) {
					lua_getfield(ctxL, -1, "script");

					if (!lua_isnil(ctxL, -1)) {
						uintptr_t script_addr = *(uintptr_t*)lua_touserdata(ctxL, -1);

						std::string class_name = **(std::string**)(*(uintptr_t*)(script_addr + RBX::Instance::ClassDescriptor) + RBX::ClassDescriptor::ClassName);

						if (pCtx->map.find(script_addr) == pCtx->map.end() && class_name == "ModuleScript") {
							pCtx->map.insert({ script_addr, true });
							lua_rawseti(ctxL, -4, ++pCtx->itemsFound);
						}
						else {
							lua_pop(ctxL, 1);
						}
					}
					else {
						lua_pop(ctxL, 1);
					}
				}

				lua_pop(ctxL, 2);
			}
			return false;
			});

		L->global->GCthreshold = ullOldThreshold;

		return 1;
	}

	auto getsenv(lua_State* L) -> int
	{
		LogFunction(xorstr_("getsenv"));
		luaL_checktype(L, 1, LUA_TUSERDATA);
		uintptr_t script_instance = *(uintptr_t*)lua_touserdata(L, 1);

		//	Defs::rbx_print(1, "script: %llX", script_instance);

		lua_getglobal(L, xorstr_("typeof"));
		lua_pushvalue(L, 1);
		lua_call(L, 1, 1);
		const bool isInstance = (strcmp(lua_tolstring(L, -1, 0), xorstr_("Instance")) == 0);
		lua_pop(L, 1);

		if (!isInstance)
			luaL_argerror(L, 1, xorstr_("Expected Instance"));

		lua_getfield(L, 1, xorstr_("ClassName"));
		const char* class_name = lua_tolstring(L, -1, NULL);

		lua_pop(L, 1);

		//lua_settop(L, 0);

		if (strcmp(class_name, "LocalScript") && strcmp(class_name, "ModuleScript")) {
			luaL_argerror(L, 1, xorstr_("LocalScript or ModuleScript"));
		}

		if (!strcmp(class_name, "LocalScript")) {
			auto node = *reinterpret_cast<Node_t**>(script_instance + RBX::ScriptNode);

			if (node == nullptr)
			{
				lua_pushnil(L);
				return 1;
			}

			auto wtr = node->wtr;
			if (wtr == nullptr)
			{
				lua_pushnil(L);
				return 1;
			}

			for (auto it = wtr; it; it = it->next)
			{
				auto thref = it->liveThreadRef;
				if (thref == nullptr)
				{
					continue;
				}

				auto thread = thref->th;
				if (thread == nullptr)
				{
					continue;
				}

				const auto extraspace = reinterpret_cast<int64_t>(lua_getthreaddata(thread));

				uintptr_t thread_scr;

				if (extraspace)
				{
					thread_scr = *(uintptr_t*)(extraspace + 0x50);
				}

				if (thread_scr)
				{
					if (script_instance == thread_scr)
					{
						lua_pushvalue(thread, LUA_GLOBALSINDEX);
						lua_xmove(thread, L, 1);
						return 1;
					}
				}
				else
				{
					continue;
				}
			}
		}
		else if (!strcmp(class_name, "ModuleScript")) {
			getloadedmodules(L);

			bool is_loaded = false;

			if (lua_istable(L, -1)) {
				lua_pushnil(L);
				while (lua_next(L, -2) != 0) {

					if (lua_isuserdata(L, -1)) {
						uintptr_t loaded_module = *(uintptr_t*)lua_touserdata(L, -1);

						if (loaded_module == script_instance) {
							is_loaded = true;
						}
					}
					lua_pop(L, 1);
				}
			}
			lua_pop(L, 1);

			if (!is_loaded) {
				luaL_error(L, "ModuleScript not loaded");
				return 0;
			}

			lua_getglobal(L, "getfenv");
			{
				*(bool*)(RBX::EnableLoadModule) = true;

				lua_getglobal(L, "debug");
				lua_getfield(L, -1, "loadmodule");
				{
					lua_pushvalue(L, 1);
				}
				lua_call(L, 1, 1);
				lua_remove(L, -2);

				*(bool*)(RBX::EnableLoadModule) = false;
			}
			lua_call(L, 1, 1);

			if (!lua_isnoneornil(L, -1))
			{
				return 1;
			}
		}

		lua_pushnil(L);
		return 1;
	}

	int getrunningscripts(lua_State* L) {
		LogFunction(xorstr_("getrunningscripts"));

		std::map< uintptr_t, bool > map;

		lua_pushvalue(L, LUA_REGISTRYINDEX);

		lua_newtable(L);

		lua_pushnil(L);

		auto c = 0u;
		while (lua_next(L, -3))
		{
			if (lua_isthread(L, -1))
			{
				const auto thread = lua_tothread(L, -1);

				if (thread)
				{
					if (const auto script_ptr = reinterpret_cast<std::uintptr_t>(thread->userdata) + 0x50; *reinterpret_cast<std::uintptr_t*>(script_ptr))
					{
						if (map.find(*(uintptr_t*)script_ptr) == map.end())
						{
							map.insert({ *(uintptr_t*)script_ptr, true });

							RBX::PushInstance(L, script_ptr);

							lua_rawseti(L, -4, ++c);
						}
					}
				}
			}

			lua_pop(L, 1);
		}

		return 1;
	}

	auto getcontext(lua_State* rl) -> int
	{
		LogFunction(xorstr_("getcontext"));

		lua_pushinteger(rl, rl->userdata->Identity);
		return 1;
	}

	auto setcontext(lua_State* rl) -> int
	{
		LogFunction(xorstr_("setcontext"));
		luaL_checktype(rl, 1, LUA_TNUMBER);

		int level = lua_tointeger(rl, 1);

		if (level > 8) {
			luaL_error(rl, " You may not set your identity above 8");
			return 0;
		}

		auto userdata = reinterpret_cast<std::int64_t>(rl->userdata);
		*reinterpret_cast<std::int64_t*>(userdata + 48) = level;

		std::int64_t arr[128];
		RBX::Impersonator(arr, &level, *reinterpret_cast<std::int64_t*>(userdata + 72));

		return 0;
	}

	void Register(lua_State* L) {
		AddGlobal(L, { xorstr_("gethui") }, gethui);
		AddGlobal(L, { xorstr_("getclipboard") }, getclipboard);
		AddGlobal(L, { xorstr_("setclipboard") }, setclipboard);
		AddGlobal(L, { xorstr_("httpget") }, httpget);
		AddGlobal(L, { xorstr_("getobjects") }, getobjects);
		AddGlobal(L, { xorstr_("identifyexecutor") }, identifyexecutor);
		AddGlobal(L, { xorstr_("request") }, request);
		AddGlobal(L, { xorstr_("gethwid") }, gethwid);
		AddGlobal(L, { xorstr_("getcustomasset") }, getcustomasset);
		AddGlobal(L, { xorstr_("queue_on_teleport") }, queue_on_teleport);
		AddGlobal(L, { xorstr_("getcallingscript") }, getcallingscript);
		AddGlobal(L, { xorstr_("getloadedmodules") }, getloadedmodules);
		AddGlobal(L, { xorstr_("getsenv") }, getsenv);
		AddGlobal(L, { xorstr_("getrunningscripts") }, getrunningscripts);
		AddGlobal(L, { xorstr_("getcontext"), xorstr_("getthreadidentity")}, getcontext);
		AddGlobal(L, { xorstr_("setcontext"), xorstr_("setthreadidentity") }, setcontext);
	}
}