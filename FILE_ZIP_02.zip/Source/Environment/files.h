#pragma once

#include "environment.h"
#include "Execution/execution.h"

using namespace Environment;
using namespace Explorer;

namespace FilesLibrary {
	int readfile(lua_State* L) {
		LogFunction(xorstr_("readfile"));
		luaL_checkstring(L, 1);

		auto absolutePath = CheckPath(L);

		if (!fs::exists(absolutePath) || !fs::is_regular_file(absolutePath)) {
			luaG_runerror(L, "file doesnt exist");
		}

		std::ifstream file(absolutePath, std::ios::binary | std::ios::ate);
		if (!file.is_open()) {
			luaG_runerror(L, "failed to read file content");
		}

		std::streamsize size = file.tellg();
		file.seekg(0, std::ios::beg);
		std::vector<char> buffer(size);
		if (!file.read(buffer.data(), size)) {
			luaG_runerror(L, "failed to read file");
		}

		lua_pushlstring(L, buffer.data(), size);

		return 1;
	}

	int listfiles(lua_State* L) {
		LogFunction(xorstr_("listfiles"));
		luaL_checkstring(L, 1);

		auto absolutePath = CheckPath(L);

		if (!fs::exists(absolutePath) || !fs::is_directory(absolutePath)) {
			luaG_runerror(L, "folder doesn't exist");
		}

		lua_newtable(L);
		int currentIndex = 1;
		for (const auto& entry : fs::directory_iterator(absolutePath)) {
			lua_pushstring(L, entry.path().string().c_str());
			lua_rawseti(L, -2, currentIndex);
			currentIndex++;
		}

		return 1;
	}

	int writefile(lua_State* L) {
		LogFunction(xorstr_("writefile"));
		luaL_checkstring(L, 1);
		luaL_checkstring(L, 2);

		auto absolutePath = CheckPath(L);
		size_t contentLength;
		auto fileContent = lua_tolstring(L, 2, &contentLength);

		if (fs::is_directory(absolutePath)) {
			luaG_runerror(L, "argument 1 is not a valid file");
		}

		fs::create_directories(absolutePath.parent_path());

		std::ofstream file(absolutePath, std::ios::binary | std::ios::beg);
		if (!file.is_open()) {
			luaG_runerror(L, "failed to open file");
		}

		file.write(fileContent, contentLength);
		if (file.fail()) {
			luaG_runerror(L, "failed to write content to file");
		}

		file.close();
		if (file.fail()) {
			luaG_runerror(L, "failed to close file");
		}

		return 0;
	}

	int appendfile(lua_State* L) {
		LogFunction(xorstr_("appendfile"));
		luaL_checkstring(L, 1);
		luaL_checkstring(L, 2);

		auto relativePath = lua_tolstring(L, 1, 0);
		auto contentToAppend = lua_tolstring(L, 2, 0);
		auto absolutePath = CheckPath(L);

		if (!fs::exists(absolutePath) || !fs::is_regular_file(absolutePath)) {
			luaG_runerror(L, "file doesn't exist");
		}

		lua_pushcfunction(L, readfile, "AppendFile");
		lua_pushstring(L, relativePath);
		lua_call(L, 1, 1);
		auto currentContent = _strdup(lua_tolstring(L, -1, NULL));
		lua_pop(L, 1);
		auto newContent = std::format("{}{}", currentContent, contentToAppend).c_str();
		lua_pushcfunction(L, writefile, "AppendFile");
		lua_pushstring(L, relativePath);
		lua_pushstring(L, newContent);
		lua_call(L, 2, 0);

		return 0;
	}

	int makefolder(lua_State* L) {
		LogFunction(xorstr_("makefolder"));
		luaL_checkstring(L, 1);

		auto absolutePath = CheckPath(L);

		if (fs::is_directory(absolutePath)) {
			return 0;
		}

		if (fs::is_regular_file(absolutePath)) {
			luaG_runerror(L, "There is a file on this path!");
		}

		if (fs::exists(absolutePath)) {
			luaG_runerror(L, "There is already something on this path!");
		}

		fs::create_directories(absolutePath);
		return 0;
	}

	int isfile(lua_State* L) {
		LogFunction(xorstr_("isfile"));
		luaL_checkstring(L, 1);

		auto absolutePath = CheckPath(L);

		lua_pushboolean(L, fs::exists(absolutePath) && fs::is_regular_file(absolutePath));
		return 1;
	}

	int isfolder(lua_State* L) {
		LogFunction(xorstr_("isfolder"));
		luaL_checkstring(L, 1);

		auto absolutePath = CheckPath(L);

		lua_pushboolean(L, fs::exists(absolutePath) && fs::is_directory(absolutePath));
		return 1;
	}

	int delfile(lua_State* L) {
		LogFunction(xorstr_("delfile"));
		luaL_checkstring(L, 1);

		auto absolutePath = CheckPath(L);

		if (!fs::exists(absolutePath) || !fs::is_regular_file(absolutePath)) {
			luaG_runerror(L, "file doesn't exist!");
		}

		fs::remove(absolutePath);
		return 0;
	}

	int delfolder(lua_State* L) {
		LogFunction(xorstr_("delfolder"));
		luaL_checkstring(L, 1);

		auto absolutePath = CheckPath(L);

		if (!fs::exists(absolutePath) || !fs::is_directory(absolutePath)) {
			luaG_runerror(L, "folder doesn't exist");
		}

		fs::remove_all(absolutePath);
		return 0;
	}

	auto loadfile(lua_State* rl) -> int
	{
		LogFunction(xorstr_("loadfile"));
		luaL_checktype(rl, 1, LUA_TSTRING);

		luaL_checkstring(rl, 1);

		auto absolutePath = CheckPath(rl);

		if (!std::filesystem::is_regular_file(absolutePath)) {
			luaL_error(rl, "invalid path");
			return 0;

		}

		std::ifstream f(absolutePath, std::ios::in | std::ios::binary);
		const auto sz = std::filesystem::file_size(absolutePath);
		std::string result(sz, '\0');
		f.read(result.data(), sz);

		auto bytecode = Luau::compile(result, {}, {}, &BytecodeEncoder);

		if (luau_load(rl, xorstr_("readfile"), bytecode.c_str(), bytecode.size(), 0) != LUA_OK)
		{
			std::string err = lua_tostring(rl, -1);
			lua_pop(rl, 1);

			lua_pushnil(rl);
			lua_pushlstring(rl, err.c_str(), err.size());
			return 2;
		}

		Identity::SetCapabilities(((Closure*)lua_topointer(rl, -1))->l.p, rl);

		return 1;
	}

	void Register(lua_State* L) {
		AddGlobal(L, { xorstr_("readfile") }, readfile);
		AddGlobal(L, { xorstr_("listfiles") }, listfiles);
		AddGlobal(L, { xorstr_("writefile") }, writefile);
		AddGlobal(L, { xorstr_("appendfile") }, appendfile);
		AddGlobal(L, { xorstr_("makefolder") }, makefolder);
		AddGlobal(L, { xorstr_("isfile") }, isfile);
		AddGlobal(L, { xorstr_("isfolder") }, isfolder);
		AddGlobal(L, { xorstr_("delfolder") }, delfolder);
		AddGlobal(L, { xorstr_("delfile") }, delfile);
		AddGlobal(L, { xorstr_("loadfile") }, loadfile);
	}
}