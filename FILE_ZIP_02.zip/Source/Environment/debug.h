#include "environment.h"
#include "metatable.h"
#include "exploit.h"

using namespace Environment;
using namespace Explorer;

namespace DebugLibrary {
	auto debug_header_getclosure(lua_State* ls, bool allowCclosure = false, bool popcl = true) -> Closure*
	{
		luaL_checkany(ls, 1);

		if (!(lua_isfunction(ls, 1) || lua_isnumber(ls, 1)))
		{
			luaL_argerror(ls, 1, xorstr_("function or number"));
		}

		int level = 0;
		if (lua_isnumber(ls, 1))
		{
			level = lua_tointeger(ls, 1);

			if (level <= 0)
			{
				luaL_argerror(ls, 1, xorstr_("invalid stack level."));
			}
		}
		else if (lua_isfunction(ls, 1))
		{
			level = -lua_gettop(ls);
		}

		lua_Debug ar;
		if (!lua_getinfo(ls, level, "f", &ar))
		{
			luaL_argerror(ls, 1, xorstr_("invalid stack level."));
		}

		if (!lua_isfunction(ls, -1))
		{
			luaL_argerror(ls, 1, xorstr_("stack does not point to a function."));
		}

		if (!allowCclosure && lua_iscfunction(ls, -1))
		{
			luaL_argerror(ls, 1, xorstr_("expected Lua Closure!"));
		}

		auto closure = clvalue(luaA_toobject(ls, -1));
		if (popcl) lua_pop(ls, 1);

		return closure;
	}

	static int debug_getupvalues(lua_State* ls)
	{
		LogFunction(xorstr_("getupvalues"));
		const auto closure = debug_header_getclosure(ls, true, false);

		// Create a table with space for the number of upvalues ( if any )
		lua_createtable(ls, closure->nupvalues, 0);
		for (int i = 0; i < closure->nupvalues; i++)
		{
			if (lua_getupvalue(ls, -2, ++i)) lua_rawseti(ls, -2, i);
		}

		return 1;
	}

	static int debug_getupvalue(lua_State* ls)
	{
		LogFunction(xorstr_("getupvalue"));
		const auto closure = debug_header_getclosure(ls, true, false);
		const auto idx = luaL_checkinteger(ls, 2);

		if (!(closure->nupvalues > 0))
		{
			luaL_argerror(ls, 1, xorstr_("function does not have upvalues."));
		}

		if (!(idx >= 1 && idx <= closure->nupvalues))
		{
			luaL_argerror(ls, 2, xorstr_("index out of range [1, nupvalues]."));
		}

		if (!lua_getupvalue(ls, -1, idx)) lua_pushnil(ls);
		return 1;
	}

	static int debug_setupvalue(lua_State* ls)
	{
		LogFunction(xorstr_("setupvalue"));
		// dont allow this in C Functions
		const auto closure = debug_header_getclosure(ls, false, false);
		const auto idx = luaL_checkinteger(ls, 2);

		if (!(closure->nupvalues > 0))
		{
			luaL_argerror(ls, 1, xorstr_("function does not have upvalues."));
		}

		if (!(idx >= 1 && idx <= closure->nupvalues))
		{
			luaL_argerror(ls, 2, xorstr_("index out of range [1, nupvalues]."));
		}

		lua_pushvalue(ls, 3);
		lua_setupvalue(ls, -2, idx);
		return 1;
	}

	static int debug_getconstants(lua_State* ls)
	{
		LogFunction(xorstr_("getconstants"));
		Closure* closure = debug_header_getclosure(ls);
		Proto* p = (Proto*)closure->l.p;

		// Create a table with space for the number of constants ( if any )
		lua_createtable(ls, (int)p->sizek, 0);
		for (int i = 0; i < (int)p->sizek; i++)
		{
			TValue k = p->k[i];

			if (k.tt == LUA_TFUNCTION || k.tt == LUA_TTABLE)
			{
				lua_pushnil(ls);
			}
			else
			{
				luaC_threadbarrier(ls) luaA_pushobject(ls, &k);
			}

			lua_rawseti(ls, -2, i + 1);
		}

		return 1;
	}

	int debug_getconstant(lua_State* ls)
	{
		LogFunction(xorstr_("getconstant"));
		const auto closure = debug_header_getclosure(ls);
		const auto idx = luaL_checkinteger(ls, 2);
		Proto* p = (Proto*)closure->l.p;

		if ((int)p->sizek == 0)
		{
			luaL_argerror(ls, 1, xorstr_("function does not have constants."));
		}

		if (!(idx >= 1 && idx <= p->sizek))
		{
			luaL_argerror(ls, 2, xorstr_("index out of range [1, sizek]."));
		}

		TValue k = (TValue)p->k[idx - 1];

		if (k.tt == LUA_TFUNCTION || k.tt == LUA_TTABLE)
		{
			lua_pushnil(ls);
		}
		else
		{
			luaC_threadbarrier(ls) luaA_pushobject(ls, &k);
		}

		return 1;
	}

	static int debug_setconstant(lua_State* L)
	{
		LogFunction(xorstr_("setconstant"));
		luaL_checktype(L, 1, LUA_TFUNCTION);
		luaL_checktype(L, 2, LUA_TNUMBER);
		luaL_checkany(L, 3);

		if (lua_iscfunction(L, 1))
			return 0;

		Proto* p = clvalue(luaA_toobject(L, 1))->l.p;
		if (!p) {
			lua_pushnil(L);
			return 1;
		}

		int Idx = lua_tonumber(L, 2);
		if (Idx < 1 || Idx > p->sizek) {
			lua_pushnil(L);
			return 1;
		}

		TValue* KTable = p->k;
		if (!KTable) {
			lua_pushnil(L);
			return 1;
		}

		TValue* tval = &(KTable[Idx - 1]);
		if (!tval) {
			lua_pushnil(L);
			return 1;
		}

		const TValue* new_t = luaA_toobject(L, 3);
		tval->tt = new_t->tt;
		tval->value = new_t->value;

		return 0;
	}

	// Clones proto and returns the clone.
	// Only important information is cloned.
	auto debug_helper_clone_proto(lua_State* ls, Proto* proto) -> Proto*
	{
		// Make a new proto.
		// We gotta make new GCObjects for the proto.
		Proto* clone = luaF_newproto(ls);

		// Copy constants
		clone->sizek = proto->sizek;
		clone->k = luaM_newarray(ls, proto->sizek, TValue, proto->memcat);
		for (int j = 0; j < proto->sizek; ++j)
		{
			clone->k[j].tt = proto->k[j].tt;
			clone->k[j].value = proto->k[j].value;
		}

		clone->lineinfo = 0;
		clone->locvars = 0;
		clone->nups = 0;
		clone->sizeupvalues = 0;
		clone->sizelineinfo = 0;
		clone->linegaplog2 = 0;
		clone->sizelocvars = 0;
		clone->linedefined = 0;

		// Copy debugname and source, make new TStrings
		if (proto->debugname)
		{
			const auto debugname = getstr(proto->debugname);
			const auto sz = strlen(debugname);

			clone->debugname = luaS_newlstr(ls, debugname, sz);
		}

		if (proto->source)
		{
			const auto source = getstr(proto->source);
			const auto sz = strlen(source);

			clone->source = luaS_newlstr(ls, source, sz);
		}

		clone->numparams = proto->numparams;
		clone->is_vararg = proto->is_vararg;
		clone->maxstacksize = proto->maxstacksize;
		clone->bytecodeid = proto->bytecodeid;

		// Set the code to return nothing.
		clone->sizecode = 1;
		clone->code = luaM_newarray(ls, clone->sizecode, Instruction, proto->memcat);
		clone->code[0] = 0x10082; // RETURN [ insn, enc 227 ]
		clone->codeentry = clone->code;
		clone->debuginsn = 0;

		// Copy protos
		clone->sizep = proto->sizep;
		clone->p = luaM_newarray(ls, proto->sizep, Proto*, proto->memcat);
		for (int j = 0; j < proto->sizep; ++j)
		{
			clone->p[j] = debug_helper_clone_proto(ls, proto->p[j]);
		}

		return clone;
	}

	static int debug_getprotos(lua_State* ls)
	{
		LogFunction(xorstr_("getprotos"));
		const auto closure = debug_header_getclosure(ls);
		const auto p = debug_helper_clone_proto(ls, closure->l.p); // Proto Clone

		// Create a table with space for the number of protos ( if any )
		lua_createtable(ls, p->sizep, 0);
		for (int i = 0; i < p->sizep; i++)
		{
			// Make a LClosure for them
			// We want to avoid vulns, hence the clones with empty code
			Proto* proto = p->p[i];
			Closure* pcl = luaF_newLclosure(ls, closure->nupvalues, closure->env, proto);

			luaC_threadbarrier(ls) setclvalue(ls, ls->top, pcl) ls->top++;

			lua_rawseti(ls, -2, i + 1);
		}

		return 1;
	}

	int debug_getproto(lua_State* L) {
		LogFunction(xorstr_("getproto"));
		Closure* cl;
		if (lua_isnumber(L, 1)) {
			lua_Debug ar;
			if (!lua_getinfo(L, luaL_checkinteger(L, 1), "f", &ar))
				luaL_argerror(L, 1, "level out of range");
			if (lua_iscfunction(L, -1))
				luaL_argerror(L, 1, "level points to cclosure");
			cl = (Closure*)lua_topointer(L, -1);
		}
		else if (lua_isfunction(L, 1)) {
			luaL_checktype(L, 1, LUA_TFUNCTION);
			cl = (Closure*)lua_topointer(L, 1);
			if (cl->isC)
				luaL_argerror(L, 1, "lclosure expected");
		}
		else {
			luaL_argerror(L, 1, "function or number expected");
		}
		int index = luaL_checkinteger(L, 2);
		bool active = false;
		if (!lua_isnoneornil(L, 3))
			active = luaL_checkboolean(L, 3);
		if (!active) {
			if (index < 1 || index > cl->l.p->sizep)
				luaL_argerror(L, 2, "index out of range");
			Proto* p = cl->l.p->p[index - 1];
			std::unique_ptr<TValue> function(new TValue{});
			setclvalue(L, function.get(), luaF_newLclosure(L, 0, cl->env, p));
			luaA_pushobject(L, function.get());
		}
		else {
			lua_newtable(L);

			struct Ctx {
				lua_State* L;
				int count;
				Closure* cl;
			} ctx{ L, 0, cl };

			luaM_visitgco(L, &ctx, [](void* pctx, lua_Page* page, GCObject* gco) -> bool {
				Ctx* ctx = static_cast<Ctx*>(pctx);
				if (!((gco->gch.marked ^ WHITEBITS) & otherwhite(ctx->L->global)))
					return false;

				uint8_t tt = gco->gch.tt;
				if (tt == LUA_TFUNCTION) {
					Closure* cl = (Closure*)gco;
					if (!cl->isC && cl->l.p == ctx->cl->l.p->p[ctx->count]) {
						setclvalue(ctx->L, ctx->L->top, cl);
						ctx->L->top++;
						lua_rawseti(ctx->L, -2, ++ctx->count);
					}
				}
				return false;
				});
		}
		return 1;
	}

	static int debug_getstack(lua_State* ls)
	{
		LogFunction(xorstr_("getstack"));
		luaL_checkany(ls, 1);

		if (!(lua_isfunction(ls, 1) || lua_isnumber(ls, 1)))
		{
			luaL_argerror(ls, 1, xorstr_("function or number"));
		}

		int level = 0;
		if (lua_isnumber(ls, 1))
		{
			level = lua_tointeger(ls, 1);

			if (level <= 0)
			{
				luaL_argerror(ls, 1, xorstr_("invalid stack level."));
			}
		}
		else if (lua_isfunction(ls, 1))
		{
			level = -lua_gettop(ls);
		}

		lua_Debug ar;
		if (!lua_getinfo(ls, level, "f", &ar))
		{
			luaL_argerror(ls, 1, xorstr_("invalid stack level."));
		}

		if (!lua_isfunction(ls, -1))
		{
			luaL_argerror(ls, 1, xorstr_("stack does not point to a function."));
		}

		if (lua_iscfunction(ls, -1))
		{
			luaL_argerror(ls, 1, xorstr_("expected Lua Closure"));
		}

		lua_pop(ls, 1); // pop the closure since we dont need it

		auto ci = ls->ci[-level];

		if (lua_isnumber(ls, 2))
		{
			const auto idx = lua_tointeger(ls, 2) - 1;

			if (idx >= cast_int(ci.top - ci.base) || idx < 0)
			{
				luaL_argerror(ls, 2, xorstr_("Invalid stack index."));
			}

			auto val = ci.base + idx;
			luaC_threadbarrier(ls) luaA_pushobject(ls, val);
		}
		else
		{
			int idx = 0;
			lua_newtable(ls);

			for (auto val = ci.base; val < ci.top; val++)
			{
				lua_pushinteger(ls, idx++ + 1);

				luaC_threadbarrier(ls) luaA_pushobject(ls, val);

				lua_settable(ls, -3);
			}
		}

		return 1;
	}

	static int debug_setstack(lua_State* ls)
	{
		LogFunction(xorstr_("setstack"));
		luaL_checkany(ls, 1);

		if (!(lua_isfunction(ls, 1) || lua_isnumber(ls, 1)))
		{
			luaL_argerror(ls, 1, xorstr_("function or number"));
		}

		int level = 0;
		if (lua_isnumber(ls, 1))
		{
			level = lua_tointeger(ls, 1);

			if (level <= 0)
			{
				luaL_argerror(ls, 1, xorstr_("invalid stack level."));
			}
		}
		else if (lua_isfunction(ls, 1))
		{
			level = -lua_gettop(ls);
		}

		lua_Debug ar;
		if (!lua_getinfo(ls, level, "f", &ar))
		{
			luaL_argerror(ls, 1, xorstr_("invalid stack level."));
		}

		if (!lua_isfunction(ls, -1))
		{
			luaL_argerror(ls, 1, xorstr_("stack does not point to a function."));
		}

		if (lua_iscfunction(ls, -1))
		{
			luaL_argerror(ls, 1, xorstr_("expected Lua Closure"));
		}

		lua_pop(ls, 1); // pop the closure since we dont need it

		luaL_checkany(ls, 3);

		auto ci = ls->ci[-level];

		const auto idx = luaL_checkinteger(ls, 2) - 1;
		if (idx >= cast_int(ci.top - ci.base) || idx < 0)
		{
			luaL_argerror(ls, 2, xorstr_("Invalid stack index."));
		}

		if ((ci.base + idx)->tt != luaA_toobject(ls, 3)->tt)
		{
			luaL_argerror(ls, 3, xorstr_("Source type does not match the Target type."));
		}

		setobj2s(ls, (ci.base + idx), luaA_toobject(ls, 3))
			return 0;
	}

	static int debug_getinfo(lua_State* ls)
	{
		LogFunction(xorstr_("getinfo"));
		luaL_checkany(ls, 1);

		if (!(lua_isfunction(ls, 1) || lua_isnumber(ls, 1)))
		{
			luaL_argerror(ls, 1, xorstr_("function or number"));
		}

		int level;
		if (lua_isnumber(ls, 1))
		{
			level = lua_tointeger(ls, 1);
		}
		else
		{
			level = -lua_gettop(ls);
		}

		auto desc = lua_isstring(ls, 2) ? lua_tolstring(ls, 2, NULL) : "sluanf";

		lua_Debug ar;
		if (!lua_getinfo(ls, level, desc, &ar))
		{
			luaL_argerror(ls, 1, xorstr_("invalid stack level."));
		}

		if (!lua_isfunction(ls, -1))
		{
			luaL_argerror(ls, 1, xorstr_("stack does not point to a function."));
		}

		lua_newtable(ls);
		{
			if (std::strchr(desc, 's'))
			{
				lua_pushstring(ls, ar.source);
				lua_setfield(ls, -2, "source");

				lua_pushstring(ls, ar.short_src);
				lua_setfield(ls, -2, "short_src");

				lua_pushstring(ls, ar.what);
				lua_setfield(ls, -2, "what");

				lua_pushinteger(ls, ar.linedefined);
				lua_setfield(ls, -2, "linedefined");
			}

			if (std::strchr(desc, 'l'))
			{
				lua_pushinteger(ls, ar.currentline);
				lua_setfield(ls, -2, "currentline");
			}

			if (std::strchr(desc, 'u'))
			{
				lua_pushinteger(ls, ar.nupvals);
				lua_setfield(ls, -2, "nups");
			}

			if (std::strchr(desc, 'a'))
			{
				lua_pushinteger(ls, ar.isvararg);
				lua_setfield(ls, -2, "is_vararg");

				lua_pushinteger(ls, ar.nparams);
				lua_setfield(ls, -2, "numparams");
			}

			if (std::strchr(desc, 'n'))
			{
				lua_pushstring(ls, ar.name);
				lua_setfield(ls, -2, "name");
			}

			if (std::strchr(desc, 'f'))
			{
				lua_pushvalue(ls, -2);
				lua_remove(ls, -3);
				lua_setfield(ls, -2, "func");
			}
		}

		return 1;
	}

	static int debug_isvalidlevel(lua_State* ls)
	{
		int level = 0;
		if (lua_isnumber(ls, 1))
		{
			level = lua_tointeger(ls, 1);

			if (level <= 0)
			{
				luaL_argerror(ls, 1, xorstr_("invalid stack level."));
			}
		}
		else if (lua_isfunction(ls, 1))
		{
			level = -lua_gettop(ls);
		}

		lua_Debug ar;
		if (!lua_getinfo(ls, level, "f", &ar))
		{
			luaL_argerror(ls, 1, xorstr_("invalid stack level."));
		}

		lua_pushboolean(ls, lua_isfunction(ls, -1));
		return 1;
	}

	static int getcurrentline(lua_State* ls)
	{
		int level{ 1 };
		if (lua_isnumber(ls, 1))
		{
			level = lua_tointeger(ls, 1);

			if (level <= 0)
			{
				luaL_argerror(ls, 1, xorstr_("invalid stack level."));
			}
		}

		lua_Debug ar;
		if (!lua_getinfo(ls, level, "l", &ar))
		{
			luaL_argerror(ls, 1, xorstr_("invalid stack level."));
		}

		lua_pushinteger(ls, ar.currentline);
		return 1;
	}

	static int debug_getcallstack(lua_State* ls)
	{
		lua_State* thread = lua_isthread(ls, 1) ? lua_tothread(ls, 1) : ls;

		int idx = 1;
		lua_newtable(ls);
		{
			while (idx < lua_stackdepth(thread))
			{
				lua_Debug ar;
				lua_getinfo(thread, idx, "f", &ar);
				/*
				lua_newtable(ls);
				{
					lua_pushstring(ls, ar.source);
					lua_setfield(ls, -2, "source");

					lua_pushstring(ls, ar.short_src);
					lua_setfield(ls, -2, "short_src");

					lua_pushstring(ls, ar.what);
					lua_setfield(ls, -2, "what");

					lua_pushinteger(ls, ar.linedefined);
					lua_setfield(ls, -2, "linedefined");

					if ( strcmp(ar.what, "Lua") == 0 )
					{
						lua_pushinteger(ls, ar.currentline);
						lua_setfield(ls, -2, "currentline");
					}

					lua_pushinteger(ls, ar.nupvals);
					lua_setfield(ls, -2, "nups");

					lua_pushinteger(ls, ar.isvararg);
					lua_setfield(ls, -2, "is_vararg");

					lua_pushinteger(ls, ar.nparams);
					lua_setfield(ls, -2, "numparams");

					lua_pushstring(ls, ar.name);
					lua_setfield(ls, -2, "name");

					lua_pushvalue(thread, -2);
					lua_remove(thread, -3);
					lua_xmove(thread, ls, 1);
					lua_setfield(ls, -2, "func");
				}
				*/
				lua_xmove(thread, ls, 1);
				lua_rawseti(ls, -2, idx++);
			}
		}

		return 1;
	}

	void Register(lua_State* L) {
		lua_newtable(L);
		AddField(L, { xorstr_("getregistry") }, ExploitLibrary::getreg);
		AddField(L, { xorstr_("getmetatable") }, MetaTableLibrary::getrawmetatable);
		AddField(L, { xorstr_("setmetatable") }, MetaTableLibrary::setrawmetatable);
		AddField(L, { xorstr_("getupvalue") }, debug_getupvalue);
		AddField(L, { xorstr_("getupvalues") }, debug_getupvalues);
		AddField(L, { xorstr_("setupvalue") }, debug_setupvalue);
		AddField(L, { xorstr_("getconstant") }, debug_getconstant);
		AddField(L, { xorstr_("getconstants") }, debug_getconstants);
		AddField(L, { xorstr_("setconstant") }, debug_setconstant);
		AddField(L, { xorstr_("getinfo") }, debug_getinfo);
		AddField(L, { xorstr_("getstack") }, debug_getstack);
		AddField(L, { xorstr_("setstack") }, debug_setstack);
		AddField(L, { xorstr_("getproto") }, debug_getproto);
		AddField(L, { xorstr_("getprotos") }, debug_getprotos);
		lua_setfield(L, LUA_GLOBALSINDEX, xorstr_("debug"));
	}
}