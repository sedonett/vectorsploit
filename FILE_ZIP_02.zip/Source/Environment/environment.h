#pragma once

#include "offsets.h"
#include "luauinit.h"

#include <format>
#include <future>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <format>
#include <filesystem>
#include <fstream>
#include <winuser.h>
#include <sstream>
#include <regex>
#include <map>

#include <lz4.h>
#include <lualib.h>
#include <lstate.h>
#include <ldo.h>
#include <lfunc.h>
#include <lapi.h>
#include <lgc.h>
#include <lmem.h>
#include <lstring.h>

#define _WINSOCKAPI_
#define WIN32_LEAN_AND_MEAN

#include <cpr/cpr.h>

#include "Crypt/crypt.h"

#pragma comment(lib, "Ws2_32.lib")
#pragma comment (lib, "Wldap32.lib")
#pragma comment (lib, "Crypt32.lib")

#define xor xorstr_
#define lua_normalisestack(L, maxSize) { if (lua_gettop(L) > maxSize) lua_settop(L, maxSize); }
#define lua_preparepush(L, pushCount) lua_rawcheckstack(L, pushCount)
#define lua_preparepushcollectable(L, pushCount) { lua_preparepush(L, pushCount); luaC_threadbarrier(L); }
#define lua_tomutclosure(L, idx) const_cast<Closure*>(reinterpret_cast<const Closure*>(lua_topointer(L, idx)))

namespace fs = std::filesystem;

namespace Explorer {
	inline std::filesystem::path workspaceDir;
	inline std::filesystem::path assetsDir;
	inline std::ofstream logFile;

	inline std::unordered_set<std::string> blacklistedExtensions = { ".csh", ".wsh", ".dll", ".bat", ".cmd", ".scr", ".vbs", ".js",
															 ".ts",  ".wsf", ".msi", ".com", ".lnk", ".ps1", ".py", "vb", ".vbe",
															 ".py3", ".pyc", ".pyw", ".vb", ".html", ".ws", ".psy", ".hta",
	};

	void LogFunction(const char* fmt, ...);

	bool IsExtensionBlacklisted(const fs::path& path);
	bool IsPathSafe(const std::string& relativePath);

	std::filesystem::path CheckPath(lua_State* L);

	void Init();
}

namespace MetaHooks
{
	static __int64 old_namecall;
	static __int64 old_index;

	static bool isDangerous(const std::string& method);

	static bool isPurchasing(const std::string& method);

	inline auto namecall_hook(lua_State* L) -> int;

	inline auto index_hook(lua_State* L) -> int;

	auto Initialize(lua_State* L) -> void;
}

namespace Environment {
	void AddGlobal(lua_State* L, std::vector<const char*> names, lua_CFunction func);
	void AddField(lua_State* L, std::vector<const char*> names, lua_CFunction func);
	void CheckInstance(lua_State* L, int idx, const char* className = "");

	void Initialize(lua_State* L);
}