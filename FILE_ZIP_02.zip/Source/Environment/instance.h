#pragma once

#include "environment.h"

#include "Compressor/compressor.h"

using namespace Environment;
using namespace Explorer;

namespace InstanceLibrary {
	auto getinstances(lua_State* rl) -> int
	{
		LogFunction(xorstr_("getinstances"));
		struct instance_context {
			lua_State* rl;
			std::intptr_t n;
		} context = { rl, 0 };

		lua_newtable(rl);
		for (lua_Page* page = rl->global->allgcopages; page;) {
			lua_Page* next{ page->listnext };

			luaM_visitpage(page, &context,
				[](void* context, lua_Page* page, GCObject* gco) -> bool {
					instance_context* gcContext{ reinterpret_cast<instance_context*>(context) };
					auto type = gco->gch.tt;

					if (type == LUA_TUSERDATA) {


						TValue* top = gcContext->rl->top;
						top->value.p = reinterpret_cast<void*>(gco);
						top->tt = type;
						gcContext->rl->top++;

						if (!strcmp(luaL_typename(gcContext->rl, -1), "Instance")) {
							gcContext->n++;
							lua_rawseti(gcContext->rl, -2, gcContext->n);
						}
						else {
							lua_pop(gcContext->rl, 1);
						}
					}

					return true;
				}
			);
			page = next;
		}
		return 1;
	}

	auto getnilinstances(lua_State* rl) -> int
	{
		LogFunction(xorstr_("getnilinstances"));
		struct instance_context {
			lua_State* rl;
			std::intptr_t n;
		} context = { rl, 0 };

		lua_newtable(rl);

		for (lua_Page* page = rl->global->allgcopages; page;) {
			lua_Page* next{ page->listnext };

			luaM_visitpage(page, &context,
				[](void* context, lua_Page* page, GCObject* gco) -> bool {
					instance_context* gcContext{ reinterpret_cast<instance_context*>(context) };
					auto type = gco->gch.tt;

					if (type == LUA_TUSERDATA) {


						TValue* top = gcContext->rl->top;
						top->value.p = reinterpret_cast<void*>(gco);
						top->tt = type;
						gcContext->rl->top++;

						if (!strcmp(luaL_typename(gcContext->rl, -1), "Instance")) {
							lua_getfield(gcContext->rl, -1, "Parent");
							bool nullParent = lua_isnoneornil(gcContext->rl, -1);

							if (nullParent) {
								lua_pop(gcContext->rl, 1);
								gcContext->n++;
								lua_rawseti(gcContext->rl, -2, gcContext->n);
							}
							else {
								lua_pop(gcContext->rl, 2);
							}
						}
						else {
							lua_pop(gcContext->rl, 1);
						}
					}

					return true;
				}
			);

			page = next;
		}
		return 1;
	}

	auto getscripthash(lua_State* L) -> int
	{
		LogFunction(xorstr_("getscripthash"));
		CheckInstance(L, 1, "LuaSourceContainer");
		lua_getfield(L, 1, "GetHash");
		lua_pushvalue(L, 1);
		lua_call(L, 1, 1);
		return 1;
	}

	auto getscriptbytecode_handler(lua_State* rl) -> int
	{
		uintptr_t script = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, 1));
		const char* classname = *reinterpret_cast<const char**>(*reinterpret_cast<uintptr_t*>(script + RBX::Instance::ClassDescriptor) + RBX::ClassDescriptor::ClassName);
		std::string compressed_bytecode;

		if (strcmp(classname, "LocalScript") == 0)
			compressed_bytecode = *reinterpret_cast<std::string*>(*reinterpret_cast<uintptr_t*>(script + RBX::Bytecode::LocalScript) + 16);
		else if (strcmp(classname, "ModuleScript") == 0)
			compressed_bytecode = *reinterpret_cast<std::string*>(*reinterpret_cast<uintptr_t*>(script + RBX::Bytecode::ModuleScript) + 16);
		else
			luaL_error(rl, "Local/Module scripts expected.");

		std::string bytecode = Compressor::decompress(compressed_bytecode);
		if (bytecode.at(0) == 0)
			luaL_error(rl, "Invalid bytecode.");

		lua_pushlstring(rl, bytecode.data(), bytecode.length());
		return 1;
	}
	
	auto getscriptbytecode(lua_State* rl) -> int
	{
		LogFunction(xorstr_("getscriptbytecode"));

		CheckInstance(rl, 1, "LuaSourceContainer");

		lua_pushcclosure(rl, getscriptbytecode_handler, nullptr, 0);
		lua_pushvalue(rl, 1);
		lua_call(rl, 1, 1);
		
		return 1;
	}

	int decompile(lua_State* L) {
		return 0;
	};

	auto getproperties(lua_State* rl) -> int
	{
		LogFunction(xorstr_("getproperties"));
		luaL_checktype(rl, 1, LUA_TUSERDATA);

		uintptr_t script = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, 1));
		uintptr_t descriptor = *reinterpret_cast<uintptr_t*>(script + RBX::Instance::ClassDescriptor);

		lua_newtable(rl);

		int position = 0;
		std::vector<uintptr_t> properties = *reinterpret_cast<std::vector<uintptr_t>*>(descriptor + RBX::ClassDescriptor::PropertyDescriptors);
		for (int i = 0; i < properties.size(); i++)
		{
			std::string property_name = *reinterpret_cast<std::string*>(*reinterpret_cast<uintptr_t*>(properties[i] + RBX::ClassDescriptor::ClassName));
			lua_pushlstring(rl, property_name.c_str(), property_name.size());
			lua_rawseti(rl, -2, ++position);
		}

		return 1;
	}

	auto getcallbackvalue(lua_State* rl) -> int
	{
		LogFunction(xorstr_("getcallbackvalue"));
		luaL_checktype(rl, 1, LUA_TUSERDATA);

		uintptr_t object = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, 1));

		std::int32_t atom{};
		auto property = lua_tostringatom(rl, 2, &atom);

		auto map = RBX::MapDescriptor[atom];
		auto descriptor = RBX::GetCallback(*reinterpret_cast<__int64*>(object + 24) + 944, &map);
		auto prop = *reinterpret_cast<__int64*>(descriptor);

		int idx = *(__int64*)(*(uintptr_t*)(*(uintptr_t*)(*(uintptr_t*)((object + *(uintptr_t*)(prop + 120)) + 24) + 56) + 40) + 20);
		lua_getref(rl, idx);

		if (lua_iscfunction(rl, -1) || lua_isLfunction(rl, -1))
			return 1;

		lua_pop(rl, 1);
		return 0;
	}

    int getscripts(lua_State* L) {
		//luaL_stackcheck(L, 0, 0);
		LogFunction(xorstr_("getscripts"));
		struct instancecontext {
			lua_State* L;
			__int64 n;
		} Context = { L, 0 };

		lua_createtable(L, 0, 0);

		const auto ullOldThreshold = L->global->GCthreshold;
		L->global->GCthreshold = SIZE_MAX; // Disable GC temporarily

		luaM_visitgco(L, &Context, [](void* ctx, lua_Page* page, GCObject* gco) -> bool {
			auto gCtx = static_cast<instancecontext*>(ctx);
			const auto type = gco->gch.tt;

			if (isdead(gCtx->L->global, gco))
				return false;

			if (type == LUA_TUSERDATA) {

				TValue* top = gCtx->L->top;
				top->value.p = reinterpret_cast<void*>(gco);
				top->tt = type;
				gCtx->L->top++;

				if (!strcmp(luaL_typename(gCtx->L, -1), "Instance")) { // instance check
					lua_getfield(gCtx->L, -1, "ClassName"); // check if instance has no parent / basically nil instance

					const char* inst_class = lua_tolstring(gCtx->L, -1, 0);
					if (!strcmp(inst_class, "LocalScript") || !strcmp(inst_class, "ModuleScript"))
					{
						lua_pop(gCtx->L, 1);
						gCtx->n++;
						lua_rawseti(gCtx->L, -2, gCtx->n);
					}
					else
						lua_pop(gCtx->L, 2);

				}
				else {
					lua_pop(gCtx->L, 1);
				}
			}

			return true;
			});

		L->global->GCthreshold = ullOldThreshold;

		return 1;
	}

	void Register(lua_State* L) {
		AddGlobal(L, { xorstr_("getinstances") }, getinstances);
		AddGlobal(L, { xorstr_("getnilinstances") }, getnilinstances);
		AddGlobal(L, { xorstr_("getscripthash") }, getscripthash);
		AddGlobal(L, { xorstr_("getscriptbytecode") }, getscriptbytecode);
		AddGlobal(L, { xorstr_("getproperties") }, getproperties);
		AddGlobal(L, { xorstr_("getcallbackvalue") }, getcallbackvalue);
		AddGlobal(L, { xorstr_("getscripts") }, getscripts);
		AddGlobal(L, { xorstr_("getscriptbytecode") }, getscriptbytecode);
	}
}