#pragma once

#include <Windows.h>

#include <Luau/Bytecode.h>
#include <Luau/BytecodeUtils.h>
#include <Luau/BytecodeBuilder.h>

#define Rebase(Address) reinterpret_cast<uintptr_t>(GetModuleHandleA(0)) + Address

inline class c_bytecode : public Luau::BytecodeEncoder
{
public:
	void encode(uint32_t* data, size_t count) override
	{
		for (auto i = 0; i < count;)
		{
			uint8_t op = LUAU_INSN_OP(data[i]);
			const auto oplen = Luau::getOpLength((LuauOpcode)op);

			BYTE* OpCodeLookUpTable = (BYTE*)Rebase(0x4BF8D50);
			uint8_t new_op = op * 227;

			new_op = OpCodeLookUpTable[new_op];
			data[i] = (new_op) | (data[i] & ~0xff);
			i += oplen;
		}
	}

} BytecodeEncoder;

typedef struct lua_State lua_State;

namespace RBX {
	const auto Print = (void(__fastcall*)(int, const char*, ...))(Rebase(0x14CD600));
	const auto GetTaskScheduler = (uintptr_t(__fastcall*)())(Rebase(0x2F12F20));

	const auto GetGlobalStateForInstance = (uintptr_t(__fastcall*)(uintptr_t, uintptr_t*, uintptr_t*))(Rebase(0xDE3860));
	const auto DecryptLuaState = (uintptr_t(__fastcall*)(uintptr_t))(Rebase(0xBA8340));
	const auto Defer = (int(__fastcall*)(lua_State*))(Rebase(0xFBA3B0));

	const auto PushInstance = (void(__fastcall*)(lua_State * a1, uintptr_t a2))(Rebase(0xEB9C10));
	const auto Impersonator = (void(__fastcall*)(std::int64_t*, std::int32_t*, std::int64_t))(Rebase(0x2CA6DC0));
	const auto GetCallback = (__int64* (__fastcall*)(__int64 a1, uintptr_t * prop_name))(Rebase(0xAAE020));

	const auto EnableLoadModule = Rebase(0x5589258);
	const auto MapDescriptor = reinterpret_cast<uintptr_t*>(Rebase(0x5A1F810));

	const auto RequireFlag = 0x1b0;
	const auto ScriptNode = 0x198;

	namespace TaskScheduler {
		const uintptr_t JobsStart = 0x1D0;
		const uintptr_t JobsEnd = 0x1D8;
		const uintptr_t JobName = 0x90;

		const uintptr_t DatamodelJob = 0xB0;
		const uintptr_t DatamodelJobToDatamodel = 0x198;

		const uintptr_t ScriptContext = 0x1F8;
	}

	namespace ScriptContext {
		const uintptr_t GlobalStates = 0x120;
		const uintptr_t LuaState = 0x88;
	}

	namespace Bytecode {
		const uintptr_t LocalScript = 0x1C0;
		const uintptr_t ModuleScript = 0x168;
	}

	namespace ClassDescriptor {
		const uintptr_t ClassName = 0x8;
		const uintptr_t PropertyDescriptors = 0x28;
	}

	namespace DataModel {
		const uintptr_t IsLoaded = 0x628;

		enum State : uint8_t {
			STATE_HOMEAPP = 15,
			STATE_INGAME = 31
		};
	}

	namespace Instance {
		const uintptr_t ClassDescriptor = 0x18;
		const uintptr_t Parent = 0x50;
		const uintptr_t Name = 0x68;
		const uintptr_t Children = 0x70;
	}
}