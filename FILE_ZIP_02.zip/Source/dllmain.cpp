#include <Windows.h>
#include <thread>

#include "Execution/execution.h"
#include "TPHandler/tphandler.h"
#include "Pipe/pipe.h"

extern "C" __declspec(dllexport) LRESULT CALLBACK callback(int code, WPARAM wParam, LPARAM lParam) {
    return CallNextHookEx(NULL, code, wParam, lParam);
}

void MainThread(HMODULE hModule) {
    Execution::Initialize();

    std::thread(&TPHandler::Start).detach();
    std::thread(PipeSystem::RunNamedPipe, "\\\\.\\pipe\\vectorsploit").detach();
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        std::thread(MainThread, hModule).detach();
        break;
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

