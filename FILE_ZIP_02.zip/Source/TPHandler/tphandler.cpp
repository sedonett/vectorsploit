#include "tphandler.h"

void TPHandler::Start() {
    uintptr_t oldDataModel = TaskScheduler::GetDataModel();

    while (true) {
        std::this_thread::sleep_for(std::chrono::milliseconds(500));

        uintptr_t newDataModel = TaskScheduler::GetDataModel();
        if (newDataModel == 0) continue;

        auto currentState = *reinterpret_cast<uint8_t*>(newDataModel + RBX::DataModel::IsLoaded);
        if (currentState != RBX::DataModel::State::STATE_INGAME) {
            break;
        }
    }

    while (true) {
        std::this_thread::sleep_for(std::chrono::milliseconds(500));

        uintptr_t newDataModel = TaskScheduler::GetDataModel();
        if (newDataModel == 0) continue;

        auto currentState = *reinterpret_cast<uint8_t*>(newDataModel + RBX::DataModel::IsLoaded);
        if (currentState == RBX::DataModel::State::STATE_INGAME) {
            break;
        }
    }

    TaskScheduler::OldFunction = nullptr;

    std::this_thread::sleep_for(std::chrono::milliseconds(3000));
    std::thread(&TPHandler::Start).detach();

    Execution::Initialize();
}